@echo off
setlocal
title CRM Etiquetas - instalar atualizador
set "BASE=%LOCALAPPDATA%\CRM-Etiquetas"
set "DEST=%BASE%\extensao"
if not exist "%BASE%" mkdir "%BASE%"
copy /Y "%~dp0atualizador\atualizar.ps1" "%BASE%\atualizar.ps1" >nul
copy /Y "%~dp0atualizador\atualizar.vbs" "%BASE%\atualizar.vbs" >nul

echo.
echo  Baixando a versao mais nova do CRM...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%BASE%\atualizar.ps1"
if not exist "%DEST%\manifest.json" (
  echo  Sem internet agora: vou usar esta pasta mesmo.
  robocopy "%~dp0." "%DEST%" /E /NFL /NDL /NJH /NJS /NP >nul
)
set "VER=?"
for /f "usebackq delims=" %%v in (`powershell.exe -NoProfile -Command "(Get-Content '%DEST%\manifest.json' -Raw | ConvertFrom-Json).version"`) do set "VER=%%v"
echo.
echo  Versao na pasta do CRM: %VER%

echo  Criando a tarefa que atualiza sozinha (de hora em hora)...
schtasks /Create /F /SC HOURLY /TN "CRM Etiquetas - atualizar" /TR "wscript.exe \"%BASE%\atualizar.vbs\"" >nul
if errorlevel 1 (
  echo  [!] Nao consegui criar a tarefa automatica. Me avise.
) else (
  echo  Tarefa criada.
)

echo %DEST%| clip
echo.
echo  ==============================================================
echo   PRONTO! Agora, no Chrome:
echo.
echo   1. Abra  chrome://extensions
echo   2. Clique em "Carregar sem compactacao"
echo   3. Na janela que abrir, clique na barra de endereco (em cima),
echo      aperte Ctrl+V e Enter. O endereco ja esta copiado:
echo        %DEST%
echo   4. Clique em "Selecionar pasta".
echo   5. Aperte F5 no WhatsApp Web.
echo.
echo   Ja tinha carregado essa pasta antes? Em chrome://extensions,
echo   clique na setinha redonda (Recarregar) do Coyote CRM e
echo   confira que aparece a versao %VER%.
echo.
echo   Daqui pra frente o CRM se atualiza sozinho. Quando tiver
echo   versao nova, aparece um botao verde no topo do CRM.
echo  ==============================================================
echo.
pause
