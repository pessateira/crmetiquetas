// Fala com a planilha da equipe (Google Apps Script). Fica aqui, fora da
// página do WhatsApp, para não depender das regras de segurança dela.
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg?.type === 'versao') {
    // O atualizador do Windows troca os arquivos da pasta. Aqui só comparamos a
    // versão que está na pasta com a que está rodando.
    fetch(chrome.runtime.getURL('manifest.json'), { cache: 'no-store' })
      .then((r) => r.json())
      .then((m) => reply({ nova: m.version !== chrome.runtime.getManifest().version ? m.version : null }))
      .catch(() => reply({ nova: null }));
    return true;
  }
  if (msg?.type === 'procurar') {
    procurarAtualizacao().then(reply, (err) => reply({ erro: err.message }));
    return true;
  }
  if (msg?.type === 'recarregar') {
    reply({ ok: true });
    setTimeout(() => chrome.runtime.reload(), 200);
    return false;
  }
  if (msg?.type !== 'equipe') return false;
  const { url, body } = msg;
  if (!/^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec$/.test(String(url))) {
    reply({ ok: false, erro: 'Endereço da planilha inválido (deve terminar em /exec).' });
    return false;
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 30000);
  fetch(url, { method: 'POST', body: JSON.stringify(body), redirect: 'follow', signal: controller.signal })
    .then((r) => r.text())
    .then((text) => {
      try {
        reply(JSON.parse(text));
      } catch {
        reply({ ok: false, erro: 'A planilha não respondeu direito. Confira se a implantação está como "Qualquer pessoa".' });
      }
    })
    .catch((err) => reply({ ok: false, erro: `Sem conexão com a planilha (${err.message})` }))
    .finally(() => clearTimeout(timer));
  return true; // resposta assíncrona
});

// Botão "Procurar atualização" do CRM: vê qual é a versão mais nova publicada e,
// se for preciso, pede ao atualizador do Windows (Native Messaging) que baixe agora.
const VERSAO_URL = 'https://raw.githubusercontent.com/pessateira/crmetiquetas/main/versao.txt';
const versaoNaPasta = () =>
  fetch(chrome.runtime.getURL('manifest.json'), { cache: 'no-store' })
    .then((r) => r.json())
    .then((m) => m.version);
const maior = (a, b) => {
  const x = String(a).split('.').map(Number);
  const y = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i += 1) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0);
  return false;
};
async function procurarAtualizacao() {
  const rodando = chrome.runtime.getManifest().version;
  let ultima = '';
  try {
    ultima = (await (await fetch(`${VERSAO_URL}?t=${Date.now()}`, { cache: 'no-store' })).text()).trim();
  } catch {}
  let pasta = await versaoNaPasta();
  let nativo = null;
  if (ultima && maior(ultima, pasta)) {
    nativo = await new Promise((resolve) => {
      const timer = setTimeout(() => resolve({ ok: false, erro: 'o atualizador demorou demais' }), 150000);
      try {
        chrome.runtime.sendNativeMessage('com.coyote.crm', { acao: 'atualizar' }, (r) => {
          clearTimeout(timer);
          resolve(chrome.runtime.lastError ? { ok: false, erro: chrome.runtime.lastError.message, semBotao: true } : r || { ok: false });
        });
      } catch (err) {
        clearTimeout(timer);
        resolve({ ok: false, erro: err.message, semBotao: true });
      }
    });
    pasta = await versaoNaPasta();
  }
  return { rodando, pasta, ultima, nativo, temNova: Boolean(ultima && maior(ultima, rodando)) };
}
