// Fala com a planilha da equipe (Google Apps Script). Fica aqui, fora da
// página do WhatsApp, para não depender das regras de segurança dela.
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg?.type === 'versao') {
    // O atualizador do Windows troca os arquivos da pasta. Aqui só comparamos a
    // versão que está na pasta com a que está rodando.
    fetch(chrome.runtime.getURL('manifest.json'), { cache: 'no-store' })
      .then((r) => r.json())
      .then((m) => reply({ nova: m.version !== chrome.runtime.getManifest().version ? m.version : null }))
      .catch(() => reply({ nova: null }));
    return true;
  }
  if (msg?.type === 'recarregar') {
    reply({ ok: true });
    setTimeout(() => chrome.runtime.reload(), 200);
    return false;
  }
  if (msg?.type !== 'equipe') return false;
  const { url, body } = msg;
  if (!/^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec$/.test(String(url))) {
    reply({ ok: false, erro: 'Endereço da planilha inválido (deve terminar em /exec).' });
    return false;
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 30000);
  fetch(url, { method: 'POST', body: JSON.stringify(body), redirect: 'follow', signal: controller.signal })
    .then((r) => r.text())
    .then((text) => {
      try {
        reply(JSON.parse(text));
      } catch {
        reply({ ok: false, erro: 'A planilha não respondeu direito. Confira se a implantação está como "Qualquer pessoa".' });
      }
    })
    .catch((err) => reply({ ok: false, erro: `Sem conexão com a planilha (${err.message})` }))
    .finally(() => clearTimeout(timer));
  return true; // resposta assíncrona
});
