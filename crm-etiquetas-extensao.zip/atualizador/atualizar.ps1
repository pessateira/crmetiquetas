# CRM Etiquetas - atualizador automatico (Windows).
# Baixa a versao mais nova do CRM e coloca na pasta que o Chrome usa:
#   %LOCALAPPDATA%\CRM-Etiquetas\extensao
# Roda sozinho de hora em hora (tarefa "CRM Etiquetas - atualizar").
# So mexe nessa pasta. Nao mexe no WhatsApp nem no Chrome.

$ErrorActionPreference = 'Stop'
$url  = 'https://github.com/pessateira/crmetiquetas/raw/main/crm-etiquetas-extensao.zip'
$base = Join-Path $env:LOCALAPPDATA 'CRM-Etiquetas'
$dest = Join-Path $base 'extensao'
$log  = Join-Path $base 'atualizacoes.log'
$tmp  = Join-Path $env:TEMP ('crm-etiquetas-' + [guid]::NewGuid().ToString('N'))

function Anotar($texto) {
  $linha = (Get-Date -Format 'yyyy-MM-dd HH:mm') + '  ' + $texto
  Add-Content -Path $log -Value $linha
  Write-Host ('  ' + $texto)
}

# Baixa o zip. Tenta 3 jeitos diferentes, porque alguns computadores bloqueiam um deles.
function Baixar($destino) {
  $u = $url + '?v=' + [DateTime]::UtcNow.Ticks   # evita pegar uma copia velha guardada no caminho
  $erros = @()
  try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri $u -OutFile $destino -UseBasicParsing -Headers @{ 'Cache-Control' = 'no-cache' }
    return
  } catch { $erros += ('PowerShell: ' + $_.Exception.Message) }
  try {
    $curl = Join-Path $env:SystemRoot 'System32\curl.exe'
    if (Test-Path $curl) {
      & $curl -L -f -s -S -o $destino $u
      if ($LASTEXITCODE -eq 0 -and (Test-Path $destino)) { return }
      $erros += ('curl: codigo ' + $LASTEXITCODE)
    }
  } catch { $erros += ('curl: ' + $_.Exception.Message) }
  try {
    Start-BitsTransfer -Source $u -Destination $destino
    return
  } catch { $erros += ('BITS: ' + $_.Exception.Message) }
  throw ('nao consegui baixar (' + ($erros -join ' | ') + ')')
}

New-Item -ItemType Directory -Force -Path $base | Out-Null
New-Item -ItemType Directory -Force -Path $tmp | Out-Null
try {
  Baixar (Join-Path $tmp 'crm.zip')
  Expand-Archive -Path (Join-Path $tmp 'crm.zip') -DestinationPath (Join-Path $tmp 'x') -Force
  $novo = (Get-Content (Join-Path $tmp 'x\manifest.json') -Raw | ConvertFrom-Json).version
  if (-not $novo) { throw 'o arquivo baixado nao tem manifest.json' }
  $atual = ''
  if (Test-Path (Join-Path $dest 'manifest.json')) {
    $atual = (Get-Content (Join-Path $dest 'manifest.json') -Raw | ConvertFrom-Json).version
  }
  if ($novo -ne $atual) {
    New-Item -ItemType Directory -Force -Path $dest | Out-Null
    # copia tudo e deixa o manifest.json por ultimo: o CRM so avisa da versao
    # nova quando todos os arquivos ja chegaram
    robocopy (Join-Path $tmp 'x') $dest /MIR /XF manifest.json /NFL /NDL /NJH /NJS /NP | Out-Null
    Copy-Item (Join-Path $tmp 'x\manifest.json') (Join-Path $dest 'manifest.json') -Force
    # o proprio atualizador tambem se atualiza
    Copy-Item (Join-Path $dest 'atualizador\atualizar.ps1') (Join-Path $base 'atualizar.ps1') -Force
    Copy-Item (Join-Path $dest 'atualizador\atualizar.vbs') (Join-Path $base 'atualizar.vbs') -Force
    Anotar ("atualizado de " + $(if ($atual) { $atual } else { 'nada' }) + " para " + $novo)
  } else {
    Anotar ('ja esta na versao mais nova (' + $novo + ')')
  }
} catch {
  Anotar ('erro: ' + $_.Exception.Message)
} finally {
  Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
}
