# CRM Etiquetas (Coyote CRM) - atualizador automatico (Windows).
# Baixa a versao mais nova do CRM e coloca na pasta que o Chrome usa:
#   %LOCALAPPDATA%\CRM-Etiquetas\extensao
# Roda sozinho de hora em hora (tarefa "CRM Etiquetas - atualizar").
# So mexe nessa pasta. Nao mexe no WhatsApp nem no Chrome.
#
# No repositorio publico ficam:
#   versao.txt                 -> numero da versao mais nova (ex.: 3.2.3)
#   versoes/crm-<versao>.zip   -> o CRM daquela versao (nome novo a cada versao,
#                                 assim nunca vem uma copia velha guardada no caminho)
#   crm-etiquetas-extensao.zip -> a mais nova (para baixar na mao)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'   # sem isso o PowerShell baixa muito devagar
$repo = 'https://github.com/pessateira/crmetiquetas/raw/main/'
$base = Join-Path $env:LOCALAPPDATA 'CRM-Etiquetas'
$dest = Join-Path $base 'extensao'
$log  = Join-Path $base 'atualizacoes.log'
$tmp  = Join-Path $env:TEMP ('crm-etiquetas-' + [guid]::NewGuid().ToString('N'))

function Anotar($texto) {
  $linha = (Get-Date -Format 'yyyy-MM-dd HH:mm') + '  ' + $texto
  Add-Content -Path $log -Value $linha
  Write-Host ('  ' + $texto)
}

# Baixa um arquivo. Tenta 3 jeitos, porque alguns computadores bloqueiam um deles.
# Primeiro o curl (rapido, vem no Windows 10 e 11), sempre com limite de tempo.
function Baixar($u, $destino) {
  $erros = @()
  $curl = Join-Path $env:SystemRoot 'System32\curl.exe'
  if (Test-Path $curl) {
    try {
      & $curl -L -f -s -S --connect-timeout 20 --max-time 90 -o $destino $u
      if ($LASTEXITCODE -eq 0 -and (Test-Path $destino)) { return }
      $erros += ('curl: codigo ' + $LASTEXITCODE)
    } catch { $erros += ('curl: ' + $_.Exception.Message) }
  }
  try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri $u -OutFile $destino -UseBasicParsing -TimeoutSec 90
    return
  } catch { $erros += ('PowerShell: ' + $_.Exception.Message) }
  try {
    Start-BitsTransfer -Source $u -Destination $destino
    return
  } catch { $erros += ('BITS: ' + $_.Exception.Message) }
  throw ('nao consegui baixar (' + ($erros -join ' | ') + ')')
}

# Pergunta a versao mais nova direto para o GitHub (API), sem a copia de ate
# 5 minutos que o raw.githubusercontent.com guarda. Se a API falhar, usa o raw.
$api = 'https://api.github.com/repos/pessateira/crmetiquetas/contents/versao.txt'
function UltimaVersao {
  $curl = Join-Path $env:SystemRoot 'System32\curl.exe'
  if (Test-Path $curl) {
    try {
      $v = & $curl -L -f -s -S --connect-timeout 20 --max-time 30 -H 'Accept: application/vnd.github.raw' -H 'User-Agent: coyote-crm' $api
      if ($LASTEXITCODE -eq 0 -and $v) { return ([string]($v -join '')).Trim() }
    } catch {}
  }
  try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $r = Invoke-WebRequest -Uri $api -UseBasicParsing -TimeoutSec 30 -Headers @{ Accept = 'application/vnd.github.raw'; 'User-Agent' = 'coyote-crm' }
    if ($r.Content) { return ([string]$r.Content).Trim() }
  } catch {}
  try {
    Baixar ($repo + 'versao.txt') (Join-Path $tmp 'versao.txt')
    return (Get-Content (Join-Path $tmp 'versao.txt') -Raw).Trim()
  } catch {}
  return ''
}

function VersaoDe($manifest) {
  if (-not (Test-Path $manifest)) { return '' }
  return [string](Get-Content $manifest -Raw | ConvertFrom-Json).version
}

New-Item -ItemType Directory -Force -Path $base | Out-Null
New-Item -ItemType Directory -Force -Path $tmp | Out-Null

# Liga o botao "Procurar atualizacao" do CRM (Native Messaging do Chrome) e
# deixa a tarefa automatica rodando a cada 15 minutos. Tudo so para este usuario.
function Preparar {
  try {
    foreach ($f in 'host.ps1', 'host.bat') {
      $de = Join-Path $dest ('atualizador\' + $f)
      if (Test-Path $de) { Copy-Item $de (Join-Path $base $f) -Force }
    }
    if (Test-Path (Join-Path $base 'host.bat')) {
      $json = Join-Path $base 'com.coyote.crm.json'
      $manifesto = @{
        name = 'com.coyote.crm'
        description = 'Coyote CRM - atualizador'
        path = (Join-Path $base 'host.bat')
        type = 'stdio'
        allowed_origins = @('chrome-extension://glpdhaondfjclgcfcdofmdcophjdelgp/')
      } | ConvertTo-Json
      [IO.File]::WriteAllText($json, $manifesto)
      $chave = 'HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.coyote.crm'
      if (-not (Test-Path $chave)) { New-Item -Path $chave -Force | Out-Null }
      Set-ItemProperty -Path $chave -Name '(default)' -Value $json
    }
    $marca = Join-Path $base 'tarefa-15min.ok'
    if (-not (Test-Path $marca)) {
      $vbs = Join-Path $base 'atualizar.vbs'
      schtasks /Create /F /SC MINUTE /MO 15 /TN 'CRM Etiquetas - atualizar' /TR ('wscript.exe "' + $vbs + '"') | Out-Null
      if ($LASTEXITCODE -eq 0) { Set-Content -Path $marca -Value 'ok' }
    }
  } catch {
    Anotar ('aviso ao preparar o botao de atualizacao: ' + $_.Exception.Message)
  }
}
try {
  $atual = VersaoDe (Join-Path $dest 'manifest.json')
  $ultima = UltimaVersao
  if ($ultima -and $ultima -eq $atual) {
    Anotar ('ja esta na versao mais nova (' + $atual + ')')
  } else {
    $zipUrl = if ($ultima -match '^[0-9.]+$') { $repo + 'versoes/crm-' + $ultima + '.zip' } else { $repo + 'crm-etiquetas-extensao.zip' }
    Baixar $zipUrl (Join-Path $tmp 'crm.zip')
    Expand-Archive -Path (Join-Path $tmp 'crm.zip') -DestinationPath (Join-Path $tmp 'x') -Force
    $novo = VersaoDe (Join-Path $tmp 'x\manifest.json')
    if (-not $novo) { throw 'o arquivo baixado nao tem manifest.json' }
    if ($novo -eq $atual) {
      Anotar ('ja esta na versao mais nova (' + $atual + ')')
    } else {
      New-Item -ItemType Directory -Force -Path $dest | Out-Null
      # copia tudo e deixa o manifest.json por ultimo: o CRM so avisa da versao
      # nova quando todos os arquivos ja chegaram
      robocopy (Join-Path $tmp 'x') $dest /MIR /XF manifest.json /NFL /NDL /NJH /NJS /NP | Out-Null
      Copy-Item (Join-Path $tmp 'x\manifest.json') (Join-Path $dest 'manifest.json') -Force
      # o proprio atualizador tambem se atualiza
      Copy-Item (Join-Path $dest 'atualizador\atualizar.ps1') (Join-Path $base 'atualizar.ps1') -Force
      Copy-Item (Join-Path $dest 'atualizador\atualizar.vbs') (Join-Path $base 'atualizar.vbs') -Force
      Anotar ('atualizado de ' + $(if ($atual) { $atual } else { 'nada' }) + ' para ' + $novo)
    }
  }
} catch {
  Anotar ('erro: ' + $_.Exception.Message)
} finally {
  Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
  Preparar
}
