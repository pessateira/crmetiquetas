# Coyote CRM - "atendente" do botao "Procurar atualizacao" do CRM.
# O Chrome chama este arquivo (Native Messaging) quando voce clica no botao.
# Ele so roda o atualizador (atualizar.ps1) e responde qual versao ficou na pasta.
# Nao recebe nenhum dado do WhatsApp.

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$base = Split-Path -Parent $MyInvocation.MyCommand.Path

function Responder($obj) {
  $bytes = [Text.Encoding]::UTF8.GetBytes(($obj | ConvertTo-Json -Compress))
  $out = [Console]::OpenStandardOutput()
  $out.Write([BitConverter]::GetBytes([int32]$bytes.Length), 0, 4)
  $out.Write($bytes, 0, $bytes.Length)
  $out.Flush()
}

try {
  # le o pedido do Chrome (4 bytes de tamanho + JSON); o conteudo nao importa
  $in = [Console]::OpenStandardInput()
  $tam = New-Object byte[] 4
  if ($in.Read($tam, 0, 4) -eq 4) {
    $n = [BitConverter]::ToInt32($tam, 0)
    if ($n -gt 0 -and $n -lt 65536) {
      $buf = New-Object byte[] $n
      $lido = 0
      while ($lido -lt $n) { $r = $in.Read($buf, $lido, $n - $lido); if ($r -le 0) { break }; $lido += $r }
    }
  }
  $saida = & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $base 'atualizar.ps1') 2>&1 | Out-String
  $versao = ''
  $m = Join-Path $base 'extensao\manifest.json'
  if (Test-Path $m) { $versao = [string](Get-Content $m -Raw | ConvertFrom-Json).version }
  Responder @{ ok = $true; versao = $versao; saida = $saida.Trim() }
} catch {
  Responder @{ ok = $false; erro = $_.Exception.Message }
}
