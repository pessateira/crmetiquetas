// Regras do CRM (sem tela), usadas pela extensão e pelos testes.
// MODO ESPELHO: o CRM só LÊ as etiquetas do WhatsApp. Nunca cria, troca ou
// remove etiqueta. Para mudar alguém de etapa, troque a etiqueta no próprio
// WhatsApp (celular ou WhatsApp Web) e o CRM acompanha.
(function (root) {
  const WAIT_WARN_MIN = 30; // cliente esperando resposta: amarelo
  const WAIT_LATE_MIN = 4 * 60; // vermelho
  const WAIT_MAX_DAYS = 7; // depois disso não conta mais como "esperando"
  const STALE_DAYS = 7; // parado na mesma etapa
  const FINAL_NAME = /fechad|ganh|perdid|cancelad|finaliz|conclu|encerrad|cliente ativo/i;

  // Etapas na ordem escolhida. Sem configuração, todas as etiquetas são etapas.
  function stageList(labels, settings) {
    const byId = new Map(labels.map((l) => [String(l.id), l]));
    const order = Array.isArray(settings?.stageIds) ? settings.stageIds.map(String) : labels.map((l) => String(l.id));
    const finals = settings?.finalIds ? new Set(settings.finalIds.map(String)) : null;
    const list = order.filter((id) => byId.has(id)).map((id) => byId.get(id));
    // etiquetas criadas no WhatsApp depois da configuração entram no fim como etapa
    if (Array.isArray(settings?.stageIds) && settings.knownLabelIds) {
      const known = new Set(settings.knownLabelIds.map(String));
      for (const l of labels) if (!known.has(String(l.id)) && !order.includes(String(l.id))) list.push(l);
    }
    return list.map((l) => ({
      id: String(l.id),
      name: l.name,
      color: l.hexColor || '#9aa5b1',
      final: finals ? finals.has(String(l.id)) : FINAL_NAME.test(l.name || ''),
    }));
  }

  // Etiquetas de etapa que a conversa tem (na ordem do funil).
  function stagesOf(labelIds, stages) {
    const ids = new Set((labelIds || []).map(String));
    return stages.filter((s) => ids.has(s.id));
  }

  // A etapa do cartão. Se a conversa tiver mais de uma etiqueta de etapa,
  // vale a mais avançada no funil (e o cartão avisa).
  function stageOf(labelIds, stages) {
    const found = stagesOf(labelIds, stages);
    return found.length ? found[found.length - 1].id : '';
  }

  function duration(minutes) {
    if (minutes < 60) return `${Math.max(1, Math.round(minutes))} min`;
    const hours = minutes / 60;
    if (hours < 24) return `${Math.floor(hours)} h`;
    const days = Math.floor(hours / 24);
    return days === 1 ? '1 dia' : `${days} dias`;
  }

  // card: { lastFromMe: true|false|null, lastAt: segundos, unread, since: ms }
  function alerts(card, stage, nowMs = Date.now()) {
    const out = [];
    const waiting = card.lastFromMe === false || (card.lastFromMe == null && card.unread > 0);
    if (waiting && card.lastAt) {
      const minutes = (nowMs / 1000 - card.lastAt) / 60;
      if (minutes >= WAIT_WARN_MIN && minutes < WAIT_MAX_DAYS * 1440) {
        out.push({ kind: 'wait', level: minutes >= WAIT_LATE_MIN ? 'late' : 'warn', text: `Esperando sua resposta há ${duration(minutes)}` });
      }
    }
    if (stage && !stage.final && card.since) {
      const days = (nowMs - card.since) / 86400000;
      if (days >= STALE_DAYS) out.push({ kind: 'stale', level: 'warn', text: `Parado em "${stage.name}" há ${duration(days * 1440)}` });
    }
    return out;
  }

  // Próximo passo com data ('AAAA-MM-DD'): avisa no dia e quando atrasa.
  function localDay(ms) {
    const d = new Date(ms);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }
  function stepInfo(note, nowMs = Date.now()) {
    if (!note?.nextDate) return null;
    const today = localDay(nowMs);
    const [y, m, d] = String(note.nextDate).split('-').map(Number);
    if (!y || !m || !d) return null;
    const days = Math.round((Date.UTC(y, m - 1, d) - Date.parse(`${today}T00:00:00Z`)) / 86400000);
    const what = note.nextStep ? `: ${note.nextStep}` : '';
    const dm = `${String(d).padStart(2, '0')}/${String(m).padStart(2, '0')}`;
    if (days < 0) return { kind: 'step', level: 'late', alert: true, text: `Atrasado há ${-days === 1 ? '1 dia' : `${-days} dias`}${what}` };
    if (days === 0) return { kind: 'step', level: 'warn', alert: true, text: `Hoje${what}` };
    return { kind: 'step', level: 'info', alert: false, text: `${days === 1 ? 'Amanhã' : dm}${what}` };
  }

  // "Novos": conversas sem etiqueta de etapa, a partir de uma data fixa
  // (o último mês antes de instalar) e todas as que chegarem depois.
  function isNovo(card, novosDesdeMs) {
    if (card.archived) return false;
    return (card.lastAt || 0) * 1000 >= (novosDesdeMs || 0);
  }

  // "Foto" das conversas que já existiam quando a regra de Novos mudou.
  // Daqui pra frente só entra em Novos (sem etiqueta) quem NUNCA tinha falado com você:
  // número que não estava na foto e com mensagem depois dela. Quem estava na foto
  // só fica em Novos se já estava lá (conversa do último mês antes de instalar).
  function knownKeys(card) {
    const d = String(card.phone || '').replace(/\D/g, '');
    return [String(card.id || ''), d.length >= 8 ? `p:${d.slice(-10)}` : ''].filter(Boolean);
  }
  function makeBaseline(cards, novosDesdeMs, nowMs) {
    const keys = {};
    for (const c of cards) {
      const v = isNovo(c, novosDesdeMs) ? 1 : 0;
      for (const k of knownKeys(c)) keys[k] = Math.max(keys[k] || 0, v);
    }
    return { at: nowMs, keys };
  }
  function isNovoAgora(card, novosDesdeMs, baseline) {
    if (card.archived) return false;
    if (!baseline) return isNovo(card, novosDesdeMs);
    const known = knownKeys(card).filter((k) => k in baseline.keys);
    if (known.length) return known.some((k) => baseline.keys[k] === 1);
    return (card.lastAt || 0) * 1000 >= baseline.at - 60000;
  }

  function formatPhone(chatId) {
    const m = String(chatId || '').match(/^(\d+)@c\.us$/);
    if (!m) return '';
    const br = m[1].match(/^55(\d{2})(\d{4,5})(\d{4})$/);
    return br ? `(${br[1]}) ${br[2]}-${br[3]}` : `+${m[1]}`;
  }

  const api = { stageList, stagesOf, stageOf, alerts, stepInfo, isNovo, isNovoAgora, makeBaseline, localDay, duration, formatPhone, FINAL_NAME };
  root.CRMCore = api;
  if (typeof module === 'object' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : window);
