// CRM Etiquetas dentro do WhatsApp Web, em MODO ESPELHO (somente leitura).
// As colunas são as etiquetas do WhatsApp Business e cada cartão fica na
// coluna da etiqueta que a conversa tem. O CRM NUNCA altera nada no
// WhatsApp: não cria, não troca e não remove etiquetas, e não envia
// mensagens. Para mudar alguém de etapa, troque a etiqueta no próprio
// WhatsApp (celular ou WhatsApp Web) e o cartão acompanha na próxima leitura.
//
// Roda isolado da página do WhatsApp (mundo "ISOLATED" da extensão): não
// usa nenhuma função interna do WhatsApp. Os dados vêm de leitor.js, que lê
// a cópia que o WhatsApp Web guarda no navegador, poucos segundos depois
// que algo muda na lista de conversas (ou quando você clica em Atualizar).
//
// EQUIPE (opcional): com uma planilha Google como ponto de encontro, cada
// pessoa publica uma cópia do seu funil e o CRM mostra todos juntos, com
// filtro "Todos / Meus / Fulano". Valor e anotações passam a ser da equipe.
(() => {
  if (window.__crmEtiquetas) return;
  window.__crmEtiquetas = true;
  const C = globalThis.CRMCore;

  // ---------- armazenamento (chrome.storage da extensão; localStorage só na página de teste) ----------
  const ext = typeof chrome !== 'undefined' && chrome.storage?.local && chrome.runtime?.id ? chrome : null;
  const RECARREGAR = 'O CRM foi atualizado e precisa recarregar: aperte F5 no WhatsApp Web (se continuar, em chrome://extensions clique em Recarregar no Coyote CRM).';
  async function toExt(msg) {
    for (let i = 0; i < 3; i += 1) {
      try {
        if (!chrome.runtime?.id) throw new Error('Extension context invalidated');
        return await ext.runtime.sendMessage(msg);
      } catch (err) {
        const perdido = /context invalidated|receiving end does not exist|could not establish connection|reading 'sendMessage'/i.test(err.message);
        if (!perdido) throw err;
        if (/context invalidated/i.test(err.message) || i === 2) throw new Error(RECARREGAR);
        await new Promise((r) => setTimeout(r, 1200)); // o motor da extensão pode estar acordando
      }
    }
    throw new Error(RECARREGAR);
  }
  const storage = {
    async get(key) {
      if (ext) return (await ext.storage.local.get(key))[key] ?? null;
      try { return JSON.parse(localStorage.getItem(key)); } catch { return null; }
    },
    async set(key, value) {
      if (ext) return ext.storage.local.set({ [key]: value });
      try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
    },
  };

  // ---------- estado ----------
  const S = {
    labels: [],
    stages: [],
    chats: [],
    contacts: [], // contatos salvos sem conversa no WhatsApp Web
    settings: {},
    cards: {}, // chatId -> { value, notes, since: { labelId: ms } } (deste Chrome)
    team: null, // { url, codigo, pessoa }
    shared: { cards: [], notes: new Map(), at: 0, error: null },
    filter: 'me', // 'me' | 'all' | nome da pessoa
    fx: { produto: '', nivel: '', origem: '' }, // filtros por selo ('-' = sem selo)
    open: false,
    search: '',
    attention: false,
    showPanel: false,
    drawerKey: null,
    screen: { prev: {}, conv: {} }, // o que apareceu na tela do WhatsApp (prévias e últimas mensagens)
    known: null, // "foto" das conversas que já existiam (regra de Novos)
    added: {}, // conversas puxadas para o funil: chatId -> { at, how: 'lista' | 'manual', by }
    manual: {}, // contatos digitados à mão: chatId -> { name, phone }
    removed: {}, // conversas removidas do funil: chave -> { name, stage, at } (só no CRM)
    diag: [], // diário de conexão (para achar a causa de quedas)
    paused: false, // leitura automática pausada
    drawerDirty: false, // ficha com alterações não salvas
    error: null,
    readAt: 0, // última leitura do WhatsApp (ms)
    reading: false,
  };
  const save = {
    settings: () => storage.set('crm:settings', S.settings),
    cards: () => storage.set('crm:cards', S.cards),
    team: () => storage.set('crm:team', S.team),
    filter: () => storage.set('crm:filter', S.filter),
    removed: () => storage.set('crm:removidos', S.removed),
    added: () => storage.set('crm:adicionados', S.added),
    known: () => storage.set('crm:conhecidos', S.known),
    manual: () => storage.set('crm:manuais', S.manual),
    screen: () => storage.set('crm:tela', S.screen),
    diag: () => storage.set('crm:diag', S.diag.slice(-300)),
    paused: () => storage.set('crm:pausado', S.paused),
  };
  const me = () => S.team?.pessoa || 'Eu';
  const norm = (s) => String(s || '').trim().toLowerCase();

  // Selos e ficha do cliente (ficam no CRM e na planilha da equipe, não no WhatsApp)
  // Produtos por marca: o selo do cartão mostra a sigla, na cor da marca
  const PRODUTOS = [
    { v: 'Vending Machine', marca: 'THM', sigla: 'VM' },
    { v: 'OCS', marca: 'THM', sigla: 'OCS' },
    { v: 'Freezer Mensal', marca: 'BRZ', sigla: 'FZ-M' },
    { v: 'Freezer Evento', marca: 'BRZ', sigla: 'FZ-E' },
    { v: 'Mercadinho', marca: 'Buy', sigla: 'MERC' },
    { v: 'Buy Box', marca: 'Buy', sigla: 'BOX' },
    { v: 'Franquia', marca: 'TMF', sigla: 'FRQ' },
  ];
  const MARCAS = ['THM', 'BRZ', 'Buy', 'TMF'];
  // valores das versões antigas (antes de separar por produto)
  const PRODUTO_ANTIGO = { 'Hot Machine': 'THM', Buy: 'Buy', BRZ: 'BRZ' };
  const produtoInfo = (v) => PRODUTOS.find((p) => p.v === v) || (v ? { v, marca: PRODUTO_ANTIGO[v] || '', sigla: v === 'Hot Machine' ? 'HM' : v, antigo: true } : null);
  const NIVEIS = [['N1', 'N1 pequeno'], ['N2', 'N2 médio'], ['N3', 'N3 grande'], ['N4', 'N4 gigante']];
  const ORIGENS = ['Moai', 'Indicação', 'Instagram', 'Google/Site', 'Outdoor', 'Prospecção ativa', 'Evento', 'Outro'];
  const TIPOS = ['Condomínio', 'Empresa', 'Hospital/Clínica', 'Academia', 'Escola/Faculdade', 'Hotel', 'Comércio', 'Outro'];
  const FICHA = ['nomeCrm', 'motivoPerda', 'perdaObs', 'value', 'notes', 'produto', 'nivel', 'origem', 'tipoLocal', 'tamanho', 'decisor', 'concorrente', 'nextStep', 'nextDate'];
  // Valor do negócio por ANO. Fichas antigas guardavam por mês (sem valorPeriodo): vira x12.
  const annual = (n) => {
    const v = Number(n?.value);
    if (n?.value == null || n.value === '' || !Number.isFinite(v)) return 0;
    return n.valorPeriodo === 'ano' ? v : v * 12;
  };
  // nome que aparece no cartão: o que você escreveu na ficha, ou o do WhatsApp
  const titleOf = (c) => noteOf(c).nomeCrm || c.name;
  // Negócio perdido: marcado aqui no CRM (fica na ficha) ou com a etiqueta "Perdido" no WhatsApp
  const MOTIVOS = ['Preço', 'Fechou com concorrente', 'Sem espaço ou local', 'Sem resposta', 'Sem interesse agora', 'Fora da área', 'Outro'];
  const LOST_RE = /perdid|perda|n[ãa]o fech/i;
  const lostOf = (c) => {
    if (LOST_RE.test(c.stageName || '')) return { via: 'etiqueta' };
    const p = noteOf(c).perda;
    // vale enquanto a etiqueta do WhatsApp for a mesma de quando marcou (mudou de etapa = reabriu)
    if (p && (p.stage || '') === (c.stageName || '')) return { via: 'crm', at: p.at, by: p.by };
    return null;
  };
  const NIVEL_COR = { N1: '#d6e9c6', N2: '#ffd97a', N3: '#ff9f6b', N4: '#c9a2ff' };

  // ---------- leitura do WhatsApp ----------
  // O leitor (leitor.js) só lê a cópia que o WhatsApp Web guarda no navegador.
  // Nada roda dentro do WhatsApp, então dá para ler quase em tempo real:
  // - logo depois que algo muda na lista de conversas (nova mensagem, etiqueta);
  // - a cada 15 s com o CRM aberto e a cada 1 min com ele fechado (para o aviso no botão);
  // - nunca com a aba do WhatsApp escondida, e nunca mais de uma vez a cada 4 s.
  const LER_ABERTO = 15 * 1000;
  const LER_FECHADO = 60 * 1000;
  const INTERVALO_MIN = 4 * 1000;

  async function refresh() {
    if (S.reading) return;
    S.reading = true;
    renderSync();
    try {
      const t0 = performance.now();
      const data = await (globalThis.CRMLeitorTeste || globalThis.CRMLeitor).ler(C.formatPhone);
      const ms = Math.round(performance.now() - t0);
      if (ms > 1500) note('leitura', `Leitura demorou ${(ms / 1000).toFixed(1)} s`);
      S.labels = data.labels;
      S.stages = C.stageList(S.labels, S.settings);
      S.chats = data.chats;
      S.contacts = data.contatos || [];
      // primeira leitura com a regra nova: tira a "foto" das conversas que já existem
      if (!S.known && S.chats.length) {
        S.known = C.makeBaseline(S.chats, S.settings.novosDesde, Date.now());
        save.known();
        note('leitura', `Foto das conversas existentes: ${S.chats.length}. Daqui pra frente só número novo entra em Novos.`);
      }
      S.readAt = Date.now();
      S.error = null;
      let dirty = false;
      for (const c of S.chats) {
        const st = C.stageOf(c.labels, S.stages);
        if (!st) continue;
        const rec = (S.cards[c.id] ??= {});
        rec.since ??= {};
        if (!rec.since[st]) {
          rec.since[st] = Date.now(); // a partir de quando o CRM viu o cartão nessa etapa
          dirty = true;
        }
      }
      if (dirty) save.cards();
      // conversa removida do funil volta sozinha se mudar de etapa no WhatsApp
      let back = false;
      for (const c of S.chats) {
        const r = S.removed[c.id];
        if (r && r.stage !== (stageById(C.stageOf(c.labels, S.stages))?.name || '')) {
          delete S.removed[c.id];
          back = true;
        }
      }
      if (back) save.removed();
    } catch (err) {
      S.error = `Não consegui ler o WhatsApp: ${err.message}`;
      if (S.diag.at(-1)?.text !== S.error) note('erro', S.error);
    }
    S.reading = false;
    render();
    schedulePublish();
  }
  let refreshTimer = null;
  const scheduleRefresh = (ms = 600) => {
    clearTimeout(refreshTimer);
    refreshTimer = setTimeout(refresh, ms);
  };

  // ---------- o que está na tela do WhatsApp (só lê, como os seus olhos) ----------
  // O texto das mensagens fica criptografado no banco do WhatsApp. Então o CRM
  // anota o que já aparece na tela: a prévia de cada conversa na lista e as
  // últimas mensagens da conversa que você abrir. Fica guardado só neste Chrome.
  const phoneKey = (t) => {
    const d = String(t || '').replace(/\D/g, '');
    return d.length >= 8 ? `p:${d.slice(-10)}` : '';
  };
  const titleKey = (t) => (/^[+\d\s().-]+$/.test(String(t)) && phoneKey(t)) || `n:${norm(String(t).replace(/^~\s*/, ''))}`;
  const keysOf = (c) => [c.name && `n:${norm(c.name)}`, c.waName && `n:${norm(c.waName)}`, phoneKey(c.phone)].filter(Boolean);
  function screenOf(c) {
    const ks = keysOf(c);
    const best = (map) => ks.map((k) => map[k]).filter(Boolean).sort((a, b) => b.at - a.at)[0] || null;
    return { prev: best(S.screen.prev), conv: best(S.screen.conv) };
  }
  let screenTimer;
  function captureScreen() {
    let changed = false;
    const pane = document.querySelector('#pane-side');
    if (pane) {
      for (const row of pane.querySelectorAll('[role="listitem"], [role="row"]')) {
        const titles = [...row.querySelectorAll('span[title]')].map((e) => e.getAttribute('title').trim()).filter(Boolean);
        if (titles.length < 2) continue;
        const name = titles[0];
        const text = titles[titles.length - 1];
        if (text === name) continue;
        const k = titleKey(name);
        const fromMe = Boolean(row.querySelector('[data-icon*="check"], [data-icon*="msg-time"]'));
        const old = S.screen.prev[k];
        if (old && old.text === text && old.fromMe === fromMe) continue;
        S.screen.prev[k] = { text: text.slice(0, 300), fromMe, at: Date.now() };
        changed = true;
      }
    }
    const main = document.querySelector('#main');
    if (main) {
      const head = main.querySelector('header span[title]') || main.querySelector('header [dir="auto"]');
      const name = (head?.getAttribute('title') || head?.textContent || '').trim();
      const lines = [...main.querySelectorAll('[data-pre-plain-text]')]
        .slice(-4)
        .map((el) => {
          const meta = /^\[([^\]]+)\]\s*(.*?):\s*$/.exec(el.getAttribute('data-pre-plain-text') || '');
          const text = (el.querySelector('.selectable-text')?.innerText || el.innerText || '').trim();
          if (!text) return null;
          return { when: meta?.[1] || '', who: el.closest('.message-out') ? 'Você' : meta?.[2] || '', text: text.slice(0, 400) };
        })
        .filter(Boolean);
      if (name && lines.length) {
        const k = titleKey(name);
        const old = S.screen.conv[k];
        if (!old || JSON.stringify(old.lines) !== JSON.stringify(lines)) {
          S.screen.conv[k] = { lines, at: Date.now() };
          changed = true;
        }
      }
    }
    if (!changed) return;
    // guarda só as 800 mais recentes de cada tipo
    for (const t of ['prev', 'conv']) {
      const e = Object.entries(S.screen[t]);
      if (e.length > 800) S.screen[t] = Object.fromEntries(e.sort((a, b) => b[1].at - a[1].at).slice(0, 800));
    }
    clearTimeout(screenTimer);
    screenTimer = setTimeout(() => {
      save.screen();
      if (S.open) render();
    }, 1500);
  }

  // ---------- cartões no formato único (meus, ao vivo, e da equipe, pela planilha) ----------
  const stageById = (id) => S.stages.find((s) => s.id === id);

  function myCards() {
    const labelName = new Map(S.labels.map((l) => [String(l.id), l]));
    const ids = new Set([...S.chats, ...S.contacts].map((c) => c.id));
    const manuais = Object.entries(S.manual)
      .filter(([id]) => !ids.has(id) && S.added[id])
      .map(([id, m]) => ({ id, name: m.name || C.formatPhone(id), waName: '', photo: '', phone: C.formatPhone(id), labels: [], lastAt: 0, lastFromMe: null, lastText: '', unread: 0, archived: false, semConversa: true }));
    return [...S.chats, ...S.contacts.filter((c) => S.added[c.id]), ...manuais]
      .map((c) => {
        const st = stageById(C.stageOf(c.labels, S.stages));
        const scr = screenOf(c);
        return {
          ...c,
          lastText: scr.prev ? `${scr.prev.fromMe ? 'Você: ' : ''}${scr.prev.text}` : c.lastText || '',
          conv: scr.conv,
          importado: S.added[c.id] ? { at: S.added[c.id].at, how: S.added[c.id].how || 'lista', by: S.added[c.id].by || me() } : null,
          key: c.id,
          owner: me(),
          mine: true,
          stageName: st?.name || '',
          stageColor: st?.color || '',
          final: Boolean(st?.final),
          since: st ? S.cards[c.id]?.since?.[st.id] ?? null : null,
          multi: C.stagesOf(c.labels, S.stages).map((s) => s.name),
          tags: c.labels.filter((id) => !stageById(id)).map((id) => labelName.get(id)).filter(Boolean).map((l) => ({ name: l.name, color: l.hexColor || '#ccc' })),
        };
      })
      .filter((c) => c.stageName || C.isNovoAgora(c, S.settings.novosDesde, S.known) || S.added[c.id]) // Novos: só quem nunca tinha falado com você (ou adicionada na mão)
      .filter((c) => !S.removed[c.key]);
  }

  function teamCards() {
    return S.shared.cards
      .filter((c) => c.owner !== me())
      .map((c) => ({ ...c, key: `${c.owner}|${c.id}`, mine: false, multi: c.multi || [], tags: c.tags || [] }))
      .filter((c) => !S.removed[c.key]);
  }

  function visibleCards() {
    if (S.filter === 'me' || !S.team) return myCards();
    if (S.filter === 'all') return [...myCards(), ...teamCards()];
    return S.filter === me() ? myCards() : teamCards().filter((c) => c.owner === S.filter);
  }

  const noteOf = (c) => {
    const shared = S.shared.notes.get(`${c.owner}|${c.id}`);
    if (shared) return shared;
    return c.mine ? S.cards[c.id] || {} : {};
  };
  const cardAlerts = (c) => {
    const lost = lostOf(c);
    const out = lost ? [] : C.alerts(c, c.stageName ? { name: c.stageName, final: c.final } : null);
    const n = noteOf(c);
    const step = C.stepInfo(n);
    if (step?.alert) out.unshift(step);
    if (lost && !n.motivoPerda) out.push({ kind: 'perda', level: 'warn', text: 'Falta o motivo da perda: abra o cartão e escolha', alert: true });
    return out;
  };
  const rank = (c) => {
    const a = cardAlerts(c);
    return a.some((x) => x.level === 'late') ? 2 : a.length ? 1 : 0;
  };

  function columnsData() {
    const q = norm(S.search);
    const cols = [{ key: '', name: 'Novos', color: '#9aa5b1', final: false, items: [] }];
    for (const s of S.stages) cols.push({ key: norm(s.name), name: s.name, color: s.color, final: s.final, items: [] });
    const byKey = new Map(cols.map((c) => [c.key, c]));
    for (const c of visibleCards()) {
      if (S.attention && rank(c) === 0) continue;
      const n = noteOf(c);
      let skip = false;
      for (const k of ['produto', 'nivel', 'origem']) {
        const want = S.fx[k];
        if (!want) continue;
        if (want === '-') skip ||= Boolean(n[k]);
        else if (k === 'produto' && want.startsWith('marca:')) skip ||= produtoInfo(n.produto)?.marca !== want.slice(6);
        else skip ||= n[k] !== want;
      }
      if (skip) continue;
      if (q) {
        const hay = [c.name, c.waName, c.phone, c.id, c.lastText, c.owner, c.stageName, ...FICHA.map((f) => n[f]), ...c.tags.map((t) => t.name)].join(' ');
        const h = norm(hay);
        if (!q.split(/\s+/).every((w) => h.includes(w))) continue; // cada palavra pode estar em qualquer lugar
      }
      let k = norm(c.stageName);
      if (lostOf(c)) {
        const st = S.stages.find((x) => LOST_RE.test(x.name));
        k = st ? norm(st.name) : '__perdidos';
        if (!byKey.has(k)) {
          const col = { key: k, name: 'Perdidos', color: '#e5484d', final: true, lost: true, items: [] };
          cols.push(col);
          byKey.set(k, col);
        }
      }
      if (!byKey.has(k)) {
        // etapa que só existe no WhatsApp de outra pessoa: vira coluna no fim
        const col = { key: k, name: c.stageName, color: c.stageColor || '#9aa5b1', final: c.final, items: [] };
        cols.push(col);
        byKey.set(k, col);
      }
      byKey.get(k).items.push(c);
    }
    for (const col of cols) {
      if (LOST_RE.test(col.name)) col.final = col.lost = true;
      col.items.sort((a, b) => rank(b) - rank(a) || b.lastAt - a.lastAt);
    }
    // Perdidos sempre por último
    const li = cols.findIndex((c) => c.lost);
    if (li > 0) cols.push(...cols.splice(li, 1));
    byKey.get('').items = byKey.get('').items.slice(0, 200);
    return cols;
  }

  // ---------- equipe (planilha Google) ----------
  async function teamCall(body) {
    if (!S.team?.url) return { ok: false, erro: 'Equipe não configurada' };
    const payload = { ...body, codigo: S.team.codigo };
    if (ext) {
      try {
        return (await toExt({ type: 'equipe', url: S.team.url, body: payload })) ?? { ok: false, erro: 'A planilha demorou demais para responder.' };
      } catch (err) {
        return { ok: false, erro: err.message };
      }
    }
    try {
      // sem extensão (página de teste): chama direto
      const r = await fetch(S.team.url, { method: 'POST', body: JSON.stringify(payload) });
      return await r.json();
    } catch (err) {
      return { ok: false, erro: err.message };
    }
  }

  function snapshot() {
    return myCards().map((c) => ({
      id: c.id,
      name: c.name,
      phone: c.phone,
      stageName: c.stageName,
      stageColor: c.stageColor,
      final: c.final,
      since: c.since,
      multi: c.multi,
      tags: c.tags,
      lastAt: c.lastAt,
      lastFromMe: c.lastFromMe,
      lastText: c.lastText,
      importado: c.importado,
      unread: c.unread,
    }));
  }
  let lastPublished = '';
  let lastPublishAt = 0;
  let publishTimer = null;
  function schedulePublish() {
    if (!S.team?.url) return;
    clearTimeout(publishTimer);
    publishTimer = setTimeout(publish, 5000);
  }
  async function publish(force = false) {
    if (!S.team?.url) return;
    const cards = snapshot();
    const sig = JSON.stringify(cards.map((c) => [c.id, c.stageName, c.lastAt, c.lastFromMe, c.unread, c.name]));
    if (!force && sig === lastPublished && Date.now() - lastPublishAt < 10 * 60 * 1000) return;
    const r = await teamCall({ acao: 'publicar', pessoa: me(), cartoes: cards });
    if (r?.ok) {
      lastPublished = sig;
      lastPublishAt = Date.now();
      S.shared.error = null;
    } else {
      S.shared.error = r?.erro || 'falha ao enviar para a planilha';
      render();
    }
  }
  async function pull() {
    if (!S.team?.url) return;
    const r = await teamCall({ acao: 'ler' });
    if (r?.ok) {
      S.shared.cards = r.cartoes || [];
      S.shared.notes = new Map((r.notas || []).map((n) => [`${n.owner}|${n.id}`, n]));
      S.shared.at = Date.now();
      S.shared.error = null;
    } else {
      S.shared.error = r?.erro || 'falha ao ler a planilha';
    }
    render();
  }
  // fichas preenchidas antes de ligar a equipe sobem para a planilha
  async function uploadLocalFichas() {
    const names = new Map(S.chats.map((c) => [c.id, c.name]));
    let sent = 0;
    for (const [id, rec] of Object.entries(S.cards)) {
      if (!FICHA.some((f) => rec[f] != null && rec[f] !== '')) continue;
      if (S.shared.notes.has(`${me()}|${id}`)) continue;
      const ficha = fichaOf(rec);
      const r = await teamCall({ acao: 'anotar', dono: me(), id, nome: names.get(id) || '', ficha, pessoa: me() });
      if (r?.ok) {
        S.shared.notes.set(`${me()}|${id}`, { ...ficha, owner: me(), id, by: me() });
        sent += 1;
      }
    }
    if (sent) toast(`${sent} ficha(s) que estavam só neste Chrome foram para a planilha da equipe.`);
  }
  const teamPeople = () => [...new Set([me(), ...S.shared.cards.map((c) => c.owner)])].filter(Boolean);


  // ---------- tela ----------
  const host = document.createElement('div');
  host.id = 'crm-etiquetas';
  const root = host.attachShadow({ mode: globalThis.CRMLeitorTeste ? 'open' : 'closed' }); // fechado: a página do WhatsApp não enxerga o CRM
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const money = (v) => (v ? Number(v).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 }) : '');
  const moneyShort = (v) => {
    const n = Number(v) || 0;
    if (!n) return '';
    if (n >= 1e6) return `R$ ${(n / 1e6).toLocaleString('pt-BR', { maximumFractionDigits: 1 })} mi`;
    if (n >= 1e3) return `R$ ${(n / 1e3).toLocaleString('pt-BR', { maximumFractionDigits: 1 })} mil`;
    return `R$ ${n.toLocaleString('pt-BR')}`;
  };
  function ago(sec) {
    if (!sec) return '';
    const d = Date.now() / 1000 - sec;
    if (d < 60) return 'agora';
    if (d < 3600) return `${Math.floor(d / 60)} min`;
    if (d < 86400) return `${Math.floor(d / 3600)} h`;
    if (d < 86400 * 7) return `${Math.floor(d / 86400)} d`;
    return new Date(sec * 1000).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
  }
  const initials = (name) => /^[\s+(\d]/.test(String(name || '')) ? '#' :
    String(name || '?')
      .replace(/[^\p{L}\p{N} ]/gu, ' ')
      .trim()
      .split(/\s+/)
      .slice(0, 2)
      .map((w) => w[0])
      .join('')
      .toUpperCase() || '?';
  // foto do contato (a mesma do WhatsApp) ou as iniciais
  const pic = (c, size = '') =>
    `<span class="pic ${size}" style="background:${avatarColor(c.name)}"><span>${esc(initials(titleOf(c)))}</span>${c.photo ? `<img src="${esc(c.photo)}" alt="" loading="lazy" referrerpolicy="no-referrer">` : ''}</span>`;
  const avatarColor = (name) => {
    const palette = ['#5b8def', '#3fb68b', '#f2a33a', '#e2626b', '#8b6fe0', '#2bb3c0', '#d36fb0', '#7a8a9e'];
    let h = 0;
    for (const ch of String(name)) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
    return palette[h % palette.length];
  };

  // ícones de traço (estilo Lucide), desenhados aqui para não depender de nada externo
  const P = {
    board: '<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M8 7v8M12 7v11M16 7v5"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
    bell: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.9 1.9 0 0 0 3.4 0"/>',
    chart: '<path d="M3 3v18h18"/><path d="M8 16v-5M13 16V8M18 16v-3"/>',
    sliders: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
    x: '<path d="M18 6 6 18M6 6l12 12"/>',
    lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
    cal: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
    warn: '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/>',
    note: '<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M8 13h8M8 17h5"/>',
    msg: '<path d="M21 11.5a8.4 8.4 0 0 1-12.6 7.3L3 21l2.2-5.4A8.5 8.5 0 1 1 21 11.5z"/>',
    pkg: '<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="m3 8 9 5 9-5M12 13v8"/>',
    level: '<path d="M4 20v-4M10 20v-8M16 20V8M22 20V4"/>',
    compass: '<circle cx="12" cy="12" r="9"/><path d="m15.5 8.5-2 5-5 2 2-5z"/>',
    phone: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/>',
    money: '<path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>',
    building: '<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M9 22v-4h6v4M8 6h.01M12 6h.01M16 6h.01M8 10h.01M12 10h.01M16 10h.01M8 14h.01M12 14h.01M16 14h.01"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    open: '<path d="M15 3h6v6M10 14 21 3M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
    inbox: '<path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.5 5.1 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.5-6.9A2 2 0 0 0 16.8 4H7.2a2 2 0 0 0-1.7 1.1z"/>',
    sync: '<path d="M21 12a9 9 0 0 1-15.5 6.2L3 16M3 12a9 9 0 0 1 15.5-6.2L21 8"/><path d="M21 3v5h-5M3 21v-5h5"/>',
    up: '<path d="M12 19V5M5 12l7-7 7 7"/>',
    trash: '<path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6M10 11v6M14 11v6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    import: '<path d="M12 3v12M7 10l5 5 5-5"/><path d="M5 21h14"/>',
    hist: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5M12 7v5l3 2"/>',
    pulse: '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
    pause: '<rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/>',
    fire: '<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.4-.5-2-1-3-1.1-2.1-.2-4.1 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.2.4-2.3 1-3.3.3 1.5 1.2 2.8 2.5 2.8z"/>',
  };
  const icon = (name, size = 16) => `<svg class="i" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[name]}</svg>`;

  const MARCA = globalThis.CRMMarca || {};
  if (MARCA.nome) host.style.setProperty('--word', `url("${MARCA.nome}")`);
  if (MARCA.simbolo) host.style.setProperty('--mark', `url("${MARCA.simbolo}")`);
  root.innerHTML = `<style>${CSS()}</style>
    <button class="fab" id="fab" data-tip="Abrir o funil">${MARCA.simbolo ? '<span class="fab-mark"></span>' : icon('board', 18)}<span>CRM</span><span class="fab-badge" id="fab-badge" hidden></span></button>
    <div class="app" id="overlay" hidden>
      <header class="top">
        <div class="brand" data-tip="Coyote Tecnologia">${MARCA.simbolo ? '<span class="logo-mark"></span><span class="logo-word" aria-label="Coyote"></span>' : `${icon('board', 20)}<span>Coyote</span>`}<span class="brand-sub">CRM</span></div>
        <div class="seg" id="who"></div>
        <label class="search">${icon('search')}<input id="search" type="search" placeholder="Buscar" aria-label="Buscar"></label>
        <div class="fx" id="fx"></div>
        <span class="spacer"></span>
        <button class="ib sync" id="btn-sync" data-tip="Atualizar agora">${icon('sync')}<span class="sync-t" id="sync-t"></span></button>
        <button class="ib upd" id="btn-upd" data-tip="Nova versão do CRM pronta: clique para atualizar" hidden>${icon('up')}</button>
        <button class="ib" id="btn-diag" data-tip="Conexão e versão: procurar atualização, pausar leitura e diário de quedas">${icon('pulse')}<span class="ib-dot" id="diag-dot" hidden></span></button>
        <button class="ib" id="btn-add" data-tip="Adicionar conversas ao funil">${icon('plus')}</button>
        <button class="ib" id="btn-att" data-tip="Só quem precisa de você">${icon('bell')}<span class="ib-badge" id="att-badge" hidden></span></button>
        <button class="ib" id="btn-panel" data-tip="Painel">${icon('chart')}</button>
        <button class="ib" id="btn-stages" data-tip="Etapas">${icon('sliders')}</button>
        <button class="ib" id="btn-team" data-tip="Equipe">${icon('users')}</button>
        <button class="ib" id="btn-close" data-tip="Voltar ao WhatsApp (Esc)">${icon('x')}</button>
      </header>
      <div id="msg" class="msg" hidden></div>
      <section id="panel" class="kpis" hidden></section>
      <main id="board" class="board"></main>
      <div class="scrim" id="scrim" hidden></div>
      <aside class="drawer" id="drawer" hidden></aside>
    </div>
    <div class="modal-bg" id="modal" hidden><div class="modal" id="modal-box"></div></div>
    <div class="toast" id="toast" hidden></div>
    <div class="tip" id="tip" hidden></div>`;
  const $ = (sel) => root.querySelector(sel);

  // dica flutuante (aparece ao passar o mouse em qualquer coisa com data-tip)
  const tipEl = $('#tip');
  root.addEventListener('mouseover', (e) => {
    const el = e.target.closest?.('[data-tip]');
    if (!el) return;
    tipEl.textContent = el.dataset.tip;
    tipEl.hidden = false;
    const r = el.getBoundingClientRect();
    const t = tipEl.getBoundingClientRect();
    let top = r.bottom + 8;
    if (top + t.height > innerHeight - 8) top = r.top - t.height - 8;
    const left = Math.min(Math.max(8, r.left + r.width / 2 - t.width / 2), innerWidth - t.width - 8);
    tipEl.style.top = `${top}px`;
    tipEl.style.left = `${left}px`;
  });
  root.addEventListener('mouseout', (e) => {
    if (e.target.closest?.('[data-tip]') && !e.relatedTarget?.closest?.('[data-tip]')) tipEl.hidden = true;
  });

  let toastTimer;
  function toast(text, error = false, action = null) {
    const el = $('#toast');
    el.innerHTML = `<span>${esc(text)}</span>${action ? `<button class="toast-act">${esc(action.label)}</button>` : ''}`;
    if (action) {
      el.querySelector('.toast-act').onclick = () => {
        el.hidden = true;
        action.fn();
      };
    }
    el.classList.toggle('error', error);
    el.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (el.hidden = true), error ? 7000 : action ? 6000 : 2600);
  }

  // ---------- cartão (compacto: nome, ícones, selos e valor) ----------
  function cardIcons(c, note) {
    const out = [];
    const step = C.stepInfo(note);
    for (const a of cardAlerts(c)) {
      if (a.kind === 'wait') out.push(`<span class="ic ${a.level}" data-tip="${esc(a.text)}">${icon('clock', 14)}</span>`);
      if (a.kind === 'stale') out.push(`<span class="ic warn" data-tip="${esc(a.text)}">${icon('moon', 14)}</span>`);
      if (a.kind === 'perda') out.push(`<span class="ic warn" data-tip="${esc(a.text)}">${icon('warn', 14)}</span>`);
    }
    if (step) out.push(`<span class="ic ${step.alert ? step.level : 'muted'}" data-tip="Próximo passo · ${esc(step.text)}">${icon('cal', 14)}</span>`);
    if (c.multi.length > 1) out.push(`<span class="ic warn" data-tip="${esc(`${c.multi.length} etapas no WhatsApp: ${c.multi.join(' + ')}. Tire a antiga na conversa.`)}">${icon('warn', 14)}</span>`);
    const last = histOf(c).find((h) => !h.auto);
    if (last) out.push(`<span class="ic muted" data-tip="${esc(`${fmtDay(last.t)} · ${last.text}${last.by ? ` (${last.by})` : ''}`)}">${icon('hist', 14)}</span>`);
    if (note.notes) out.push(`<span class="ic muted" data-tip="${esc(String(note.notes).slice(0, 160))}">${icon('note', 14)}</span>`);
    if (c.lastText) out.push(`<span class="ic muted" data-tip="${esc(c.lastText)}">${icon('msg', 14)}</span>`);
    if (c.unread) out.push(`<span class="unread" data-tip="${c.unread} não lida${c.unread > 1 ? 's' : ''}">${c.unread > 99 ? '99+' : c.unread}</span>`);
    return out.join('');
  }
  function cardBadges(c, note) {
    const out = [];
    if (note.nivel) out.push(`<span class="bd lv ${esc(note.nivel)}" data-tip="Nível ${esc(NIVEIS.find(([v]) => v === note.nivel)?.[1] || note.nivel)}">${esc(note.nivel)}</span>`);
    if (c.importado) out.push(`<span class="bd imp" data-tip="${esc(importText(c.importado))}">${icon('import', 11)}${c.importado.how === 'manual' ? 'manual' : 'importado'}</span>`);
    if (note.motivoPerda && lostOf(c)) out.push(`<span class="bd lost" data-tip="${esc(`Perdido: ${note.motivoPerda}${note.perdaObs ? ` · ${note.perdaObs}` : ''}`)}">${esc(note.motivoPerda)}</span>`);
    const pd = produtoInfo(note.produto);
    if (pd) out.push(`<span class="bd pd m-${esc(pd.marca || 'x')}" data-tip="${esc(`Produto: ${pd.v}${pd.marca ? ` · ${pd.marca}` : ''}${pd.antigo ? ' (antigo: escolha o produto certo na ficha)' : ''}`)}">${esc(pd.sigla)}</span>`);
    if (note.origem) out.push(`<span class="bd og" data-tip="Origem: ${esc(note.origem)}">${icon('compass', 11)}</span>`);
    for (const t of c.tags) out.push(`<span class="dot" style="background:${esc(t.color)}" data-tip="Etiqueta: ${esc(t.name)}"></span>`);
    return out.join('');
  }
  function cardHtml(c) {
    const note = noteOf(c);
    const r = rank(c);
    const owner = S.filter === 'all' ? `<span class="av xs own" style="background:${avatarColor(c.owner)}" data-tip="${esc(c.mine ? `${c.owner} (você)` : c.owner)}">${esc(initials(c.owner))}</span>` : '';
    const tip = note.nomeCrm && note.nomeCrm !== c.name ? ` data-tip="${esc(`No WhatsApp: ${c.name}${c.phone ? ` · ${c.phone}` : ''}`)}"` : '';
    return `<article class="card ${r === 2 ? 'r-late' : r === 1 ? 'r-warn' : ''}" data-key="${esc(c.key)}">
      <div class="c1">${pic(c)}<span class="nm"${tip}>${esc(titleOf(c))}</span><span class="tm">${esc(ago(c.lastAt))}</span><button class="rm" data-rm="${esc(c.key)}" data-tip="Remover do funil">${icon('x', 13)}</button></div>
      <div class="c2"><span class="icons">${cardIcons(c, note)}</span><span class="badges">${cardBadges(c, note)}</span>${annual(note) ? `<span class="val" data-tip="Valor estimado/ano: ${esc(money(annual(note)))}">${esc(moneyShort(annual(note)))}</span>` : ''}${owner}</div>
    </article>`;
  }

  // ---------- topo ----------
  function renderWho() {
    const who = $('#who');
    if (!S.team) {
      who.innerHTML = '';
      return;
    }
    const updated = (p) => {
      const times = S.shared.cards.filter((c) => c.owner === p && c.updatedAt).map((c) => Date.parse(c.updatedAt));
      return times.length ? ago(Math.max(...times) / 1000) : '';
    };
    const seg = (value, label, tip, person) =>
      `<button class="sg ${S.filter === value ? 'on' : ''}" data-filter="${esc(value)}" data-tip="${esc(tip)}">${person ? `<span class="av xs" style="background:${avatarColor(person)}">${esc(initials(person))}</span>` : ''}${esc(label)}</button>`;
    who.innerHTML = [
      seg('all', 'Todos', 'Funil de toda a equipe'),
      seg('me', 'Meus', `Só o seu (${me()})`, me()),
      ...teamPeople()
        .filter((p) => p !== me())
        .map((p) => seg(p, p.split(' ')[0], updated(p) ? `Funil de ${p} · atualizado há ${updated(p)}` : `Funil de ${p}`, p)),
    ].join('');
  }

  function renderFx() {
    const sel = (key, ic, label, options) => {
      const on = S.fx[key];
      return `<label class="fxs ${on ? 'on' : ''}" data-tip="${esc(label)}">${icon(ic, 14)}<select data-fx="${key}" aria-label="${esc(label)}">
        <option value="">${esc(label)}</option>
        ${options.map(([v, t]) => `<option value="${esc(v)}" ${on === v ? 'selected' : ''}>${esc(t)}</option>`).join('')}
        <option value="-" ${on === '-' ? 'selected' : ''}>Sem ${esc(label.toLowerCase())}</option>
      </select></label>`;
    };
    const any = S.fx.produto || S.fx.nivel || S.fx.origem;
    const prodOpts = MARCAS.flatMap((m) => [[`marca:${m}`, `${m} (todos)`], ...PRODUTOS.filter((p) => p.marca === m).map((p) => [p.v, `\u00a0\u00a0${p.v}`])]);
    $('#fx').innerHTML = `${sel('produto', 'pkg', 'Produto', prodOpts)}${sel('nivel', 'level', 'Nível', NIVEIS)}${sel('origem', 'compass', 'Origem', ORIGENS.map((o) => [o, o]))}${any ? `<button class="ib sm" data-fx-clear data-tip="Limpar filtros">${icon('x', 14)}</button>` : ''}`;
  }

  // ---------- quadro ----------
  function render() {
    const myAtt = myCards().filter((c) => rank(c) > 0).length;
    $('#fab-badge').hidden = myAtt === 0;
    $('#fab-badge').textContent = myAtt;
    if (!S.open) return;
    renderSync();
    renderWho();
    renderFx();
    const cols = columnsData();
    const att = S.attention ? cols.flatMap((c) => c.items).length : visibleCards().filter((c) => rank(c) > 0).length;
    $('#att-badge').hidden = att === 0;
    $('#att-badge').textContent = att;
    $('#btn-att').classList.toggle('on', S.attention);
    $('#btn-panel').classList.toggle('on', S.showPanel);
    $('#diag-dot').hidden = !S.paused;
    $('#btn-team').classList.toggle('alert', Boolean(S.team && S.shared.error));
    const problems = [];
    if (S.error) problems.push(S.error);
    if (!S.labels.length) problems.push('Nenhuma etiqueta no WhatsApp ainda. Crie Iniciando, Negociando, Em fechamento e Fechado (celular: Ferramentas → Etiquetas).');
    if (S.team && S.shared.error) problems.push(`Equipe: ${S.shared.error}`);
    $('#msg').hidden = problems.length === 0;
    $('#msg').textContent = problems.join(' · ');
    const board = $('#board');
    const scrolls = Object.fromEntries([...board.querySelectorAll('.col')].map((el) => [el.dataset.col, el.querySelector('.cards')?.scrollTop || 0]));
    const boardLeft = board.scrollLeft;
    const boardTop = board.scrollTop;
    board.innerHTML = cols
      .filter((col) => col.key === '' || col.items.length || S.stages.some((s) => norm(s.name) === col.key))
      .map((col) => {
        const total = col.items.reduce((s, c) => s + annual(noteOf(c)), 0);
        return `<section class="col" data-col="${esc(col.key)}" style="--c:${esc(col.key === '' ? '#9aa5b1' : col.color)}">
          <header class="col-h">
            <div class="col-t"><span class="col-name">${col.key === '' ? icon('inbox', 13) : ''}${esc(col.name)}</span><span class="col-n">${col.items.length}</span></div>
            <div class="col-s">${total ? esc(money(total)) : col.final ? 'final' : '&nbsp;'}</div>
          </header>
          <div class="cards">${col.items.map(cardHtml).join('') || '<div class="empty">vazio</div>'}</div>
        </section>`;
      })
      .join('');
    // continua no mesmo lugar da coluna (ex.: depois de remover um cartão ou da leitura automática)
    for (const el of board.querySelectorAll('.col')) {
      const top = scrolls[el.dataset.col];
      if (top) el.querySelector('.cards').scrollTop = top;
    }
    board.scrollLeft = boardLeft;
    board.scrollTop = boardTop;
    $('#panel').hidden = !S.showPanel;
    if (S.showPanel) renderPanel(cols);
    if (S.drawerKey && !$('#drawer').hidden) renderDrawer(S.drawerKey, true);
  }

  function renderPanel(cols) {
    const all = cols.flatMap((c) => c.items);
    const open = cols.filter((c) => c.key && !c.final).flatMap((c) => c.items);
    const lostCards = cols.filter((c) => c.lost).flatMap((c) => c.items);
    const sum = (list) => list.reduce((s, c) => s + annual(noteOf(c)), 0);
    const count = (kind) => all.filter((c) => cardAlerts(c).some((a) => a.kind === kind)).length;
    const kpi = (ic, value, label, tip, tone = '') => `<div class="kpi ${tone}" data-tip="${esc(tip)}"><span class="kpi-i">${icon(ic, 18)}</span><div><div class="kpi-v">${esc(value)}</div><div class="kpi-l">${esc(label)}</div></div></div>`;
    // list: [rótulo, nome completo, filtro da ficha]
    const group = (list) => {
      const rows = list.map(([t, full, match]) => {
        const items = open.filter((c) => match(noteOf(c)));
        return { t, full, n: items.length, total: sum(items) };
      });
      const max = Math.max(1, ...rows.map((r) => r.total || r.n));
      return rows
        .map((r) => `<div class="gr" data-tip="${esc(`${r.full || r.t}: ${r.n} em aberto · ${money(r.total) || 'R$ 0'}/ano`)}"><span class="gr-t">${esc(r.t)}</span><span class="gr-bar"><i style="width:${((r.total || r.n) / max) * 100}%"></i></span><span class="gr-v">${r.n}</span></div>`)
        .join('');
    };
    $('#panel').innerHTML = `
      ${kpi('board', open.length, 'em aberto', 'Negócios em aberto (sem contar Novos e Fechado)')}
      ${kpi('money', moneyShort(sum(open)) || 'R$ 0', 'valor/ano', `Valor estimado por ano dos negócios em aberto: ${money(sum(open)) || 'R$ 0'}`)}
      ${kpi('clock', count('wait'), 'esperando', 'Clientes esperando sua resposta há 30 min ou mais', count('wait') ? 'warn' : '')}
      ${kpi('cal', count('step'), 'passos', 'Próximos passos para hoje ou atrasados', count('step') ? 'late' : '')}
      ${kpi('moon', count('stale'), 'parados', 'Parados na mesma etapa há 7 dias ou mais')}
      ${kpi('inbox', cols[0].items.length, 'novos', 'Conversas sem etiqueta de etapa')}
      ${kpi('x', lostCards.length, 'perdidos', 'Negócios perdidos (coluna Perdidos)', lostCards.length ? 'late' : '')}
      <div class="kpi wide"><div class="kpi-l">${icon('level', 13)} Por nível</div>${group(NIVEIS.map(([v, full]) => [v, full, (n) => n.nivel === v]))}</div>
      <div class="kpi wide"><div class="kpi-l">${icon('pkg', 13)} Por marca</div>${group(MARCAS.map((m) => [m, `${m} (${PRODUTOS.filter((p) => p.marca === m).map((p) => p.v).join(', ')})`, (n) => produtoInfo(n.produto)?.marca === m]))}</div>
      <div class="kpi wide"><div class="kpi-l">${icon('warn', 13)} Motivos da perda</div>${lostCards.length ? MOTIVOS.map((m) => [m, lostCards.filter((c) => noteOf(c).motivoPerda === m).length])
        .concat([['Sem motivo', lostCards.filter((c) => !noteOf(c).motivoPerda).length]])
        .filter(([, k]) => k)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 4)
        .map(([m, k]) => `<div class="gr lg" data-tip="${esc(`${m}: ${k} perdido${k > 1 ? 's' : ''}`)}"><span class="gr-t lost-t">${esc(m)}</span><span class="gr-bar"><i style="width:${(k / lostCards.length) * 100}%;background:var(--late)"></i></span><span class="gr-v">${k}</span></div>`)
        .join('') : '<div class="muted" style="font-size:12px">Nenhum perdido ainda.</div>'}</div>`;
  }

  // ---------- painel lateral do cartão (detalhes + ficha) ----------
  const findCard = (key) => visibleCards().find((c) => c.key === key) || [...myCards(), ...teamCards()].find((c) => c.key === key);
  function openDrawer(key) {
    S.drawerKey = key;
    $('#drawer').hidden = false;
    $('#scrim').hidden = false;
    renderDrawer(key);
  }
  function closeDrawer() {
    S.drawerKey = null;
    $('#drawer').hidden = true;
    $('#scrim').hidden = true;
  }
  function renderDrawer(key, soft = false) {
    const c = findCard(key);
    if (!c) return closeDrawer();
    // não atrapalha quem está digitando ou tem alterações ainda não salvas
    if (soft && (S.drawerDirty || (root.activeElement && $('#drawer').contains(root.activeElement)))) return;
    S.drawerDirty = false;
    const n = noteOf(c);
    const shared = Boolean(S.team);
    const step = C.stepInfo(n);
    const opts = (list, cur, ph) => [`<option value="">${esc(ph)}</option>`, ...list.map(([v, t]) => `<option value="${esc(v)}" ${cur === v ? 'selected' : ''}>${esc(t)}</option>`)].join('');
    const pairs = (arr) => arr.map((v) => [v, v]);
    const alerts = [...cardAlerts(c).filter((a) => a.kind !== 'step'), ...(step ? [{ ...step, kind: 'step' }] : [])];
    const alertIcon = { wait: 'clock', stale: 'moon', step: 'cal' };
    const row = (ic, label, field) => `<label class="fr"><span class="frl">${icon(ic, 14)}${esc(label)}</span>${field}</label>`;
    $('#drawer').innerHTML = `
      <header class="dw-h">
        ${pic(c, 'lg')}
        <div class="dw-t"><div class="dw-name">${esc(titleOf(c))}</div><div class="dw-sub">${c.phone ? `${icon('phone', 12)} ${esc(c.phone)}` : ''}${n.nomeCrm && n.nomeCrm !== c.name ? `<span class="sep">·</span>${icon('msg', 12)} ${esc(c.name)}` : ''}${c.waName ? `<span class="sep">·</span><span data-tip="Nome que a pessoa usa no WhatsApp">~${esc(c.waName)}</span>` : ''}</div></div>
        <button class="ib" data-dw-close data-tip="Fechar">${icon('x')}</button>
      </header>
      <div class="dw-pills">
        <span class="pill-stage" style="--c:${esc(c.stageColor || '#9aa5b1')}">${esc(c.stageName || 'Novos')}</span>
        ${!c.mine || S.team ? `<span class="pill-owner"><span class="av xs" style="background:${avatarColor(c.owner)}">${esc(initials(c.owner))}</span>${esc(c.owner)}</span>` : ''}
        ${c.mine ? `<button class="btn primary sm" data-open="${esc(c.id)}">${icon('open', 14)} Abrir conversa</button>` : ''}
      </div>
      ${alerts.length || c.multi.length > 1 ? `<div class="dw-alerts">${alerts.map((a) => `<div class="al ${a.level === 'info' ? 'muted' : a.level}">${icon(alertIcon[a.kind] || 'warn', 14)}<span>${esc(a.kind === 'step' ? `Próximo passo · ${a.text}` : a.text)}</span></div>`).join('')}${c.multi.length > 1 ? `<div class="al warn">${icon('warn', 14)}<span>${esc(`${c.multi.length} etapas no WhatsApp: ${c.multi.join(' + ')}`)}</span></div>` : ''}</div>` : ''}
      ${convHtml(c)}
      <div class="dw-hist">
        <div class="sec">${icon('hist', 13)} Histórico</div>
        <input id="h-new" class="h-in" placeholder="O que aconteceu? Ex.: mandei a proposta (Enter registra)" maxlength="300">
        <ul class="hist">${histOf(c)
          .slice(0, 30)
          .map((h) => `<li class="${h.auto ? 'auto' : ''}"><span class="h-d">${esc(fmtDay(h.t))}</span><span class="h-t">${esc(h.text)}</span>${h.by ? `<span class="h-b">${esc(h.by)}</span>` : ''}</li>`)
          .join('') || '<li class="muted">Nada registrado ainda.</li>'}</ul>
      </div>
      <form class="dw-form" id="dw-form" autocomplete="off">
        <div class="sec">Ficha</div>
        ${row('user', 'Nome no CRM', `<input id="f-nomeCrm" value="${esc(n.nomeCrm ?? '')}" placeholder="${esc(c.name)} (ex.: nome da empresa)">`)}
        <div class="sec">Classificação</div>
        ${row('pkg', 'Produto', `<select id="f-produto"><option value="">—</option>${MARCAS.map((m) => `<optgroup label="${esc(m)}">${PRODUTOS.filter((p) => p.marca === m).map((p) => `<option value="${esc(p.v)}" ${n.produto === p.v ? 'selected' : ''}>${esc(p.v)}</option>`).join('')}</optgroup>`).join('')}${produtoInfo(n.produto)?.antigo ? `<option value="${esc(n.produto)}" selected>${esc(n.produto)} (antigo)</option>` : ''}</select>`)}
        ${row('level', 'Nível', `<select id="f-nivel">${opts(NIVEIS, n.nivel, '—')}</select>`)}
        ${row('compass', 'Origem', `<select id="f-origem">${opts(pairs(ORIGENS), n.origem, '—')}</select>`)}
        <div class="sec">Próximo passo</div>
        ${row('cal', 'O quê', `<input id="f-nextStep" value="${esc(n.nextStep ?? '')}" placeholder="Ex.: ligar para o síndico">`)}
        ${row('clock', 'Quando', `<input id="f-nextDate" type="date" value="${esc(n.nextDate ?? '')}">`)}
        <div class="sec">Negócio</div>
        ${row('money', 'Valor/ano', `<input id="f-value" type="number" step="0.01" min="0" value="${esc(annual(n) || '')}" placeholder="R$ em 12 meses">`)}
        ${row('building', 'Local', `<select id="f-tipoLocal">${opts(pairs(TIPOS), n.tipoLocal, '—')}</select>`)}
        ${row('users', 'Pessoas', `<input id="f-tamanho" type="number" min="0" value="${esc(n.tamanho ?? '')}" placeholder="Moradores / funcionários">`)}
        ${row('user', 'Decisor', `<input id="f-decisor" value="${esc(n.decisor ?? '')}" placeholder="Quem decide">`)}
        ${row('fire', 'Concorrente', `<input id="f-concorrente" value="${esc(n.concorrente ?? '')}" placeholder="Quem já atende">`)}
        <div class="sec">Perda</div>
        ${row('warn', 'Motivo', `<select id="f-motivoPerda">${opts(pairs(MOTIVOS), n.motivoPerda, '—')}${n.motivoPerda && !MOTIVOS.includes(n.motivoPerda) ? `<option selected>${esc(n.motivoPerda)}</option>` : ''}</select>`)}
        ${row('note', 'Detalhe', `<input id="f-perdaObs" value="${esc(n.perdaObs ?? '')}" placeholder="Ex.: achou caro, fechou com a X">`)}
        <div class="perda-act">${(() => {
          const lost = lostOf(c);
          if (!lost) return `<button type="button" class="btn ghost danger sm" id="f-perder">${icon('x', 13)} Marcar como perdido</button><span class="muted">vai para a coluna Perdidos (só no CRM)</span>`;
          if (lost.via === 'etiqueta') return `<span class="lost-tag">${icon('warn', 13)} Perdido pela etiqueta do WhatsApp</span>${n.motivoPerda ? '' : '<span class="muted">escolha o motivo e salve</span>'}`;
          return `<span class="lost-tag">${icon('warn', 13)} Perdido em ${esc(fmtDay(lost.at))}</span><button type="button" class="btn sm" id="f-reabrir">Reabrir</button>`;
        })()}</div>
        <div class="sec">Observações</div>
        <textarea id="f-notes" class="ta" rows="4" placeholder="Anote o que importa…">${esc(n.notes ?? '')}</textarea>
      </form>
      <footer class="dw-f">
        <span class="muted" data-tip="${shared ? 'A ficha fica na planilha da equipe: todos veem. Nada vai para o WhatsApp.' : 'A ficha fica só neste Chrome. Nada vai para o WhatsApp.'}">${icon(shared ? 'users' : 'lock', 13)} ${shared ? 'ficha da equipe' : 'só neste Chrome'}${n.by ? ` · por ${esc(n.by)}` : ''}</span>
        <span class="dw-actions"><button class="btn ghost danger" id="f-remove" data-tip="Tira esta conversa do funil (só no CRM, nada muda no WhatsApp). Volta sozinha se mudar de etapa no WhatsApp.">${icon('trash', 14)} Remover</button><button class="btn primary" id="f-save">Salvar</button></span>
      </footer>`;
    $('#f-remove').onclick = () => removeCard(c.key);
    if ($('#f-perder')) $('#f-perder').onclick = () => markLost(c);
    if ($('#f-reabrir')) $('#f-reabrir').onclick = () => reopenLost(c.key);
    $('#h-new').onkeydown = (e) => {
      if (e.key !== 'Enter' || !e.target.value.trim()) return;
      e.preventDefault();
      addHist(c, e.target.value.trim());
    };
    $('#f-save').onclick = () => saveFicha(c);
  }

  async function saveFicha(c) {
    const ficha = {};
    for (const f of FICHA) {
      const v = $(`#f-${f}`).value.trim();
      ficha[f] = ['value', 'tamanho'].includes(f) ? (v === '' ? null : Number(v)) : v;
    }
    ficha.valorPeriodo = 'ano';
    ficha.hist = noteOf(c).hist || [];
    ficha.perda = noteOf(c).perda || null;
    $('#f-save').disabled = true;
    const ok = await persistNote(c, ficha);
    $('#f-save').disabled = false;
    if (!ok) return;
    root.activeElement?.blur?.();
    S.drawerDirty = false;
    closeDrawer();
    render();
    toast('Ficha salva');
  }

  // últimas mensagens que apareceram na tela (conversa aberta) ou a prévia da lista
  function convHtml(c) {
    const conv = c.conv;
    if (conv?.lines?.length) {
      return `<div class="dw-conv"><div class="sec">${icon('msg', 13)} Últimas mensagens <span class="muted">· vistas ${esc(ago(conv.at / 1000) === 'agora' ? 'agora' : `há ${ago(conv.at / 1000)}`)}</span></div>${conv.lines
        .map((l) => `<div class="cv ${l.who === 'Você' ? 'me' : ''}"><span class="cv-w">${esc(l.who || 'Cliente')}${l.when ? ` · ${esc(l.when.split(',')[0])}` : ''}</span><span>${esc(l.text)}</span></div>`)
        .join('')}</div>`;
    }
    if (c.lastText) return `<div class="dw-last">${icon('msg', 14)}<span>${esc(c.lastText)}</span><span class="tm">${esc(ago(c.lastAt))}</span></div>`;
    if (c.semConversa) return `<div class="dw-last muted">${icon('msg', 14)}<span class="muted">Esta conversa ainda não está no WhatsApp Web (ele só traz as mais recentes). Clique em <b>Abrir conversa</b> e depois na conversa: ela passa a aparecer aqui.</span></div>`;
    return c.mine ? `<div class="dw-last muted">${icon('msg', 14)}<span class="muted">Abra a conversa no WhatsApp (ou role a lista até ela) e as últimas mensagens aparecem aqui.</span></div>` : '';
  }

  // ---------- histórico do cliente ----------
  const importText = (i) => `${i.how === 'manual' ? 'Adicionado à mão' : 'Importado para o funil'} por ${!i.by || i.by === me() ? 'você' : i.by} em ${fmtDay(i.at)}`;
  const fmtDay = (t) => new Date(t).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
  function histOf(c) {
    const own = (noteOf(c).hist || []).map((h) => ({ ...h }));
    const since = c.mine ? S.cards[c.id]?.since || {} : {};
    const labelName = new Map(S.labels.map((l) => [String(l.id), l.name]));
    const auto = Object.entries(since)
      .filter(([id]) => labelName.has(id))
      .map(([id, t]) => ({ t, text: `Entrou em ${labelName.get(id)}`, auto: true }));
    if (c.importado) auto.push({ t: c.importado.at, text: importText(c.importado).replace(/ em \d\d\/\d\d$/, ''), auto: true });
    return [...own, ...auto].sort((a, b) => b.t - a.t);
  }
  // grava a ficha (neste Chrome e, com equipe, na planilha)
  async function persistNote(c, ficha) {
    if (c.mine) {
      S.cards[c.id] = { ...(S.cards[c.id] || {}), ...ficha };
      save.cards();
    }
    if (S.team) {
      const r = await teamCall({ acao: 'anotar', dono: c.owner, id: c.id, nome: ficha.nomeCrm || c.name, ficha, pessoa: me() });
      if (!r?.ok) {
        toast(`Não consegui salvar na planilha: ${r?.erro || 'erro'}`, true);
        return false;
      }
      S.shared.notes.set(`${c.owner}|${c.id}`, { ...ficha, owner: c.owner, id: c.id, by: me() });
    }
    return true;
  }
  const fichaOf = (n) => ({ ...Object.fromEntries(FICHA.map((f) => [f, n[f] ?? (['value', 'tamanho'].includes(f) ? null : '')])), valorPeriodo: n.valorPeriodo || '', hist: n.hist || [], perda: n.perda || null });
  // lê os campos da ficha aberta (para salvar junto ao marcar ou reabrir)
  function fichaFromForm(c) {
    const ficha = {};
    for (const f of FICHA) {
      const v = $(`#f-${f}`).value.trim();
      ficha[f] = ['value', 'tamanho'].includes(f) ? (v === '' ? null : Number(v)) : v;
    }
    const n = noteOf(c);
    return { ...ficha, valorPeriodo: 'ano', hist: n.hist || [], perda: n.perda || null };
  }
  async function markLost(c) {
    const ficha = fichaFromForm(c);
    if (!ficha.motivoPerda) {
      $('#f-motivoPerda').focus();
      return toast('Escolha o motivo da perda antes', true);
    }
    ficha.perda = { at: Date.now(), stage: c.stageName || '', by: me() };
    ficha.hist = [...ficha.hist, { t: Date.now(), text: `Perdido: ${ficha.motivoPerda}${ficha.perdaObs ? ` (${ficha.perdaObs})` : ''}`, by: me() }].slice(-60);
    if (!(await persistNote(c, ficha))) return;
    S.drawerDirty = false;
    closeDrawer();
    render();
    publish(true);
    toast(`"${titleOf(c)}" foi para Perdidos`, false, { label: 'Desfazer', fn: () => reopenLost(c.key) });
  }
  async function reopenLost(key) {
    const c = findCard(key);
    if (!c) return;
    const n = noteOf(c);
    const ficha = { ...fichaOf(n), perda: null, hist: [...(n.hist || []), { t: Date.now(), text: 'Reaberto', by: me() }].slice(-60) };
    if (!(await persistNote(c, ficha))) return;
    S.drawerDirty = false;
    if (S.drawerKey === key) renderDrawer(key);
    render();
    publish(true);
    toast('Negócio reaberto');
  }
  async function addHist(c, text) {
    const n = noteOf(c);
    const ficha = { ...fichaOf(n), hist: [...(n.hist || []), { t: Date.now(), text: text.slice(0, 300), by: me() }].slice(-60) };
    if (!(await persistNote(c, ficha))) return;
    S.drawerDirty = false;
    renderDrawer(c.key);
    render();
    toast('Registrado no histórico');
  }

  // ---------- remover do funil (só no CRM; a conversa continua no WhatsApp) ----------
  function removeCard(key) {
    const c = findCard(key);
    if (!c) return;
    S.removed[key] = { name: titleOf(c), stage: c.stageName || '', at: Date.now() };
    if (c.mine && S.added[c.id]) {
      delete S.added[c.id];
      save.added();
    }
    if (c.mine && S.manual[c.id]) {
      delete S.manual[c.id];
      save.manual();
    }
    save.removed();
    if (S.drawerKey === key) closeDrawer();
    render();
    if (c.mine) publish(true);
    toast(`"${titleOf(c)}" saiu do funil`, false, { label: 'Desfazer', fn: () => restoreCard(key) });
  }
  function restoreCard(key) {
    delete S.removed[key];
    save.removed();
    render();
    publish(true);
  }

  // ---------- adicionar ao funil (conversas antigas, arquivadas ou removidas) ----------
  function openAdd() {
    const inFunnel = new Set(myCards().map((c) => c.id));
    const pool = [...S.chats.filter((c) => !inFunnel.has(c.id)).sort((a, b) => b.lastAt - a.lastAt), ...S.contacts.filter((c) => !inFunnel.has(c.id)).sort((a, b) => a.name.localeCompare(b.name))];
    const picked = new Set();
    const rowsHtml = (q) => {
      const nq = norm(q);
      const list = pool.filter((c) => !nq || norm([c.name, c.waName, c.phone, c.phone.replace(/\D/g, '')].join(' ')).includes(nq)).slice(0, 150);
      return (
        list
          .map(
            (c) => `<li><label class="ad"><input type="checkbox" data-pick="${esc(c.id)}" ${picked.has(c.id) ? 'checked' : ''}>${pic(c)}<span class="ad-t"><b>${esc(c.name)}</b><span class="muted">${esc([c.phone, c.waName && `~${c.waName}`].filter(Boolean).join(' · '))}</span></span><span class="muted ad-w">${c.semConversa ? 'contato salvo' : `${S.removed[c.id] ? 'removida · ' : c.archived ? 'arquivada · ' : ''}${esc(ago(c.lastAt))}`}</span></label></li>`,
          )
          .join('') || '<li class="muted">Nenhuma conversa encontrada.</li>'
      );
    };
    openModal(`<header class="md-h">${icon('plus')}<h2>Adicionar ao funil</h2><button class="ib" data-close>${icon('x')}</button></header>
      <p class="muted"><span>Conversas que não estão no funil (mais antigas que 1 mês, arquivadas ou removidas) e, no fim da lista, contatos salvos no celular. Elas entram em <b>Novos</b>; para mudar de etapa, coloque a etiqueta no WhatsApp.</span></p>
      <label class="search wide">${icon('search')}<input id="ad-q" type="search" placeholder="Buscar por nome ou número"></label>
      <ul class="adds" id="ad-list">${rowsHtml('')}</ul>
      <details class="ad-man"><summary>${icon('user', 13)} Não está na lista? Adicionar à mão</summary>
        <div class="ad-man-f"><input id="am-name" placeholder="Nome (ex.: Hotel Lago Sul)"><input id="am-phone" placeholder="WhatsApp com DDD (ex.: 61 99999-0000)"><button class="btn" id="am-ok">${icon('plus', 14)} Adicionar</button></div>
      </details>
      <div class="row"><span class="muted" id="ad-n">Nenhuma selecionada</span><span class="spacer"></span><button class="btn" data-close>Cancelar</button><button class="btn primary" id="ad-ok" disabled>Adicionar</button></div>`);
    const upd = () => {
      $('#ad-n').textContent = picked.size ? `${picked.size} selecionada${picked.size > 1 ? 's' : ''}` : 'Nenhuma selecionada';
      $('#ad-ok').disabled = !picked.size;
      $('#ad-ok').textContent = picked.size ? `Adicionar (${picked.size})` : 'Adicionar';
    };
    $('#ad-q').oninput = (e) => ($('#ad-list').innerHTML = rowsHtml(e.target.value));
    $('#ad-list').onchange = (e) => {
      const id = e.target.dataset.pick;
      if (!id) return;
      e.target.checked ? picked.add(id) : picked.delete(id);
      upd();
    };
    $('#ad-ok').onclick = () => {
      for (const id of picked) {
        S.added[id] = { at: Date.now(), how: 'lista', by: me() };
        delete S.removed[id];
      }
      save.added();
      save.removed();
      closeModal();
      render();
      publish(true);
      toast(`${picked.size} conversa${picked.size > 1 ? 's' : ''} no funil`);
    };
    $('#am-ok').onclick = () => {
      let d = $('#am-phone').value.replace(/\D/g, '');
      if (d.length === 10 || d.length === 11) d = `55${d}`;
      if (d.length < 12 || d.length > 15) return toast('Confira o número: DDD + número (ex.: 61 99999-0000)', true);
      const id = `${d}@c.us`;
      const name = $('#am-name').value.trim();
      if (!S.chats.some((c) => c.id === id) && !S.contacts.some((c) => c.id === id)) {
        S.manual[id] = { name, at: Date.now() };
        save.manual();
      }
      S.added[id] = { at: Date.now(), how: 'manual', by: me() };
      delete S.removed[id];
      save.added();
      save.removed();
      if (name) {
        // o nome digitado vira o "Nome no CRM"
        S.cards[id] = { ...(S.cards[id] || {}), nomeCrm: S.cards[id]?.nomeCrm || name };
        save.cards();
      }
      closeModal();
      render();
      publish(true);
      toast(`${name || C.formatPhone(id)} entrou em Novos`);
    };
    $('#ad-q').focus();
  }

  // ---------- janelas (etapas e equipe) ----------
  function openModal(html) {
    $('#modal-box').innerHTML = html;
    $('#modal').hidden = false;
  }
  const closeModal = () => ($('#modal').hidden = true);

  function editStages() {
    const stageIds = new Set(S.stages.map((s) => s.id));
    const finals = new Set(S.stages.filter((s) => s.final).map((s) => s.id));
    const order = [...S.stages.map((s) => s.id), ...S.labels.map((l) => String(l.id)).filter((id) => !stageIds.has(id))];
    const byId = new Map(S.labels.map((l) => [String(l.id), l]));
    const rows = () =>
      order
        .map(
          (id, i) => `<li data-id="${esc(id)}"><i class="sw" style="background:${esc(byId.get(id)?.hexColor || '#ccc')}"></i><span class="lname">${esc(byId.get(id)?.name)}</span>
          <label class="tg" data-tip="Vira coluna no funil"><input type="checkbox" class="is-stage" ${stageIds.has(id) ? 'checked' : ''}><span>Etapa</span></label>
          <label class="tg" data-tip="Fim de linha: não avisa quando parado"><input type="checkbox" class="is-final" ${finals.has(id) ? 'checked' : ''}><span>Final</span></label>
          <button type="button" class="ib sm" data-up ${i === 0 ? 'disabled' : ''} data-tip="Subir">▲</button><button type="button" class="ib sm" data-down ${i === order.length - 1 ? 'disabled' : ''} data-tip="Descer">▼</button></li>`,
        )
        .join('') || '<li class="muted">Nenhuma etiqueta. Crie no celular: Ferramentas → Etiquetas.</li>';
    openModal(`<header class="md-h">${icon('sliders')}<h2>Etapas</h2><button class="ib" data-close>${icon('x')}</button></header>
      <p class="muted">As etapas são as etiquetas do WhatsApp (crie e renomeie no celular). Aqui você escolhe quais viram coluna e a ordem.</p>
      <ul class="stages" id="st-list">${rows()}</ul>
      ${Object.keys(S.removed).length ? `<h3 class="md-sub">${icon('trash', 14)} Removidos do funil</h3><ul class="stages removed">${Object.entries(S.removed)
        .sort((a, b) => b[1].at - a[1].at)
        .map(([k, r]) => `<li><span class="lname">${esc(r.name)}</span><span class="muted">${esc(r.stage || 'Novos')}</span><button type="button" class="btn sm" data-restore="${esc(k)}">Voltar ao funil</button></li>`)
        .join('')}</ul>` : ''}
      <div class="row"><span class="spacer"></span><button class="btn" data-close>Cancelar</button><button class="btn primary" id="st-save">Salvar</button></div>`);
    const list = $('#st-list');
    list.onclick = (e) => {
      const li = e.target.closest('li[data-id]');
      if (!li) return;
      const i = order.indexOf(li.dataset.id);
      const j = e.target.closest('[data-up]') ? i - 1 : e.target.closest('[data-down]') ? i + 1 : -1;
      if (j < 0 || j >= order.length) return;
      [order[i], order[j]] = [order[j], order[i]];
      list.innerHTML = rows();
    };
    list.onchange = (e) => {
      const id = e.target.closest('li')?.dataset.id;
      if (e.target.classList.contains('is-stage')) e.target.checked ? stageIds.add(id) : stageIds.delete(id);
      if (e.target.classList.contains('is-final')) e.target.checked ? finals.add(id) : finals.delete(id);
    };
    $('#st-save').onclick = () => {
      S.settings = { ...S.settings, stageIds: order.filter((id) => stageIds.has(id)), finalIds: [...finals], knownLabelIds: S.labels.map((l) => String(l.id)) };
      save.settings();
      S.stages = C.stageList(S.labels, S.settings);
      closeModal();
      render();
      publish(true);
      toast('Etapas salvas');
    };
  }

  function editTeam() {
    const t = S.team || {};
    openModal(`<header class="md-h">${icon('users')}<h2>Equipe</h2><button class="ib" data-close>${icon('x')}</button></header>
      <p class="muted">Junte o seu funil com o de outras pessoas (ex.: Bianca) usando uma planilha Google como ponto de encontro. Nada disso mexe no WhatsApp.</p>
      <label class="fl">Seu nome<input id="t-name" value="${esc(t.pessoa || '')}" placeholder="Pedro"></label>
      <label class="fl">Endereço da planilha<input id="t-url" value="${esc(t.url || '')}" placeholder="https://script.google.com/macros/s/.../exec"></label>
      <label class="fl">Código da equipe<input id="t-code" value="${esc(t.codigo || '')}" placeholder="o mesmo do Apps Script"></label>
      <div class="row">${S.team ? '<button class="btn" id="t-off">Desligar</button>' : ''}<span class="spacer"></span><button class="btn" data-close>Cancelar</button><button class="btn primary" id="t-save">Testar e salvar</button></div>`);
    if ($('#t-off'))
      $('#t-off').onclick = () => {
        S.team = null;
        S.filter = 'me';
        S.shared = { cards: [], notes: new Map(), at: 0, error: null };
        save.team();
        save.filter();
        closeModal();
        render();
        toast('Equipe desligada');
      };
    $('#t-save').onclick = async () => {
      const team = { pessoa: $('#t-name').value.trim(), url: $('#t-url').value.trim(), codigo: $('#t-code').value.trim() };
      if (!team.pessoa || !team.url || !team.codigo) return toast('Preencha nome, endereço e código.', true);
      const before = S.team;
      S.team = team;
      $('#t-save').disabled = true;
      const r = await teamCall({ acao: 'teste' });
      $('#t-save').disabled = false;
      if (!r?.ok) {
        S.team = before;
        return toast(`Não consegui falar com a planilha: ${r?.erro || 'erro'}`, true);
      }
      save.team();
      if (S.filter === 'me') S.filter = 'all';
      save.filter();
      closeModal();
      toast('Equipe conectada');
      await publish(true);
      await pull();
      await uploadLocalFichas();
    };
  }

  // ---------- eventos ----------
  function setOpen(open) {
    S.open = open;
    $('#overlay').hidden = !open;
    tipEl.hidden = true;
    if (!open) closeDrawer();
    if (open) {
      if (Date.now() - S.readAt > 60 * 1000) refresh();
      else render();
      pull();
    }
  }
  $('#fab').onclick = () => setOpen(!S.open);
  for (const ev of ['input', 'change']) $('#drawer').addEventListener(ev, () => (S.drawerDirty = true));
  $('#btn-sync').onclick = () => refresh();
  // botão Atualizar: mostra há quanto tempo foi a última leitura
  function renderSync() {
    const b = $('#btn-sync');
    b.classList.toggle('spin', S.reading);
    $('#sync-t').textContent = S.reading ? '' : S.readAt ? ago(S.readAt / 1000) : '';
    const quando = ago(S.readAt / 1000) === 'agora' ? 'agora mesmo' : `há ${ago(S.readAt / 1000)}`;
    b.dataset.tip = S.reading ? 'Lendo o WhatsApp…' : S.paused ? `Leitura automática pausada. Lido ${quando}: clique para ler agora.` : S.readAt ? `Lido ${quando}. Atualiza sozinho em poucos segundos quando algo muda.` : 'Ler o WhatsApp agora';
  }
  $('#btn-close').onclick = () => setOpen(false);
  $('#btn-att').onclick = () => {
    S.attention = !S.attention;
    render();
  };
  $('#btn-panel').onclick = () => {
    S.showPanel = !S.showPanel;
    render();
  };
  $('#btn-stages').onclick = editStages;
  $('#btn-diag').onclick = openDiag;
  $('#btn-add').onclick = openAdd;
  $('#btn-team').onclick = editTeam;
  $('#search').oninput = (e) => {
    S.search = e.target.value;
    render();
  };
  root.addEventListener('change', (e) => {
    const k = e.target.dataset?.fx;
    if (!k) return;
    S.fx[k] = e.target.value;
    render();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape' || !S.open) return;
    if (!$('#modal').hidden) return closeModal();
    if (!$('#drawer').hidden) return closeDrawer();
    setOpen(false);
  });

  // "Abrir conversa": escreve o número (ou nome) na busca do próprio WhatsApp,
  // igual a você digitar. Aí é só clicar na conversa. Nada é enviado.
  const openChat = (key) => {
    const c = findCard(key);
    if (!c) return;
    const digits = (c.phone || '').replace(/\D/g, '');
    const text = digits ? digits.replace(/^55/, '') : c.name;
    setOpen(false);
    const box = document.querySelector('#side [contenteditable="true"], #side input[type="text"], #side input:not([type]), [data-testid="chat-list-search"] [contenteditable="true"]');
    if (box) {
      box.focus();
      try {
        document.execCommand('selectAll', false, null);
        document.execCommand('insertText', false, text);
        return toast('Procurei na busca do WhatsApp: clique na conversa');
      } catch {}
    }
    navigator.clipboard?.writeText(text).catch(() => {});
    toast(`Copiei "${text}": cole na busca do WhatsApp (Ctrl+V)`);
  };
  root.addEventListener('error', (e) => {
    if (e.target.tagName === 'IMG' && e.target.closest('.pic')) e.target.remove();
  }, true);
  root.addEventListener('click', (e) => {
    if (e.target.closest('[data-close]') || e.target.id === 'modal') return closeModal();
    if (e.target.closest('[data-dw-close]') || e.target.id === 'scrim') return closeDrawer();
    if (e.target.closest('[data-fx-clear]')) {
      S.fx = { produto: '', nivel: '', origem: '' };
      return render();
    }
    const seg = e.target.closest('[data-filter]');
    if (seg) {
      S.filter = seg.dataset.filter;
      save.filter();
      render();
      if (S.filter !== 'me') pull();
      return;
    }
    const rm = e.target.closest('[data-rm]');
    if (rm) return removeCard(rm.dataset.rm);
    const back = e.target.closest('[data-restore]');
    if (back) {
      restoreCard(back.dataset.restore);
      return back.closest('li')?.remove();
    }
    const openBtn = e.target.closest('[data-open]');
    if (openBtn) return openChat(openBtn.dataset.open);
    const card = e.target.closest('.card');
    if (card) openDrawer(card.dataset.key);
  });

  // tema claro/escuro igual ao do WhatsApp Web
  const syncTheme = () => host.setAttribute('data-theme', document.body?.classList.contains('dark') ? 'dark' : 'light');

  // ---------- início ----------
  async function start() {
    S.settings = (await storage.get('crm:settings')) || {};
    if (!S.settings.novosDesde) {
      S.settings.novosDesde = Date.now() - 30 * 86400000;
      save.settings();
    }
    S.cards = (await storage.get('crm:cards')) || {};
    S.team = (await storage.get('crm:team')) || null;
    S.filter = (S.team && (await storage.get('crm:filter'))) || 'me';
    S.removed = (await storage.get('crm:removidos')) || {};
    S.added = (await storage.get('crm:adicionados')) || {};
    S.known = (await storage.get('crm:conhecidos')) || null;
    S.manual = (await storage.get('crm:manuais')) || {};
    S.screen = { prev: {}, conv: {}, ...((await storage.get('crm:tela')) || {}) };
    S.diag = (await storage.get('crm:diag')) || [];
    S.paused = Boolean(await storage.get('crm:pausado'));
    const nav = performance.getEntriesByType?.('navigation')?.[0]?.type;
    note('inicio', `WhatsApp Web aberto${nav === 'reload' ? ' (a página foi RECARREGADA)' : ''} · CRM ${ext?.runtime.getManifest().version || 'teste'}${S.paused ? ' · leitura automática pausada' : ''}`);
    window.addEventListener('offline', () => note('rede', 'Internet do computador caiu'));
    window.addEventListener('online', () => note('rede', 'Internet do computador voltou'));
    document.body.appendChild(host);
    syncTheme();
    new MutationObserver(syncTheme).observe(document.body, { attributes: true, attributeFilter: ['class'] });
    await refresh();
    setInterval(() => {
      if (ext && !chrome.runtime?.id) {
        if (S.error !== RECARREGAR) {
          S.error = RECARREGAR;
          S.paused = true;
          render();
          toast(RECARREGAR, true);
        }
        return;
      }
      watchConnection();
      watchList();
      if (!document.hidden) captureScreen();
      if (canAutoRead() && Date.now() - S.readAt >= (S.open ? LER_ABERTO : LER_FECHADO)) refresh();
    }, 5000);
    watchList();
    document.addEventListener('visibilitychange', () => {
      if (canAutoRead() && Date.now() - S.readAt > LER_ABERTO) refresh();
    });
    setInterval(() => (S.open ? render() : null), 60 * 1000);
    // equipe: manda o seu funil e busca o dos outros a cada 2 minutos
    setInterval(() => {
      publish();
      if (S.open) pull();
    }, 2 * 60 * 1000);
    publish(true);
    checkUpdate();
    setInterval(checkUpdate, 30 * 60 * 1000);
  }

  // ---------- conexão: leitura automática só com o WhatsApp estável ----------
  // Não lê com a aba escondida, com o WhatsApp sem a lista de conversas
  // (desconectado, recarregando ou sincronizando) nem nos 30 s depois que ela volta.
  let paneSeen = true;
  let paneBackAt = 0;
  let paneGoneAt = 0;
  let qrSeen = false;
  function canAutoRead() {
    if (S.paused || document.hidden) return false;
    if (!document.querySelector('#pane-side')) return false;
    return Date.now() - paneBackAt > 30 * 1000;
  }
  function watchConnection() {
    const pane = Boolean(document.querySelector('#pane-side'));
    const lastRead = S.readAt ? `${Math.round((Date.now() - S.readAt) / 1000)} s antes` : 'nenhuma ainda';
    if (paneSeen && !pane) {
      paneGoneAt = Date.now();
      note('queda', `A lista de conversas sumiu (WhatsApp caiu ou recarregou). Última leitura do CRM: ${lastRead}`);
    }
    if (!paneSeen && pane) {
      paneBackAt = Date.now();
      note('volta', `O WhatsApp voltou depois de ${Math.max(1, Math.round((Date.now() - paneGoneAt) / 1000))} s`);
    }
    paneSeen = pane;
    const qr = Boolean(document.querySelector('canvas[aria-label*="QR" i], div[data-ref] canvas'));
    if (qr && !qrSeen) note('qr', 'Apareceu o QR code: o WhatsApp saiu da conta (aparelho desconectado)');
    qrSeen = qr;
  }

  // ---------- diário de conexão ----------
  let diagTimer;
  function note(type, text) {
    S.diag.push({ t: Date.now(), type, text });
    if (S.diag.length > 300) S.diag = S.diag.slice(-300);
    clearTimeout(diagTimer);
    diagTimer = setTimeout(save.diag, 1000);
    if (!$('#modal').hidden && $('#diag-list')) $('#diag-list').innerHTML = diagRows();
  }
  const fmtTime = (t) => new Date(t).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const DIAG_ICON = { inicio: 'open', queda: 'warn', volta: 'sync', qr: 'lock', rede: 'pulse', leitura: 'clock', erro: 'warn' };
  const diagRows = () =>
    S.diag
      .slice(-60)
      .reverse()
      .map((d) => `<li class="dg ${esc(d.type)}">${icon(DIAG_ICON[d.type] || 'pulse', 13)}<span class="dg-t">${esc(fmtTime(d.t))}</span><span>${esc(d.text)}</span></li>`)
      .join('') || '<li class="muted">Nada registrado ainda.</li>';
  function openDiag() {
    const quedas = S.diag.filter((d) => d.type === 'queda' || d.type === 'qr');
    openModal(`<header class="md-h">${icon('pulse')}<h2>Conexão e versão</h2><button class="ib" data-close>${icon('x')}</button></header>
      <div class="diag-box"><div><strong>Versão do CRM:</strong> <span id="vs-txt">${esc(ext?.runtime.getManifest().version || 'teste')}</span></div><button class="btn" id="vs-btn">${icon('sync', 14)} Procurar atualização</button></div>
      <p class="muted">${icon('lock', 12)} Modo espelho: o CRM só lê a cópia das conversas que o WhatsApp Web guarda no computador. Não roda nada dentro do WhatsApp e nunca mexe nele.</p>
      <div class="diag-box">
        <div><strong>Leitura automática:</strong> ${S.paused ? 'pausada (só lê quando você clica nas setas)' : 'ligada (lê poucos segundos depois que algo muda)'}</div>
        <button class="btn ${S.paused ? 'primary' : ''}" id="dg-pause">${icon(S.paused ? 'sync' : 'pause', 14)} ${S.paused ? 'Ligar de novo' : 'Pausar'}</button>
      </div>
      <p class="muted"><span>${quedas.length ? `${quedas.length} queda${quedas.length > 1 ? 's' : ''} registrada${quedas.length > 1 ? 's' : ''}.` : 'Nenhuma queda registrada.'} Se o WhatsApp cair, clique em “Copiar relatório” e me mande.</span></p>
      <ul class="diag" id="diag-list">${diagRows()}</ul>
      <div class="row"><button class="btn" id="dg-clear">Limpar</button><span class="spacer"></span><button class="btn primary" id="dg-copy">Copiar relatório</button></div>`);
    $('#vs-btn').onclick = () => checkNow();
    $('#dg-pause').onclick = () => {
      S.paused = !S.paused;
      save.paused();
      note('leitura', S.paused ? 'Leitura automática pausada' : 'Leitura automática ligada');
      openDiag();
    };
    $('#dg-clear').onclick = () => {
      S.diag = [];
      save.diag();
      $('#diag-list').innerHTML = diagRows();
    };
    $('#dg-copy').onclick = async () => {
      const txt = [`Coyote CRM ${ext?.runtime.getManifest().version || ''} · ${navigator.userAgent}`, ...S.diag.map((d) => `${fmtTime(d.t)}  [${d.type}] ${d.text}`)].join('\n');
      try {
        await navigator.clipboard.writeText(txt);
        toast('Relatório copiado: cole no WhatsApp ou e-mail');
      } catch {
        toast('Não consegui copiar', true);
      }
    };
  }

  // só observa a lista de conversas (como os seus olhos): quando ela muda, lê de novo
  let watched = null;
  let captureT;
  const listObserver = new MutationObserver(() => {
    clearTimeout(captureT);
    captureT = setTimeout(captureScreen, 800);
    if (!canAutoRead()) return;
    scheduleRefresh(Math.max(2500, S.readAt + INTERVALO_MIN - Date.now()));
  });
  function watchList() {
    const pane = document.querySelector('#pane-side');
    if (!pane || pane === watched) return;
    listObserver.disconnect();
    listObserver.observe(pane, { childList: true, subtree: true, characterData: true });
    watched = pane;
  }

  // espera o WhatsApp Web terminar de abrir (lista de conversas na tela) e mais um pouco
  function whenReady(tries = 0) {
    const ready = document.querySelector('#pane-side') || globalThis.CRMLeitorTeste;
    if (!ready) return setTimeout(() => whenReady(tries + 1), 2000);
    setTimeout(start, globalThis.CRMLeitorTeste ? 0 : 15000);
  }
  whenReady();

  // ---------- atualização automática (Opção A: pasta atualizada pelo atualizador do Windows) ----------
  async function checkUpdate() {
    if (!ext) return;
    try {
      const r = await toExt({ type: 'versao' });
      $('#btn-upd').hidden = !r?.nova;
      if (r?.nova) $('#btn-upd').dataset.tip = `Nova versão do CRM (${r.nova}) pronta: clique para atualizar`;
    } catch {}
  }
  // botão "Procurar atualização": pede ao atualizador do Windows para baixar agora
  async function checkNow() {
    const b = $('#vs-btn');
    const t = $('#vs-txt');
    if (!ext) return toast('Só funciona com a extensão instalada');
    b.disabled = true;
    b.innerHTML = `${icon('sync', 14)} Procurando…`;
    let r = null;
    try {
      r = await toExt({ type: 'procurar' });
    } catch (err) {
      r = { erro: err.message };
    }
    b.disabled = false;
    b.innerHTML = `${icon('sync', 14)} Procurar atualização`;
    if (!r || r.erro) return toast(`Não consegui procurar: ${r?.erro || 'erro'}`, true);
    note('leitura', `Procurou atualização: rodando ${r.rodando}, na pasta ${r.pasta}, mais nova ${r.ultima || '?'}`);
    if (r.pasta !== r.rodando) {
      t.innerHTML = `${esc(r.rodando)} → <b>${esc(r.pasta)}</b> pronta`;
      b.className = 'btn primary';
      b.innerHTML = `${icon('up', 14)} Atualizar agora`;
      b.onclick = () => $('#btn-upd').click();
      checkUpdate();
      return;
    }
    // o atualizador baixou para a pasta dele, mas o Chrome continua na mesma versão:
    // o CRM está carregado de outra pasta (ex.: Downloads)
    if (r.nativo?.ok && r.nativo.versao && r.nativo.versao !== r.pasta) {
      note('erro', `Pasta errada: o atualizador tem a ${r.nativo.versao}, mas o Chrome carrega o CRM de outra pasta (${r.pasta})`);
      return toast(`O Chrome está usando o CRM de outra pasta (ex.: Downloads). Em chrome://extensions, remova o Coyote CRM e carregue a pasta %LOCALAPPDATA%\\CRM-Etiquetas\\extensao (versão ${r.nativo.versao} já está lá).`, true);
    }
    if (!r.temNova) return toast(`Você já está na versão mais nova (${r.rodando})`);
    if (r.nativo?.semBotao) {
      return toast(`Saiu a versão ${r.ultima}. Este computador ainda não liga o botão: o atualizador do Windows baixa sozinho em até 15 min (ou rode o INSTALAR-ATUALIZADOR de novo).`, true);
    }
    // o atualizador rodou mas a pasta não mudou: mostra o que ele disse
    const disse = String(r.nativo?.erro || r.nativo?.saida || '').trim().split(/\r?\n/).filter(Boolean).pop() || 'sem resposta';
    note('erro', `Atualização para ${r.ultima} não baixou: ${disse}`);
    toast(`Saiu a versão ${r.ultima}, mas o atualizador não baixou (${disse}). Tente de novo em alguns minutos.`, true);
  }
  $('#btn-upd').onclick = async () => {
    try {
      await toExt({ type: 'recarregar' });
    } catch {}
    setTimeout(() => location.reload(), 600);
  };

  function CSS() {
    return `
    :host { all: initial; --bg:#f3f5f8; --panel:#ffffff; --col:#eaeef3; --text:#1f2733; --muted:#7a8699; --line:#e2e7ee; --acc:#2f6fed; --acc-soft:#e8f0fe; --warn:#e8a317; --late:#e5484d; --ok:#25a36f; --shadow:0 1px 2px rgba(16,24,40,.06), 0 1px 3px rgba(16,24,40,.08); font: 13px/1.4 Inter, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }
    :host([data-theme="dark"]) { --bg:#0f1418; --panel:#1b232a; --col:#151c22; --text:#e6ebf0; --muted:#8a97a6; --line:#2a343d; --acc:#5b8def; --acc-soft:#1f2c44; --shadow:0 1px 2px rgba(0,0,0,.4); }
    * { box-sizing: border-box; font-family: inherit; }
    [hidden] { display: none !important; }
    button, input, select, textarea { font: inherit; color: inherit; }
    .i { flex: none; display: block; }
    .spacer { flex: 1; }
    .ib.sync { width: auto; padding: 0 8px; gap: 5px; display: inline-flex; align-items: center; }
    .sync-t { font-size: 11.5px; color: var(--muted); white-space: nowrap; }
    .sync-t:empty { display: none; }
    .ib.sync.spin .i { animation: spin 1s linear infinite; }
    @keyframes spin { to { transform: rotate(360deg); } }
    .ib.upd { background: var(--ok); color: #fff; }
    .muted { color: var(--muted); font-size: 12px; margin: 0; display: inline-flex; align-items: center; gap: 5px; }

    .fab { position: fixed; left: 76px; bottom: 14px; z-index: 2147483000; display: inline-flex; align-items: center; gap: 8px; background: #0b0b0c; color: #fff; border: 1px solid rgba(255,255,255,.14); border-radius: 999px; padding: 7px 15px 7px 11px; font-weight: 700; letter-spacing: .04em; cursor: pointer; box-shadow: 0 6px 16px rgba(0,0,0,.3); }
    .fab-badge { background: var(--late); color: #fff; border-radius: 999px; min-width: 18px; height: 18px; padding: 0 5px; font-size: 11px; display: inline-grid; place-items: center; }

    .app { position: fixed; inset: 0; z-index: 2147483001; background: var(--bg); color: var(--text); display: flex; flex-direction: column; }
    .top { display: flex; align-items: center; gap: 8px; padding: 10px 16px; background: var(--panel); border-bottom: 1px solid var(--line); flex-wrap: nowrap; min-width: 0; }
    .top > .ib, .top > .seg { flex: none; }
    .brand { display: flex; align-items: center; gap: 8px; font-weight: 700; font-size: 15px; color: var(--text); margin-right: 4px; flex: none; }
    .logo-mark { width: 26px; height: 31px; flex: none; background: var(--text); -webkit-mask: var(--mark) center / contain no-repeat; mask: var(--mark) center / contain no-repeat; }
    .logo-word { width: 84px; height: 14px; background: var(--text); -webkit-mask: var(--word) left center / contain no-repeat; mask: var(--word) left center / contain no-repeat; }
    .brand-sub { font-size: 10px; font-weight: 700; letter-spacing: .08em; color: var(--muted); border: 1px solid var(--line); border-radius: 5px; padding: 1px 5px; }
    .fab-mark { width: 20px; height: 24px; flex: none; background: #fff; -webkit-mask: var(--mark) center / contain no-repeat; mask: var(--mark) center / contain no-repeat; }
    .seg { display: inline-flex; background: var(--col); border-radius: 10px; padding: 3px; gap: 2px; }
    .seg:empty { display: none; }
    .sg { border: 0; background: transparent; border-radius: 8px; padding: 5px 10px; cursor: pointer; display: inline-flex; align-items: center; gap: 6px; color: var(--muted); font-weight: 500; }
    .sg.on { background: var(--panel); color: var(--text); box-shadow: var(--shadow); }
    .search { display: flex; align-items: center; gap: 6px; background: var(--col); border-radius: 10px; padding: 0 10px; color: var(--muted); flex: 0 1 220px; min-width: 110px; }
    .search input { min-width: 0; width: 100%; }
    .search input { border: 0; background: transparent; outline: none; padding: 7px 0; width: 100%; color: var(--text); }
    .fx { display: inline-flex; gap: 6px; align-items: center; flex: 0 1 auto; min-width: 0; }
    .fxs { display: inline-flex; align-items: center; gap: 4px; border: 1px solid var(--line); border-radius: 10px; padding: 0 4px 0 8px; color: var(--muted); background: var(--panel); min-width: 0; flex: 0 1 auto; }
    .fxs.on { border-color: var(--acc); color: var(--acc); background: var(--acc-soft); }
    .fxs select { border: 0; background: transparent; outline: none; padding: 6px 2px; cursor: pointer; color: inherit; max-width: 130px; min-width: 0; width: 100%; }
    .ib { position: relative; display: inline-grid; place-items: center; width: 34px; height: 34px; border-radius: 10px; border: 0; background: transparent; color: var(--muted); cursor: pointer; }
    .ib:hover:not([disabled]) { background: var(--col); color: var(--text); }
    .ib.on { background: var(--acc-soft); color: var(--acc); }
    .ib.alert { color: var(--late); }
    .ib.ghost { cursor: help; }
    .ib.sm { width: 26px; height: 26px; border-radius: 8px; font-size: 10px; }
    .ib[disabled] { opacity: .3; cursor: default; }
    .ib-badge { position: absolute; top: 2px; right: 1px; background: var(--late); color: #fff; border-radius: 999px; min-width: 16px; height: 16px; font-size: 10px; display: grid; place-items: center; padding: 0 4px; }
    .msg { margin: 10px 16px 0; padding: 9px 12px; border-radius: 10px; background: #fff4d6; color: #6b4e00; font-size: 12.5px; }

    .kpis { display: grid; grid-template-columns: repeat(7, minmax(0, 1fr)) minmax(0, 1.5fr) minmax(0, 1.5fr) minmax(0, 1.7fr); gap: 10px; padding: 12px 16px 0; }
    .kpi { min-width: 0; overflow: hidden; background: var(--panel); border-radius: 12px; padding: 10px 12px; box-shadow: var(--shadow); display: flex; gap: 10px; align-items: center; }
    .kpi-i { width: 34px; height: 34px; border-radius: 10px; display: grid; place-items: center; background: var(--acc-soft); color: var(--acc); flex: none; }
    .kpi.warn .kpi-i { background: #fff3d6; color: var(--warn); }
    .kpi.late .kpi-i { background: #fde7e7; color: var(--late); }
    .kpi-v { font-size: 18px; font-weight: 700; line-height: 1.1; white-space: nowrap; }
    .kpi-l { color: var(--muted); font-size: 11.5px; display: flex; align-items: center; gap: 5px; white-space: nowrap; }
    .kpi.wide { flex-direction: column; align-items: stretch; gap: 4px; }
    .gr { display: grid; grid-template-columns: 34px 1fr 22px; gap: 6px; align-items: center; font-size: 11.5px; }
    .gr-t { color: var(--muted); font-weight: 600; }
    .gr-bar { height: 6px; background: var(--col); border-radius: 99px; overflow: hidden; }
    .gr-bar i { display: block; height: 100%; background: var(--acc); border-radius: 99px; }
    .gr-v { text-align: right; font-weight: 600; }

    .board { flex: 1; display: flex; gap: 12px; padding: 14px 16px; overflow: auto; align-items: flex-start; }
    .col { flex: 1 0 215px; max-width: 340px; max-height: 100%; display: flex; flex-direction: column; }
    .col-h { padding: 4px 4px 8px; margin-bottom: 8px; border-bottom: 3px solid var(--c); }
    .col-t { display: flex; align-items: center; justify-content: space-between; gap: 6px; }
    .col-name { display: inline-flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 700; letter-spacing: .04em; text-transform: uppercase; color: var(--text); }
    .col-n { font-size: 11.5px; font-weight: 600; color: var(--muted); background: var(--col); border-radius: 99px; padding: 1px 8px; }
    .col-s { font-size: 12px; color: var(--muted); margin-top: 2px; min-height: 16px; }
    .cards { overflow-y: auto; display: flex; flex-direction: column; gap: 6px; padding: 0 2px 8px; min-height: 40px; }
    .empty { color: var(--muted); text-align: center; padding: 14px; font-size: 12px; border: 1px dashed var(--line); border-radius: 10px; }
    .card { background: var(--panel); border-radius: 10px; padding: 9px 11px; box-shadow: var(--shadow); cursor: pointer; border-left: 3px solid transparent; transition: transform .08s, box-shadow .08s; }
    .card:hover { transform: translateY(-1px); box-shadow: 0 4px 12px rgba(16,24,40,.12); }
    .card.r-warn { border-left-color: var(--warn); }
    .card.r-late { border-left-color: var(--late); }
    .c1 { display: flex; align-items: center; gap: 7px; }
    .nm { flex: 1; font-weight: 600; font-size: 13px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .tm { color: var(--muted); font-size: 11px; flex: none; }
    .c2 { display: flex; align-items: center; gap: 6px; margin-top: 6px; min-height: 18px; flex-wrap: wrap; row-gap: 4px; }
    .icons { display: inline-flex; align-items: center; gap: 5px; }
    .ic { display: inline-grid; place-items: center; color: var(--muted); }
    .ic.warn { color: var(--warn); }
    .ic.late { color: var(--late); }
    .ic.muted { color: #a3adbb; }
    .unread { background: var(--ok); color: #fff; border-radius: 99px; font-size: 10px; font-weight: 700; min-width: 17px; height: 17px; display: inline-grid; place-items: center; padding: 0 4px; }
    .badges { display: inline-flex; align-items: center; gap: 4px; margin-left: auto; }
    .bd { font-size: 10px; font-weight: 700; border-radius: 6px; padding: 1px 6px; line-height: 16px; display: inline-flex; align-items: center; }
    .bd.pd { background: #e3f4ee; color: #187a55; }
    .bd.og { background: var(--col); color: var(--muted); padding: 2px 4px; }
    .bd.lv.N1 { background: #eef2f7; color: #5b6b80; }
    .bd.lv.N2 { background: #fff1d6; color: #9a6400; }
    .bd.lv.N3 { background: #ffe1d6; color: #b4400f; }
    .bd.lv.N4 { background: #efe3ff; color: #6b2fb3; }
    .bd.pd.m-THM { background: #ffe4e1; color: #b3261e; }
    .bd.pd.m-BRZ { background: #e0f0ff; color: #0b5cad; }
    .bd.pd.m-Buy { background: #e3f4ee; color: #187a55; }
    .bd.pd.m-TMF { background: #fff1d6; color: #8a5a00; }
    :host([data-theme="dark"]) .bd.pd { background: #173a2e; color: #6fd3a6; }
    :host([data-theme="dark"]) .bd.lv.N1 { background: #263240; color: #a9b6c6; }
    :host([data-theme="dark"]) .bd.lv.N2 { background: #3d3014; color: #f0c56a; }
    :host([data-theme="dark"]) .bd.lv.N3 { background: #45251a; color: #ff9f7a; }
    :host([data-theme="dark"]) .bd.lv.N4 { background: #33224a; color: #c9a2ff; }
    :host([data-theme="dark"]) .bd.pd.m-THM { background: #45201d; color: #ff8a80; }
    :host([data-theme="dark"]) .bd.pd.m-BRZ { background: #172f47; color: #7cbcff; }
    :host([data-theme="dark"]) .bd.pd.m-Buy { background: #173a2e; color: #6fd3a6; }
    :host([data-theme="dark"]) .bd.pd.m-TMF { background: #3d3014; color: #f0c56a; }
    .dot { width: 8px; height: 8px; border-radius: 50%; display: inline-block; }
    .val { font-size: 11.5px; font-weight: 700; color: var(--text); flex: none; }
    .badges:empty + .val { margin-left: auto; }
    .icons:empty { display: none; }

    .pic { position: relative; width: 26px; height: 26px; border-radius: 50%; color: #fff; display: inline-grid; place-items: center; font-size: 10.5px; font-weight: 700; flex: none; overflow: hidden; }
    .pic img { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; }
    .pic.lg { width: 46px; height: 46px; font-size: 16px; }
    .pw { position: relative; flex: none; display: inline-flex; }
    .c2 .own { margin-left: auto; flex: none; }
    .c2 .val + .own { margin-left: 6px; }
    .dw-sub .sep { margin: 0 2px; opacity: .6; }
    .search.wide { width: 100%; margin: 6px 0 8px; }
    .adds { list-style: none; margin: 0 0 12px; padding: 0; max-height: 340px; overflow: auto; border: 1px solid var(--line); border-radius: 10px; }
    .adds li { border-bottom: 1px solid var(--line); }
    .adds li:last-child { border-bottom: 0; }
    .adds li.muted { padding: 10px; }
    .ad { display: flex; align-items: center; gap: 10px; padding: 7px 10px; cursor: pointer; }
    .ad:hover { background: var(--col); }
    .ad-t { flex: 1; min-width: 0; display: flex; flex-direction: column; }
    .ad-t b { font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .ad-t .muted { font-size: 11.5px; }
    .ad-w { font-size: 11.5px; white-space: nowrap; }
    .av { width: 26px; height: 26px; border-radius: 50%; color: #fff; display: inline-grid; place-items: center; font-size: 11px; font-weight: 700; flex: none; }
    .av.sm { width: 20px; height: 20px; font-size: 9.5px; }
    .av.xs { width: 16px; height: 16px; font-size: 8.5px; }
    .av.lg { width: 42px; height: 42px; font-size: 15px; }

    .scrim { position: absolute; inset: 0; background: rgba(15,20,25,.25); }
    .drawer { position: absolute; top: 0; right: 0; bottom: 0; width: min(440px, 100%); background: var(--panel); box-shadow: -8px 0 24px rgba(16,24,40,.16); display: flex; flex-direction: column; animation: slide .16s ease-out; }
    @keyframes slide { from { transform: translateX(24px); opacity: .6; } to { transform: none; opacity: 1; } }
    .dw-h { display: flex; align-items: center; gap: 12px; padding: 16px 16px 10px; }
    .dw-t { flex: 1; min-width: 0; }
    .dw-name { font-size: 16px; font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .dw-sub { color: var(--muted); font-size: 12px; display: flex; align-items: center; gap: 5px; }
    .dw-pills { display: flex; align-items: center; gap: 8px; padding: 0 16px 12px; flex-wrap: wrap; border-bottom: 1px solid var(--line); }
    .pill-stage { font-size: 12px; font-weight: 600; padding: 3px 10px; border-radius: 99px; background: color-mix(in srgb, var(--c) 22%, transparent); color: var(--text); border: 1px solid color-mix(in srgb, var(--c) 55%, transparent); }
    .pill-owner { display: inline-flex; align-items: center; gap: 5px; font-size: 12px; color: var(--muted); }
    .dw-pills .btn { margin-left: auto; }
    .dw-alerts { padding: 10px 16px 0; display: flex; flex-direction: column; gap: 6px; }
    .al { display: flex; align-items: center; gap: 8px; font-size: 12.5px; padding: 7px 10px; border-radius: 9px; background: var(--col); }
    .al.warn { background: #fff4d9; color: #7a5300; }
    .al.late { background: #fde8e8; color: #a3282c; }
    :host([data-theme="dark"]) .al.warn { background: #3a2f12; color: #f3cd72; }
    :host([data-theme="dark"]) .al.late { background: #40201f; color: #ff9b9b; }
    .dw-conv { margin: 10px 16px 0; display: flex; flex-direction: column; gap: 6px; }
    .dw-conv .sec, .dw-hist .sec { margin: 0 0 2px; display: flex; align-items: center; gap: 6px; }
    .dw-conv .sec .muted { font-weight: 400; text-transform: none; letter-spacing: 0; }
    .cv { background: var(--col); border-radius: 10px; padding: 6px 10px; font-size: 12.5px; display: flex; flex-direction: column; max-width: 92%; overflow-wrap: anywhere; }
    .cv.me { align-self: flex-end; background: #dcf8c6; }
    :host([data-theme="dark"]) .cv.me { background: #1f3a2c; }
    .cv-w { font-size: 10.5px; font-weight: 700; color: var(--muted); }
    .dw-hist { margin: 12px 16px 0; display: flex; flex-direction: column; gap: 6px; }
    .h-in { border: 1px solid var(--line); border-radius: 9px; background: var(--col); outline: none; padding: 8px 10px; color: var(--text); font: inherit; font-size: 12.5px; }
    .h-in:focus { border-color: var(--acc); background: var(--panel); }
    .hist { list-style: none; margin: 0; padding: 0; max-height: 150px; overflow: auto; }
    .hist li { display: flex; gap: 8px; align-items: baseline; font-size: 12.5px; padding: 4px 0; border-bottom: 1px dashed var(--line); }
    .hist li.auto { color: var(--muted); }
    .h-d { color: var(--muted); font-size: 11px; font-variant-numeric: tabular-nums; flex: none; }
    .h-t { flex: 1; overflow-wrap: anywhere; }
    .h-b { color: var(--muted); font-size: 11px; flex: none; }
    .dw-last { margin: 10px 16px 0; display: flex; gap: 8px; align-items: flex-start; font-size: 12.5px; color: var(--muted); background: var(--col); border-radius: 9px; padding: 8px 10px; }
    .dw-last span:first-of-type { flex: 1; color: var(--text); overflow-wrap: anywhere; }
    .dw-form { flex: none; padding: 4px 16px 14px; display: flex; flex-direction: column; gap: 2px; }
    .drawer { overflow-y: auto; }
    .dw-f { position: sticky; bottom: 0; background: var(--panel); margin-top: auto; z-index: 1; }
    .sec { font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .05em; color: var(--muted); margin: 14px 0 4px; }
    .dw-form .fr { display: grid; grid-template-columns: 112px 1fr; align-items: center; gap: 8px; min-height: 34px; border-bottom: 1px dashed var(--line); }
    .dw-form .frl { display: flex; align-items: center; flex-direction: row; gap: 7px; color: var(--muted); font-size: 12.5px; }
    .dw-form .fr input, .dw-form .fr select { border: 1px solid transparent; border-radius: 7px; background: transparent; outline: none; padding: 6px 8px; width: 100%; min-width: 0; color: var(--text); font: inherit; font-size: 13px; }
    .dw-form .fr:hover input, .dw-form .fr:hover select { background: var(--col); }
    .dw-form .fr input:focus, .dw-form .fr select:focus { border-color: var(--acc); background: var(--panel); }
    .dw-form .fr select { cursor: pointer; }
    .dw-form .fr input::placeholder { color: var(--muted); opacity: .7; }
    .dw-form .ta { border: 1px solid var(--line); border-radius: 9px; background: var(--col); outline: none; padding: 9px 10px; width: 100%; box-sizing: border-box; color: var(--text); font: inherit; font-size: 13px; resize: vertical; }
    .dw-form .ta:focus { border-color: var(--acc); background: var(--panel); }
    .dw-f { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 12px 16px; border-top: 1px solid var(--line); }
    .dw-actions { display: flex; gap: 8px; }
    .perda-act { display: flex; align-items: center; gap: 10px; padding: 8px 0 4px; font-size: 12px; flex-wrap: wrap; }
    .lost-tag { display: inline-flex; align-items: center; gap: 5px; color: var(--late); font-weight: 600; }
    .bd.lost { background: #fde8e8; color: #a3282c; font-weight: 600; max-width: 110px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; display: inline-block; }
    :host([data-theme="dark"]) .bd.lost { background: #40201f; color: #ff9b9b; }
    .gr.lg { grid-template-columns: 104px 1fr 22px; }
    .gr-t.lost-t { min-width: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .bd.imp { background: #efe7ff; color: #6d3fd1; gap: 3px; font-weight: 600; }
    :host([data-theme="dark"]) .bd.imp { background: #2d2342; color: #b99bff; }
    .ad-man { margin: 0 0 12px; font-size: 12.5px; }
    .ad-man summary { cursor: pointer; color: var(--acc); display: flex; align-items: center; gap: 6px; list-style: none; }
    .ad-man-f { display: flex; gap: 8px; margin-top: 8px; flex-wrap: wrap; }
    .ad-man-f input { flex: 1 1 160px; border: 1px solid var(--line); border-radius: 9px; background: var(--col); padding: 7px 10px; color: var(--text); outline: none; }
    .ad-man-f input:focus { border-color: var(--acc); background: var(--panel); }
    .ib-dot { position: absolute; top: 6px; right: 6px; width: 8px; height: 8px; border-radius: 50%; background: var(--warn); }
    .diag-box { display: flex; align-items: center; justify-content: space-between; gap: 10px; background: var(--col); border-radius: 10px; padding: 10px 12px; margin: 8px 0; }
    .diag { list-style: none; margin: 0 0 12px; padding: 0; max-height: 300px; overflow: auto; border: 1px solid var(--line); border-radius: 10px; }
    .dg { display: flex; gap: 8px; align-items: flex-start; padding: 7px 10px; border-bottom: 1px solid var(--line); font-size: 12px; }
    .dg:last-child { border-bottom: 0; }
    .dg .i { margin-top: 2px; color: var(--muted); }
    .dg.queda .i, .dg.qr .i, .dg.erro .i { color: var(--late); }
    .dg.volta .i { color: var(--ok); }
    .dg-t { color: var(--muted); white-space: nowrap; font-variant-numeric: tabular-nums; }
    .btn.ghost { background: transparent; }
    .btn.danger { color: var(--late); }
    .btn.danger:hover { background: #fde8e8; }
    :host([data-theme="dark"]) .btn.danger:hover { background: #40201f; }
    .card { position: relative; }
    .rm { display: none; position: absolute; top: 6px; right: 6px; width: 22px; height: 22px; border: 0; border-radius: 6px; background: var(--col); color: var(--muted); cursor: pointer; place-items: center; padding: 0; }
    .card:hover .rm { display: grid; }
    .card:hover .tm { visibility: hidden; }
    .rm:hover { color: var(--late); background: #fde8e8; }
    :host([data-theme="dark"]) .rm:hover { background: #40201f; }
    .md-sub { display: flex; align-items: center; gap: 6px; font-size: 13px; margin: 16px 0 6px; color: var(--muted); }
    .stages.removed li { gap: 10px; }
    .stages.removed .lname { flex: 1; }
    .toast { display: flex; align-items: center; gap: 12px; }
    .toast-act { background: transparent; border: 0; color: #8fb4ff; font-weight: 700; cursor: pointer; padding: 0; }

    .btn { border: 1px solid var(--line); background: var(--panel); border-radius: 9px; padding: 7px 14px; cursor: pointer; font-weight: 600; display: inline-flex; align-items: center; gap: 6px; }
    .btn:hover { background: var(--col); }
    .btn.primary { background: var(--acc); color: #fff; border-color: var(--acc); }
    .btn.primary:hover { filter: brightness(1.06); }
    .btn.sm { padding: 5px 10px; font-size: 12px; }
    .btn:disabled { opacity: .6; cursor: progress; }

    .modal-bg { position: fixed; inset: 0; z-index: 2147483002; background: rgba(15,20,25,.45); display: flex; align-items: center; justify-content: center; padding: 16px; }
    .modal { background: var(--panel); color: var(--text); border-radius: 14px; padding: 16px 18px; width: min(520px, 100%); max-height: calc(100vh - 32px); overflow: auto; display: flex; flex-direction: column; gap: 12px; box-shadow: 0 20px 50px rgba(0,0,0,.25); }
    .md-h { display: flex; align-items: center; gap: 8px; color: var(--acc); }
    .md-h h2 { margin: 0; font-size: 16px; color: var(--text); flex: 1; }
    .fl { display: flex; flex-direction: column; gap: 4px; font-weight: 600; font-size: 12px; color: var(--muted); }
    .fl input { padding: 8px 10px; border: 1px solid var(--line); border-radius: 9px; background: var(--bg); font-weight: 400; color: var(--text); }
    .row { display: flex; gap: 8px; align-items: center; }
    .stages { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 6px; }
    .stages li { display: flex; align-items: center; gap: 8px; border: 1px solid var(--line); border-radius: 10px; padding: 6px 8px; }
    .sw { width: 10px; height: 10px; border-radius: 3px; flex: none; }
    .lname { flex: 1; font-weight: 500; }
    .tg { display: inline-flex; align-items: center; gap: 4px; font-size: 12px; color: var(--muted); cursor: pointer; }

    .toast { position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%); z-index: 2147483003; background: #1f2733; color: #fff; padding: 9px 16px; border-radius: 10px; max-width: calc(100vw - 32px); box-shadow: 0 8px 24px rgba(0,0,0,.2); font-size: 12.5px; }
    .toast.error { background: var(--late); }
    .tip { position: fixed; z-index: 2147483004; max-width: 280px; background: #1f2733; color: #fff; font-size: 11.5px; line-height: 1.35; padding: 6px 9px; border-radius: 7px; pointer-events: none; box-shadow: 0 4px 14px rgba(0,0,0,.2); }
    @media (max-width: 1200px) { .kpis { grid-template-columns: repeat(3, minmax(0, 1fr)); } .search { width: 160px; } }
    @media (max-width: 720px) { .col { flex-basis: 85vw; } .fx { display: none; } }
    `;
  }
})();
