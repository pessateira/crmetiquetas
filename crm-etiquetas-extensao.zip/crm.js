// CRM Etiquetas dentro do WhatsApp Web, em MODO ESPELHO (somente leitura).
// As colunas são as etiquetas do WhatsApp Business e cada cartão fica na
// coluna da etiqueta que a conversa tem. O CRM NUNCA altera nada no
// WhatsApp: não cria, não troca e não remove etiquetas, e não envia
// mensagens. Para mudar alguém de etapa, troque a etiqueta no próprio
// WhatsApp (celular ou WhatsApp Web) e o cartão acompanha na próxima leitura.
//
// Roda isolado da página do WhatsApp (mundo "ISOLATED" da extensão): não
// usa nenhuma função interna do WhatsApp. Os dados vêm de leitor.js, que lê
// a cópia que o WhatsApp Web guarda no navegador, a cada 5 minutos ou
// quando você clica em Atualizar.
//
// EQUIPE (opcional): com uma planilha Google como ponto de encontro, cada
// pessoa publica uma cópia do seu funil e o CRM mostra todos juntos, com
// filtro "Todos / Meus / Fulano". Valor e anotações passam a ser da equipe.
(() => {
  if (window.__crmEtiquetas) return;
  window.__crmEtiquetas = true;
  const C = globalThis.CRMCore;

  // ---------- armazenamento (chrome.storage da extensão; localStorage só na página de teste) ----------
  const ext = typeof chrome !== 'undefined' && chrome.storage?.local && chrome.runtime?.id ? chrome : null;
  const storage = {
    async get(key) {
      if (ext) return (await ext.storage.local.get(key))[key] ?? null;
      try { return JSON.parse(localStorage.getItem(key)); } catch { return null; }
    },
    async set(key, value) {
      if (ext) return ext.storage.local.set({ [key]: value });
      try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
    },
  };

  // ---------- estado ----------
  const S = {
    labels: [],
    stages: [],
    chats: [],
    settings: {},
    cards: {}, // chatId -> { value, notes, since: { labelId: ms } } (deste Chrome)
    team: null, // { url, codigo, pessoa }
    shared: { cards: [], notes: new Map(), at: 0, error: null },
    filter: 'me', // 'me' | 'all' | nome da pessoa
    fx: { produto: '', nivel: '', origem: '' }, // filtros por selo ('-' = sem selo)
    open: false,
    search: '',
    attention: false,
    showPanel: false,
    drawerKey: null,
    error: null,
    readAt: 0, // última leitura do WhatsApp (ms)
    reading: false,
  };
  const save = {
    settings: () => storage.set('crm:settings', S.settings),
    cards: () => storage.set('crm:cards', S.cards),
    team: () => storage.set('crm:team', S.team),
    filter: () => storage.set('crm:filter', S.filter),
  };
  const me = () => S.team?.pessoa || 'Eu';
  const norm = (s) => String(s || '').trim().toLowerCase();

  // Selos e ficha do cliente (ficam no CRM e na planilha da equipe, não no WhatsApp)
  const PRODUTOS = ['Buy', 'Hot Machine', 'BRZ', 'Franquia'];
  const NIVEIS = [['N1', 'N1 pequeno'], ['N2', 'N2 médio'], ['N3', 'N3 grande']];
  const ORIGENS = ['Moai', 'Indicação', 'Instagram', 'Google/Site', 'Prospecção ativa', 'Evento', 'Outro'];
  const TIPOS = ['Condomínio', 'Empresa', 'Hospital/Clínica', 'Academia', 'Escola/Faculdade', 'Hotel', 'Comércio', 'Outro'];
  const FICHA = ['value', 'notes', 'produto', 'nivel', 'origem', 'tipoLocal', 'tamanho', 'decisor', 'concorrente', 'nextStep', 'nextDate'];
  const NIVEL_COR = { N1: '#d6e9c6', N2: '#ffd97a', N3: '#ff9f6b' };

  // ---------- leitura do WhatsApp ----------
  // O leitor (leitor.js) só lê a cópia que o WhatsApp Web guarda no navegador,
  // de vez em quando ou quando você clica em Atualizar. Nada roda dentro do WhatsApp.
  const LER_A_CADA = 5 * 60 * 1000;

  async function refresh() {
    if (S.reading) return;
    S.reading = true;
    renderSync();
    try {
      const data = await (globalThis.CRMLeitorTeste || globalThis.CRMLeitor).ler(C.formatPhone);
      S.labels = data.labels;
      S.stages = C.stageList(S.labels, S.settings);
      S.chats = data.chats;
      S.readAt = Date.now();
      S.error = null;
      let dirty = false;
      for (const c of S.chats) {
        const st = C.stageOf(c.labels, S.stages);
        if (!st) continue;
        const rec = (S.cards[c.id] ??= {});
        rec.since ??= {};
        if (!rec.since[st]) {
          rec.since[st] = Date.now(); // a partir de quando o CRM viu o cartão nessa etapa
          dirty = true;
        }
      }
      if (dirty) save.cards();
    } catch (err) {
      S.error = `Não consegui ler o WhatsApp: ${err.message}`;
    }
    S.reading = false;
    render();
    schedulePublish();
  }
  let refreshTimer = null;
  const scheduleRefresh = (ms = 600) => {
    clearTimeout(refreshTimer);
    refreshTimer = setTimeout(refresh, ms);
  };

  // ---------- cartões no formato único (meus, ao vivo, e da equipe, pela planilha) ----------
  const stageById = (id) => S.stages.find((s) => s.id === id);

  function myCards() {
    const labelName = new Map(S.labels.map((l) => [String(l.id), l]));
    return S.chats
      .map((c) => {
        const st = stageById(C.stageOf(c.labels, S.stages));
        return {
          ...c,
          key: c.id,
          owner: me(),
          mine: true,
          stageName: st?.name || '',
          stageColor: st?.color || '',
          final: Boolean(st?.final),
          since: st ? S.cards[c.id]?.since?.[st.id] ?? null : null,
          multi: C.stagesOf(c.labels, S.stages).map((s) => s.name),
          tags: c.labels.filter((id) => !stageById(id)).map((id) => labelName.get(id)).filter(Boolean).map((l) => ({ name: l.name, color: l.hexColor || '#ccc' })),
        };
      })
      .filter((c) => c.stageName || C.isNovo(c, S.settings.novosDesde)); // Novos: sem etiqueta, do último mês em diante
  }

  function teamCards() {
    return S.shared.cards
      .filter((c) => c.owner !== me())
      .map((c) => ({ ...c, key: `${c.owner}|${c.id}`, mine: false, multi: c.multi || [], tags: c.tags || [] }));
  }

  function visibleCards() {
    if (S.filter === 'me' || !S.team) return myCards();
    if (S.filter === 'all') return [...myCards(), ...teamCards()];
    return S.filter === me() ? myCards() : teamCards().filter((c) => c.owner === S.filter);
  }

  const noteOf = (c) => {
    const shared = S.shared.notes.get(`${c.owner}|${c.id}`);
    if (shared) return shared;
    return c.mine ? S.cards[c.id] || {} : {};
  };
  const cardAlerts = (c) => {
    const out = C.alerts(c, c.stageName ? { name: c.stageName, final: c.final } : null);
    const step = C.stepInfo(noteOf(c));
    if (step?.alert) out.unshift(step);
    return out;
  };
  const rank = (c) => {
    const a = cardAlerts(c);
    return a.some((x) => x.level === 'late') ? 2 : a.length ? 1 : 0;
  };

  function columnsData() {
    const q = norm(S.search);
    const cols = [{ key: '', name: 'Novos', color: '#9aa5b1', final: false, items: [] }];
    for (const s of S.stages) cols.push({ key: norm(s.name), name: s.name, color: s.color, final: s.final, items: [] });
    const byKey = new Map(cols.map((c) => [c.key, c]));
    for (const c of visibleCards()) {
      if (S.attention && rank(c) === 0) continue;
      const n = noteOf(c);
      let skip = false;
      for (const k of ['produto', 'nivel', 'origem']) {
        const want = S.fx[k];
        if (want && (want === '-' ? Boolean(n[k]) : n[k] !== want)) skip = true;
      }
      if (skip) continue;
      if (q) {
        const hay = [c.name, c.phone, c.id, c.lastText, c.owner, c.stageName, ...FICHA.map((f) => n[f]), ...c.tags.map((t) => t.name)].join(' ');
        if (!norm(hay).includes(q)) continue;
      }
      const k = norm(c.stageName);
      if (!byKey.has(k)) {
        // etapa que só existe no WhatsApp de outra pessoa: vira coluna no fim
        const col = { key: k, name: c.stageName, color: c.stageColor || '#9aa5b1', final: c.final, items: [] };
        cols.push(col);
        byKey.set(k, col);
      }
      byKey.get(k).items.push(c);
    }
    for (const col of cols) col.items.sort((a, b) => rank(b) - rank(a) || b.lastAt - a.lastAt);
    byKey.get('').items = byKey.get('').items.slice(0, 200);
    return cols;
  }

  // ---------- equipe (planilha Google) ----------
  async function teamCall(body) {
    if (!S.team?.url) return { ok: false, erro: 'Equipe não configurada' };
    const payload = { ...body, codigo: S.team.codigo };
    if (ext) {
      try {
        return (await ext.runtime.sendMessage({ type: 'equipe', url: S.team.url, body: payload })) ?? { ok: false, erro: 'A planilha demorou demais para responder.' };
      } catch (err) {
        return { ok: false, erro: /context invalidated/i.test(err.message) ? 'A extensão foi atualizada: aperte F5.' : err.message };
      }
    }
    try {
      // sem extensão (página de teste): chama direto
      const r = await fetch(S.team.url, { method: 'POST', body: JSON.stringify(payload) });
      return await r.json();
    } catch (err) {
      return { ok: false, erro: err.message };
    }
  }

  function snapshot() {
    return myCards().map((c) => ({
      id: c.id,
      name: c.name,
      phone: c.phone,
      stageName: c.stageName,
      stageColor: c.stageColor,
      final: c.final,
      since: c.since,
      multi: c.multi,
      tags: c.tags,
      lastAt: c.lastAt,
      lastFromMe: c.lastFromMe,
      lastText: c.lastText,
      unread: c.unread,
    }));
  }
  let lastPublished = '';
  let lastPublishAt = 0;
  let publishTimer = null;
  function schedulePublish() {
    if (!S.team?.url) return;
    clearTimeout(publishTimer);
    publishTimer = setTimeout(publish, 5000);
  }
  async function publish(force = false) {
    if (!S.team?.url) return;
    const cards = snapshot();
    const sig = JSON.stringify(cards.map((c) => [c.id, c.stageName, c.lastAt, c.lastFromMe, c.unread, c.name]));
    if (!force && sig === lastPublished && Date.now() - lastPublishAt < 10 * 60 * 1000) return;
    const r = await teamCall({ acao: 'publicar', pessoa: me(), cartoes: cards });
    if (r?.ok) {
      lastPublished = sig;
      lastPublishAt = Date.now();
      S.shared.error = null;
    } else {
      S.shared.error = r?.erro || 'falha ao enviar para a planilha';
      render();
    }
  }
  async function pull() {
    if (!S.team?.url) return;
    const r = await teamCall({ acao: 'ler' });
    if (r?.ok) {
      S.shared.cards = r.cartoes || [];
      S.shared.notes = new Map((r.notas || []).map((n) => [`${n.owner}|${n.id}`, n]));
      S.shared.at = Date.now();
      S.shared.error = null;
    } else {
      S.shared.error = r?.erro || 'falha ao ler a planilha';
    }
    render();
  }
  // fichas preenchidas antes de ligar a equipe sobem para a planilha
  async function uploadLocalFichas() {
    const names = new Map(S.chats.map((c) => [c.id, c.name]));
    let sent = 0;
    for (const [id, rec] of Object.entries(S.cards)) {
      if (!FICHA.some((f) => rec[f] != null && rec[f] !== '')) continue;
      if (S.shared.notes.has(`${me()}|${id}`)) continue;
      const ficha = Object.fromEntries(FICHA.map((f) => [f, rec[f] ?? (['value', 'tamanho'].includes(f) ? null : '')]));
      const r = await teamCall({ acao: 'anotar', dono: me(), id, nome: names.get(id) || '', ficha, pessoa: me() });
      if (r?.ok) {
        S.shared.notes.set(`${me()}|${id}`, { ...ficha, owner: me(), id, by: me() });
        sent += 1;
      }
    }
    if (sent) toast(`${sent} ficha(s) que estavam só neste Chrome foram para a planilha da equipe.`);
  }
  const teamPeople = () => [...new Set([me(), ...S.shared.cards.map((c) => c.owner)])].filter(Boolean);


  // ---------- tela ----------
  const host = document.createElement('div');
  host.id = 'crm-etiquetas';
  const root = host.attachShadow({ mode: globalThis.CRMLeitorTeste ? 'open' : 'closed' }); // fechado: a página do WhatsApp não enxerga o CRM
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const money = (v) => (v ? Number(v).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 }) : '');
  const moneyShort = (v) => {
    const n = Number(v) || 0;
    if (!n) return '';
    if (n >= 1e6) return `R$ ${(n / 1e6).toLocaleString('pt-BR', { maximumFractionDigits: 1 })} mi`;
    if (n >= 1e3) return `R$ ${(n / 1e3).toLocaleString('pt-BR', { maximumFractionDigits: 1 })} mil`;
    return `R$ ${n.toLocaleString('pt-BR')}`;
  };
  function ago(sec) {
    if (!sec) return '';
    const d = Date.now() / 1000 - sec;
    if (d < 60) return 'agora';
    if (d < 3600) return `${Math.floor(d / 60)} min`;
    if (d < 86400) return `${Math.floor(d / 3600)} h`;
    if (d < 86400 * 7) return `${Math.floor(d / 86400)} d`;
    return new Date(sec * 1000).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
  }
  const initials = (name) =>
    String(name || '?')
      .replace(/[^\p{L}\p{N} ]/gu, ' ')
      .trim()
      .split(/\s+/)
      .slice(0, 2)
      .map((w) => w[0])
      .join('')
      .toUpperCase() || '?';
  const avatarColor = (name) => {
    const palette = ['#5b8def', '#3fb68b', '#f2a33a', '#e2626b', '#8b6fe0', '#2bb3c0', '#d36fb0', '#7a8a9e'];
    let h = 0;
    for (const ch of String(name)) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
    return palette[h % palette.length];
  };

  // ícones de traço (estilo Lucide), desenhados aqui para não depender de nada externo
  const P = {
    board: '<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M8 7v8M12 7v11M16 7v5"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
    bell: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.9 1.9 0 0 0 3.4 0"/>',
    chart: '<path d="M3 3v18h18"/><path d="M8 16v-5M13 16V8M18 16v-3"/>',
    sliders: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
    x: '<path d="M18 6 6 18M6 6l12 12"/>',
    lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
    cal: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
    warn: '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/>',
    note: '<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M8 13h8M8 17h5"/>',
    msg: '<path d="M21 11.5a8.4 8.4 0 0 1-12.6 7.3L3 21l2.2-5.4A8.5 8.5 0 1 1 21 11.5z"/>',
    pkg: '<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="m3 8 9 5 9-5M12 13v8"/>',
    level: '<path d="M4 20v-4M10 20v-8M16 20V8M22 20V4"/>',
    compass: '<circle cx="12" cy="12" r="9"/><path d="m15.5 8.5-2 5-5 2 2-5z"/>',
    phone: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/>',
    money: '<path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>',
    building: '<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M9 22v-4h6v4M8 6h.01M12 6h.01M16 6h.01M8 10h.01M12 10h.01M16 10h.01M8 14h.01M12 14h.01M16 14h.01"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    open: '<path d="M15 3h6v6M10 14 21 3M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
    inbox: '<path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.5 5.1 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.5-6.9A2 2 0 0 0 16.8 4H7.2a2 2 0 0 0-1.7 1.1z"/>',
    sync: '<path d="M21 12a9 9 0 0 1-15.5 6.2L3 16M3 12a9 9 0 0 1 15.5-6.2L21 8"/><path d="M21 3v5h-5M3 21v-5h5"/>',
    up: '<path d="M12 19V5M5 12l7-7 7 7"/>',
    fire: '<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.4-.5-2-1-3-1.1-2.1-.2-4.1 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.2.4-2.3 1-3.3.3 1.5 1.2 2.8 2.5 2.8z"/>',
  };
  const icon = (name, size = 16) => `<svg class="i" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[name]}</svg>`;
  const PROD_SHORT = { Buy: 'Buy', 'Hot Machine': 'HM', BRZ: 'BRZ', Franquia: 'FR' };

  root.innerHTML = `<style>${CSS()}</style>
    <button class="fab" id="fab" data-tip="Abrir o funil">${icon('board', 18)}<span>CRM</span><span class="fab-badge" id="fab-badge" hidden></span></button>
    <div class="app" id="overlay" hidden>
      <header class="top">
        <div class="brand">${icon('board', 20)}<span>Funil</span></div>
        <div class="seg" id="who"></div>
        <label class="search">${icon('search')}<input id="search" type="search" placeholder="Buscar" aria-label="Buscar"></label>
        <div class="fx" id="fx"></div>
        <span class="spacer"></span>
        <button class="ib sync" id="btn-sync" data-tip="Atualizar agora">${icon('sync')}<span class="sync-t" id="sync-t"></span></button>
        <button class="ib upd" id="btn-upd" data-tip="Nova versão do CRM pronta: clique para atualizar" hidden>${icon('up')}</button>
        <span class="ib ghost" data-tip="Modo espelho: o CRM só lê a cópia das conversas que o WhatsApp Web guarda no computador, a cada 5 minutos ou quando você clica em Atualizar. Nunca mexe no WhatsApp.">${icon('lock')}</span>
        <button class="ib" id="btn-att" data-tip="Só quem precisa de você">${icon('bell')}<span class="ib-badge" id="att-badge" hidden></span></button>
        <button class="ib" id="btn-panel" data-tip="Painel">${icon('chart')}</button>
        <button class="ib" id="btn-stages" data-tip="Etapas">${icon('sliders')}</button>
        <button class="ib" id="btn-team" data-tip="Equipe">${icon('users')}</button>
        <button class="ib" id="btn-close" data-tip="Voltar ao WhatsApp (Esc)">${icon('x')}</button>
      </header>
      <div id="msg" class="msg" hidden></div>
      <section id="panel" class="kpis" hidden></section>
      <main id="board" class="board"></main>
      <div class="scrim" id="scrim" hidden></div>
      <aside class="drawer" id="drawer" hidden></aside>
    </div>
    <div class="modal-bg" id="modal" hidden><div class="modal" id="modal-box"></div></div>
    <div class="toast" id="toast" hidden></div>
    <div class="tip" id="tip" hidden></div>`;
  const $ = (sel) => root.querySelector(sel);

  // dica flutuante (aparece ao passar o mouse em qualquer coisa com data-tip)
  const tipEl = $('#tip');
  root.addEventListener('mouseover', (e) => {
    const el = e.target.closest?.('[data-tip]');
    if (!el) return;
    tipEl.textContent = el.dataset.tip;
    tipEl.hidden = false;
    const r = el.getBoundingClientRect();
    const t = tipEl.getBoundingClientRect();
    let top = r.bottom + 8;
    if (top + t.height > innerHeight - 8) top = r.top - t.height - 8;
    const left = Math.min(Math.max(8, r.left + r.width / 2 - t.width / 2), innerWidth - t.width - 8);
    tipEl.style.top = `${top}px`;
    tipEl.style.left = `${left}px`;
  });
  root.addEventListener('mouseout', (e) => {
    if (e.target.closest?.('[data-tip]') && !e.relatedTarget?.closest?.('[data-tip]')) tipEl.hidden = true;
  });

  let toastTimer;
  function toast(text, error = false) {
    const el = $('#toast');
    el.textContent = text;
    el.classList.toggle('error', error);
    el.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (el.hidden = true), error ? 7000 : 2600);
  }

  // ---------- cartão (compacto: nome, ícones, selos e valor) ----------
  function cardIcons(c, note) {
    const out = [];
    const step = C.stepInfo(note);
    for (const a of cardAlerts(c)) {
      if (a.kind === 'wait') out.push(`<span class="ic ${a.level}" data-tip="${esc(a.text)}">${icon('clock', 14)}</span>`);
      if (a.kind === 'stale') out.push(`<span class="ic warn" data-tip="${esc(a.text)}">${icon('moon', 14)}</span>`);
    }
    if (step) out.push(`<span class="ic ${step.alert ? step.level : 'muted'}" data-tip="Próximo passo · ${esc(step.text)}">${icon('cal', 14)}</span>`);
    if (c.multi.length > 1) out.push(`<span class="ic warn" data-tip="${esc(`${c.multi.length} etapas no WhatsApp: ${c.multi.join(' + ')}. Tire a antiga na conversa.`)}">${icon('warn', 14)}</span>`);
    if (note.notes) out.push(`<span class="ic muted" data-tip="${esc(String(note.notes).slice(0, 160))}">${icon('note', 14)}</span>`);
    if (c.lastText) out.push(`<span class="ic muted" data-tip="${esc(c.lastText)}">${icon('msg', 14)}</span>`);
    if (c.unread) out.push(`<span class="unread" data-tip="${c.unread} não lida${c.unread > 1 ? 's' : ''}">${c.unread > 99 ? '99+' : c.unread}</span>`);
    return out.join('');
  }
  function cardBadges(c, note) {
    const out = [];
    if (note.nivel) out.push(`<span class="bd lv ${esc(note.nivel)}" data-tip="Nível ${esc(NIVEIS.find(([v]) => v === note.nivel)?.[1] || note.nivel)}">${esc(note.nivel)}</span>`);
    if (note.produto) out.push(`<span class="bd pd" data-tip="Produto: ${esc(note.produto)}">${esc(PROD_SHORT[note.produto] || note.produto)}</span>`);
    if (note.origem) out.push(`<span class="bd og" data-tip="Origem: ${esc(note.origem)}">${icon('compass', 11)}</span>`);
    for (const t of c.tags) out.push(`<span class="dot" style="background:${esc(t.color)}" data-tip="Etiqueta: ${esc(t.name)}"></span>`);
    return out.join('');
  }
  function cardHtml(c) {
    const note = noteOf(c);
    const r = rank(c);
    const av = S.filter === 'all' ? `<span class="av sm" style="background:${avatarColor(c.owner)}" data-tip="${esc(c.mine ? `${c.owner} (você)` : c.owner)}">${esc(initials(c.owner))}</span>` : '';
    return `<article class="card ${r === 2 ? 'r-late' : r === 1 ? 'r-warn' : ''}" data-key="${esc(c.key)}">
      <div class="c1">${av}<span class="nm">${esc(c.name)}</span><span class="tm">${esc(ago(c.lastAt))}</span></div>
      <div class="c2"><span class="icons">${cardIcons(c, note)}</span><span class="badges">${cardBadges(c, note)}</span>${note.value ? `<span class="val" data-tip="Valor estimado/mês: ${esc(money(note.value))}">${esc(moneyShort(note.value))}</span>` : ''}</div>
    </article>`;
  }

  // ---------- topo ----------
  function renderWho() {
    const who = $('#who');
    if (!S.team) {
      who.innerHTML = '';
      return;
    }
    const updated = (p) => {
      const times = S.shared.cards.filter((c) => c.owner === p && c.updatedAt).map((c) => Date.parse(c.updatedAt));
      return times.length ? ago(Math.max(...times) / 1000) : '';
    };
    const seg = (value, label, tip, person) =>
      `<button class="sg ${S.filter === value ? 'on' : ''}" data-filter="${esc(value)}" data-tip="${esc(tip)}">${person ? `<span class="av xs" style="background:${avatarColor(person)}">${esc(initials(person))}</span>` : ''}${esc(label)}</button>`;
    who.innerHTML = [
      seg('all', 'Todos', 'Funil de toda a equipe'),
      seg('me', 'Meus', `Só o seu (${me()})`, me()),
      ...teamPeople()
        .filter((p) => p !== me())
        .map((p) => seg(p, p.split(' ')[0], updated(p) ? `Funil de ${p} · atualizado há ${updated(p)}` : `Funil de ${p}`, p)),
    ].join('');
  }

  function renderFx() {
    const sel = (key, ic, label, options) => {
      const on = S.fx[key];
      return `<label class="fxs ${on ? 'on' : ''}" data-tip="${esc(label)}">${icon(ic, 14)}<select data-fx="${key}" aria-label="${esc(label)}">
        <option value="">${esc(label)}</option>
        ${options.map(([v, t]) => `<option value="${esc(v)}" ${on === v ? 'selected' : ''}>${esc(t)}</option>`).join('')}
        <option value="-" ${on === '-' ? 'selected' : ''}>Sem ${esc(label.toLowerCase())}</option>
      </select></label>`;
    };
    const any = S.fx.produto || S.fx.nivel || S.fx.origem;
    $('#fx').innerHTML = `${sel('produto', 'pkg', 'Produto', PRODUTOS.map((p) => [p, p]))}${sel('nivel', 'level', 'Nível', NIVEIS)}${sel('origem', 'compass', 'Origem', ORIGENS.map((o) => [o, o]))}${any ? `<button class="ib sm" data-fx-clear data-tip="Limpar filtros">${icon('x', 14)}</button>` : ''}`;
  }

  // ---------- quadro ----------
  function render() {
    const myAtt = myCards().filter((c) => rank(c) > 0).length;
    $('#fab-badge').hidden = myAtt === 0;
    $('#fab-badge').textContent = myAtt;
    if (!S.open) return;
    renderSync();
    renderWho();
    renderFx();
    const cols = columnsData();
    const att = S.attention ? cols.flatMap((c) => c.items).length : visibleCards().filter((c) => rank(c) > 0).length;
    $('#att-badge').hidden = att === 0;
    $('#att-badge').textContent = att;
    $('#btn-att').classList.toggle('on', S.attention);
    $('#btn-panel').classList.toggle('on', S.showPanel);
    $('#btn-team').classList.toggle('alert', Boolean(S.team && S.shared.error));
    const problems = [];
    if (S.error) problems.push(S.error);
    if (!S.labels.length) problems.push('Nenhuma etiqueta no WhatsApp ainda. Crie Iniciando, Negociando, Em fechamento e Fechado (celular: Ferramentas → Etiquetas).');
    if (S.team && S.shared.error) problems.push(`Equipe: ${S.shared.error}`);
    $('#msg').hidden = problems.length === 0;
    $('#msg').textContent = problems.join(' · ');
    $('#board').innerHTML = cols
      .filter((col) => col.key === '' || col.items.length || S.stages.some((s) => norm(s.name) === col.key))
      .map((col) => {
        const total = col.items.reduce((s, c) => s + (Number(noteOf(c).value) || 0), 0);
        return `<section class="col" style="--c:${esc(col.key === '' ? '#9aa5b1' : col.color)}">
          <header class="col-h">
            <div class="col-t"><span class="col-name">${col.key === '' ? icon('inbox', 13) : ''}${esc(col.name)}</span><span class="col-n">${col.items.length}</span></div>
            <div class="col-s">${total ? esc(money(total)) : col.final ? 'final' : '&nbsp;'}</div>
          </header>
          <div class="cards">${col.items.map(cardHtml).join('') || '<div class="empty">vazio</div>'}</div>
        </section>`;
      })
      .join('');
    $('#panel').hidden = !S.showPanel;
    if (S.showPanel) renderPanel(cols);
    if (S.drawerKey && !$('#drawer').hidden) renderDrawer(S.drawerKey, true);
  }

  function renderPanel(cols) {
    const all = cols.flatMap((c) => c.items);
    const open = cols.filter((c) => c.key && !c.final).flatMap((c) => c.items);
    const sum = (list) => list.reduce((s, c) => s + (Number(noteOf(c).value) || 0), 0);
    const count = (kind) => all.filter((c) => cardAlerts(c).some((a) => a.kind === kind)).length;
    const kpi = (ic, value, label, tip, tone = '') => `<div class="kpi ${tone}" data-tip="${esc(tip)}"><span class="kpi-i">${icon(ic, 18)}</span><div><div class="kpi-v">${esc(value)}</div><div class="kpi-l">${esc(label)}</div></div></div>`;
    const group = (key, list) => {
      const rows = list.map(([v, t]) => {
        const items = open.filter((c) => noteOf(c)[key] === v);
        return { t, n: items.length, total: sum(items) };
      });
      const max = Math.max(1, ...rows.map((r) => r.total || r.n));
      return rows
        .map((r) => `<div class="gr" data-tip="${esc(`${r.t}: ${r.n} em aberto · ${money(r.total) || 'R$ 0'}/mês`)}"><span class="gr-t">${esc(r.t)}</span><span class="gr-bar"><i style="width:${((r.total || r.n) / max) * 100}%"></i></span><span class="gr-v">${r.n}</span></div>`)
        .join('');
    };
    $('#panel').innerHTML = `
      ${kpi('board', open.length, 'em aberto', 'Negócios em aberto (sem contar Novos e Fechado)')}
      ${kpi('money', moneyShort(sum(open)) || 'R$ 0', 'valor/mês', `Valor estimado por mês dos negócios em aberto: ${money(sum(open)) || 'R$ 0'}`)}
      ${kpi('clock', count('wait'), 'esperando', 'Clientes esperando sua resposta há 30 min ou mais', count('wait') ? 'warn' : '')}
      ${kpi('cal', count('step'), 'passos', 'Próximos passos para hoje ou atrasados', count('step') ? 'late' : '')}
      ${kpi('moon', count('stale'), 'parados', 'Parados na mesma etapa há 7 dias ou mais')}
      ${kpi('inbox', cols[0].items.length, 'novos', 'Conversas sem etiqueta de etapa')}
      <div class="kpi wide"><div class="kpi-l">${icon('level', 13)} Por nível</div>${group('nivel', NIVEIS.map(([v]) => [v, v]))}</div>
      <div class="kpi wide"><div class="kpi-l">${icon('pkg', 13)} Por produto</div>${group('produto', PRODUTOS.map((p) => [p, PROD_SHORT[p] || p]))}</div>`;
  }

  // ---------- painel lateral do cartão (detalhes + ficha) ----------
  const findCard = (key) => visibleCards().find((c) => c.key === key) || [...myCards(), ...teamCards()].find((c) => c.key === key);
  function openDrawer(key) {
    S.drawerKey = key;
    $('#drawer').hidden = false;
    $('#scrim').hidden = false;
    renderDrawer(key);
  }
  function closeDrawer() {
    S.drawerKey = null;
    $('#drawer').hidden = true;
    $('#scrim').hidden = true;
  }
  function renderDrawer(key, soft = false) {
    const c = findCard(key);
    if (!c) return closeDrawer();
    if (soft && root.activeElement && $('#drawer').contains(root.activeElement)) return; // não atrapalha quem está digitando
    const n = noteOf(c);
    const shared = Boolean(S.team);
    const step = C.stepInfo(n);
    const opts = (list, cur, ph) => [`<option value="">${esc(ph)}</option>`, ...list.map(([v, t]) => `<option value="${esc(v)}" ${cur === v ? 'selected' : ''}>${esc(t)}</option>`)].join('');
    const pairs = (arr) => arr.map((v) => [v, v]);
    const alerts = [...cardAlerts(c).filter((a) => a.kind !== 'step'), ...(step ? [{ ...step, kind: 'step' }] : [])];
    const alertIcon = { wait: 'clock', stale: 'moon', step: 'cal' };
    const row = (ic, label, field) => `<label class="fr"><span class="frl">${icon(ic, 14)}${esc(label)}</span>${field}</label>`;
    $('#drawer').innerHTML = `
      <header class="dw-h">
        <span class="av lg" style="background:${avatarColor(c.name)}">${esc(initials(c.name))}</span>
        <div class="dw-t"><div class="dw-name">${esc(c.name)}</div><div class="dw-sub">${c.phone ? `${icon('phone', 12)} ${esc(c.phone)}` : ''}</div></div>
        <button class="ib" data-dw-close data-tip="Fechar">${icon('x')}</button>
      </header>
      <div class="dw-pills">
        <span class="pill-stage" style="--c:${esc(c.stageColor || '#9aa5b1')}">${esc(c.stageName || 'Novos')}</span>
        ${!c.mine || S.team ? `<span class="pill-owner"><span class="av xs" style="background:${avatarColor(c.owner)}">${esc(initials(c.owner))}</span>${esc(c.owner)}</span>` : ''}
        ${c.mine ? `<button class="btn primary sm" data-open="${esc(c.id)}">${icon('open', 14)} Abrir conversa</button>` : ''}
      </div>
      ${alerts.length || c.multi.length > 1 ? `<div class="dw-alerts">${alerts.map((a) => `<div class="al ${a.level === 'info' ? 'muted' : a.level}">${icon(alertIcon[a.kind] || 'warn', 14)}<span>${esc(a.kind === 'step' ? `Próximo passo · ${a.text}` : a.text)}</span></div>`).join('')}${c.multi.length > 1 ? `<div class="al warn">${icon('warn', 14)}<span>${esc(`${c.multi.length} etapas no WhatsApp: ${c.multi.join(' + ')}`)}</span></div>` : ''}</div>` : ''}
      ${c.lastText ? `<div class="dw-last">${icon('msg', 14)}<span>${esc(c.lastText)}</span><span class="tm">${esc(ago(c.lastAt))}</span></div>` : ''}
      <form class="dw-form" id="dw-form" autocomplete="off">
        <div class="sec">Classificação</div>
        ${row('pkg', 'Produto', `<select id="f-produto">${opts(pairs(PRODUTOS), n.produto, '—')}</select>`)}
        ${row('level', 'Nível', `<select id="f-nivel">${opts(NIVEIS, n.nivel, '—')}</select>`)}
        ${row('compass', 'Origem', `<select id="f-origem">${opts(pairs(ORIGENS), n.origem, '—')}</select>`)}
        <div class="sec">Próximo passo</div>
        ${row('cal', 'O quê', `<input id="f-nextStep" value="${esc(n.nextStep ?? '')}" placeholder="Ex.: ligar para o síndico">`)}
        ${row('clock', 'Quando', `<input id="f-nextDate" type="date" value="${esc(n.nextDate ?? '')}">`)}
        <div class="sec">Negócio</div>
        ${row('money', 'Valor/mês', `<input id="f-value" type="number" step="0.01" min="0" value="${esc(n.value ?? '')}" placeholder="R$">`)}
        ${row('building', 'Local', `<select id="f-tipoLocal">${opts(pairs(TIPOS), n.tipoLocal, '—')}</select>`)}
        ${row('users', 'Pessoas', `<input id="f-tamanho" type="number" min="0" value="${esc(n.tamanho ?? '')}" placeholder="Moradores / funcionários">`)}
        ${row('user', 'Decisor', `<input id="f-decisor" value="${esc(n.decisor ?? '')}" placeholder="Quem decide">`)}
        ${row('fire', 'Concorrente', `<input id="f-concorrente" value="${esc(n.concorrente ?? '')}" placeholder="Quem já atende">`)}
        <div class="sec">Observações</div>
        <textarea id="f-notes" class="ta" rows="4" placeholder="Anote o que importa…">${esc(n.notes ?? '')}</textarea>
      </form>
      <footer class="dw-f">
        <span class="muted" data-tip="${shared ? 'A ficha fica na planilha da equipe: todos veem. Nada vai para o WhatsApp.' : 'A ficha fica só neste Chrome. Nada vai para o WhatsApp.'}">${icon(shared ? 'users' : 'lock', 13)} ${shared ? 'ficha da equipe' : 'só neste Chrome'}${n.by ? ` · por ${esc(n.by)}` : ''}</span>
        <button class="btn primary" id="f-save">Salvar</button>
      </footer>`;
    $('#f-save').onclick = () => saveFicha(c);
  }

  async function saveFicha(c) {
    const ficha = {};
    for (const f of FICHA) {
      const v = $(`#f-${f}`).value.trim();
      ficha[f] = ['value', 'tamanho'].includes(f) ? (v === '' ? null : Number(v)) : v;
    }
    if (c.mine) {
      S.cards[c.id] = { ...(S.cards[c.id] || {}), ...ficha };
      save.cards();
    }
    if (S.team) {
      $('#f-save').disabled = true;
      const r = await teamCall({ acao: 'anotar', dono: c.owner, id: c.id, nome: c.name, ficha, pessoa: me() });
      $('#f-save').disabled = false;
      if (!r?.ok) return toast(`Não consegui salvar na planilha: ${r?.erro || 'erro'}`, true);
      S.shared.notes.set(`${c.owner}|${c.id}`, { ...ficha, owner: c.owner, id: c.id, by: me() });
    }
    root.activeElement?.blur?.();
    render();
    renderDrawer(c.key);
    toast('Ficha salva');
  }

  // ---------- janelas (etapas e equipe) ----------
  function openModal(html) {
    $('#modal-box').innerHTML = html;
    $('#modal').hidden = false;
  }
  const closeModal = () => ($('#modal').hidden = true);

  function editStages() {
    const stageIds = new Set(S.stages.map((s) => s.id));
    const finals = new Set(S.stages.filter((s) => s.final).map((s) => s.id));
    const order = [...S.stages.map((s) => s.id), ...S.labels.map((l) => String(l.id)).filter((id) => !stageIds.has(id))];
    const byId = new Map(S.labels.map((l) => [String(l.id), l]));
    const rows = () =>
      order
        .map(
          (id, i) => `<li data-id="${esc(id)}"><i class="sw" style="background:${esc(byId.get(id)?.hexColor || '#ccc')}"></i><span class="lname">${esc(byId.get(id)?.name)}</span>
          <label class="tg" data-tip="Vira coluna no funil"><input type="checkbox" class="is-stage" ${stageIds.has(id) ? 'checked' : ''}><span>Etapa</span></label>
          <label class="tg" data-tip="Fim de linha: não avisa quando parado"><input type="checkbox" class="is-final" ${finals.has(id) ? 'checked' : ''}><span>Final</span></label>
          <button type="button" class="ib sm" data-up ${i === 0 ? 'disabled' : ''} data-tip="Subir">▲</button><button type="button" class="ib sm" data-down ${i === order.length - 1 ? 'disabled' : ''} data-tip="Descer">▼</button></li>`,
        )
        .join('') || '<li class="muted">Nenhuma etiqueta. Crie no celular: Ferramentas → Etiquetas.</li>';
    openModal(`<header class="md-h">${icon('sliders')}<h2>Etapas</h2><button class="ib" data-close>${icon('x')}</button></header>
      <p class="muted">As etapas são as etiquetas do WhatsApp (crie e renomeie no celular). Aqui você escolhe quais viram coluna e a ordem.</p>
      <ul class="stages" id="st-list">${rows()}</ul>
      <div class="row"><span class="spacer"></span><button class="btn" data-close>Cancelar</button><button class="btn primary" id="st-save">Salvar</button></div>`);
    const list = $('#st-list');
    list.onclick = (e) => {
      const li = e.target.closest('li[data-id]');
      if (!li) return;
      const i = order.indexOf(li.dataset.id);
      const j = e.target.closest('[data-up]') ? i - 1 : e.target.closest('[data-down]') ? i + 1 : -1;
      if (j < 0 || j >= order.length) return;
      [order[i], order[j]] = [order[j], order[i]];
      list.innerHTML = rows();
    };
    list.onchange = (e) => {
      const id = e.target.closest('li')?.dataset.id;
      if (e.target.classList.contains('is-stage')) e.target.checked ? stageIds.add(id) : stageIds.delete(id);
      if (e.target.classList.contains('is-final')) e.target.checked ? finals.add(id) : finals.delete(id);
    };
    $('#st-save').onclick = () => {
      S.settings = { ...S.settings, stageIds: order.filter((id) => stageIds.has(id)), finalIds: [...finals], knownLabelIds: S.labels.map((l) => String(l.id)) };
      save.settings();
      S.stages = C.stageList(S.labels, S.settings);
      closeModal();
      render();
      publish(true);
      toast('Etapas salvas');
    };
  }

  function editTeam() {
    const t = S.team || {};
    openModal(`<header class="md-h">${icon('users')}<h2>Equipe</h2><button class="ib" data-close>${icon('x')}</button></header>
      <p class="muted">Junte o seu funil com o de outras pessoas (ex.: Bianca) usando uma planilha Google como ponto de encontro. Nada disso mexe no WhatsApp.</p>
      <label class="fl">Seu nome<input id="t-name" value="${esc(t.pessoa || '')}" placeholder="Pedro"></label>
      <label class="fl">Endereço da planilha<input id="t-url" value="${esc(t.url || '')}" placeholder="https://script.google.com/macros/s/.../exec"></label>
      <label class="fl">Código da equipe<input id="t-code" value="${esc(t.codigo || '')}" placeholder="o mesmo do Apps Script"></label>
      <div class="row">${S.team ? '<button class="btn" id="t-off">Desligar</button>' : ''}<span class="spacer"></span><button class="btn" data-close>Cancelar</button><button class="btn primary" id="t-save">Testar e salvar</button></div>`);
    if ($('#t-off'))
      $('#t-off').onclick = () => {
        S.team = null;
        S.filter = 'me';
        S.shared = { cards: [], notes: new Map(), at: 0, error: null };
        save.team();
        save.filter();
        closeModal();
        render();
        toast('Equipe desligada');
      };
    $('#t-save').onclick = async () => {
      const team = { pessoa: $('#t-name').value.trim(), url: $('#t-url').value.trim(), codigo: $('#t-code').value.trim() };
      if (!team.pessoa || !team.url || !team.codigo) return toast('Preencha nome, endereço e código.', true);
      const before = S.team;
      S.team = team;
      $('#t-save').disabled = true;
      const r = await teamCall({ acao: 'teste' });
      $('#t-save').disabled = false;
      if (!r?.ok) {
        S.team = before;
        return toast(`Não consegui falar com a planilha: ${r?.erro || 'erro'}`, true);
      }
      save.team();
      if (S.filter === 'me') S.filter = 'all';
      save.filter();
      closeModal();
      toast('Equipe conectada');
      await publish(true);
      await pull();
      await uploadLocalFichas();
    };
  }

  // ---------- eventos ----------
  function setOpen(open) {
    S.open = open;
    $('#overlay').hidden = !open;
    tipEl.hidden = true;
    if (!open) closeDrawer();
    if (open) {
      if (Date.now() - S.readAt > 60 * 1000) refresh();
      else render();
      pull();
    }
  }
  $('#fab').onclick = () => setOpen(!S.open);
  $('#btn-sync').onclick = () => refresh();
  // botão Atualizar: mostra há quanto tempo foi a última leitura
  function renderSync() {
    const b = $('#btn-sync');
    b.classList.toggle('spin', S.reading);
    $('#sync-t').textContent = S.reading ? '' : S.readAt ? ago(S.readAt / 1000) : '';
    const quando = ago(S.readAt / 1000) === 'agora' ? 'agora mesmo' : `há ${ago(S.readAt / 1000)}`;
    b.dataset.tip = S.reading ? 'Lendo o WhatsApp…' : S.readAt ? `Lido ${quando}. Lê sozinho a cada 5 min; clique para ler agora.` : 'Ler o WhatsApp agora';
  }
  $('#btn-close').onclick = () => setOpen(false);
  $('#btn-att').onclick = () => {
    S.attention = !S.attention;
    render();
  };
  $('#btn-panel').onclick = () => {
    S.showPanel = !S.showPanel;
    render();
  };
  $('#btn-stages').onclick = editStages;
  $('#btn-team').onclick = editTeam;
  $('#search').oninput = (e) => {
    S.search = e.target.value;
    render();
  };
  root.addEventListener('change', (e) => {
    const k = e.target.dataset?.fx;
    if (!k) return;
    S.fx[k] = e.target.value;
    render();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape' || !S.open) return;
    if (!$('#modal').hidden) return closeModal();
    if (!$('#drawer').hidden) return closeDrawer();
    setOpen(false);
  });

  // "Abrir conversa": escreve o número (ou nome) na busca do próprio WhatsApp,
  // igual a você digitar. Aí é só clicar na conversa. Nada é enviado.
  const openChat = (key) => {
    const c = findCard(key);
    if (!c) return;
    const digits = (c.phone || '').replace(/\D/g, '');
    const text = digits ? digits.replace(/^55/, '') : c.name;
    setOpen(false);
    const box = document.querySelector('#side [contenteditable="true"], #side input[type="text"], #side input:not([type]), [data-testid="chat-list-search"] [contenteditable="true"]');
    if (box) {
      box.focus();
      try {
        document.execCommand('selectAll', false, null);
        document.execCommand('insertText', false, text);
        return toast('Procurei na busca do WhatsApp: clique na conversa');
      } catch {}
    }
    navigator.clipboard?.writeText(text).catch(() => {});
    toast(`Copiei "${text}": cole na busca do WhatsApp (Ctrl+V)`);
  };
  root.addEventListener('click', (e) => {
    if (e.target.closest('[data-close]') || e.target.id === 'modal') return closeModal();
    if (e.target.closest('[data-dw-close]') || e.target.id === 'scrim') return closeDrawer();
    if (e.target.closest('[data-fx-clear]')) {
      S.fx = { produto: '', nivel: '', origem: '' };
      return render();
    }
    const seg = e.target.closest('[data-filter]');
    if (seg) {
      S.filter = seg.dataset.filter;
      save.filter();
      render();
      if (S.filter !== 'me') pull();
      return;
    }
    const openBtn = e.target.closest('[data-open]');
    if (openBtn) return openChat(openBtn.dataset.open);
    const card = e.target.closest('.card');
    if (card) openDrawer(card.dataset.key);
  });

  // tema claro/escuro igual ao do WhatsApp Web
  const syncTheme = () => host.setAttribute('data-theme', document.body?.classList.contains('dark') ? 'dark' : 'light');

  // ---------- início ----------
  async function start() {
    S.settings = (await storage.get('crm:settings')) || {};
    if (!S.settings.novosDesde) {
      S.settings.novosDesde = Date.now() - 30 * 86400000;
      save.settings();
    }
    S.cards = (await storage.get('crm:cards')) || {};
    S.team = (await storage.get('crm:team')) || null;
    S.filter = (S.team && (await storage.get('crm:filter'))) || 'me';
    document.body.appendChild(host);
    syncTheme();
    new MutationObserver(syncTheme).observe(document.body, { attributes: true, attributeFilter: ['class'] });
    await refresh();
    // lê de novo a cada 5 minutos (e quando você abre o CRM ou clica em Atualizar)
    setInterval(() => refresh(), LER_A_CADA);
    setInterval(() => (S.open ? render() : null), 60 * 1000);
    // equipe: manda o seu funil e busca o dos outros a cada 2 minutos
    setInterval(() => {
      publish();
      if (S.open) pull();
    }, 2 * 60 * 1000);
    publish(true);
    checkUpdate();
    setInterval(checkUpdate, 30 * 60 * 1000);
  }

  // espera o WhatsApp Web terminar de abrir (lista de conversas na tela) e mais um pouco
  function whenReady(tries = 0) {
    const ready = document.querySelector('#pane-side') || globalThis.CRMLeitorTeste;
    if (!ready) return setTimeout(() => whenReady(tries + 1), 2000);
    setTimeout(start, globalThis.CRMLeitorTeste ? 0 : 15000);
  }
  whenReady();

  // ---------- atualização automática (Opção A: pasta atualizada pelo atualizador do Windows) ----------
  async function checkUpdate() {
    if (!ext) return;
    try {
      const r = await ext.runtime.sendMessage({ type: 'versao' });
      $('#btn-upd').hidden = !r?.nova;
      if (r?.nova) $('#btn-upd').dataset.tip = `Nova versão do CRM (${r.nova}) pronta: clique para atualizar`;
    } catch {}
  }
  $('#btn-upd').onclick = async () => {
    try {
      await ext.runtime.sendMessage({ type: 'recarregar' });
    } catch {}
    setTimeout(() => location.reload(), 600);
  };

  function CSS() {
    return `
    :host { all: initial; --bg:#f3f5f8; --panel:#ffffff; --col:#eaeef3; --text:#1f2733; --muted:#7a8699; --line:#e2e7ee; --acc:#2f6fed; --acc-soft:#e8f0fe; --warn:#e8a317; --late:#e5484d; --ok:#25a36f; --shadow:0 1px 2px rgba(16,24,40,.06), 0 1px 3px rgba(16,24,40,.08); font: 13px/1.4 Inter, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }
    :host([data-theme="dark"]) { --bg:#0f1418; --panel:#1b232a; --col:#151c22; --text:#e6ebf0; --muted:#8a97a6; --line:#2a343d; --acc:#5b8def; --acc-soft:#1f2c44; --shadow:0 1px 2px rgba(0,0,0,.4); }
    * { box-sizing: border-box; font-family: inherit; }
    [hidden] { display: none !important; }
    button, input, select, textarea { font: inherit; color: inherit; }
    .i { flex: none; display: block; }
    .spacer { flex: 1; }
    .ib.sync { width: auto; padding: 0 8px; gap: 5px; display: inline-flex; align-items: center; }
    .sync-t { font-size: 11.5px; color: var(--muted); white-space: nowrap; }
    .sync-t:empty { display: none; }
    .ib.sync.spin .i { animation: spin 1s linear infinite; }
    @keyframes spin { to { transform: rotate(360deg); } }
    .ib.upd { background: var(--ok); color: #fff; }
    .muted { color: var(--muted); font-size: 12px; margin: 0; display: inline-flex; align-items: center; gap: 5px; }

    .fab { position: fixed; left: 76px; bottom: 14px; z-index: 2147483000; display: inline-flex; align-items: center; gap: 7px; background: var(--acc); color: #fff; border: 0; border-radius: 12px; padding: 9px 14px; font-weight: 600; cursor: pointer; box-shadow: 0 6px 16px rgba(47,111,237,.35); }
    .fab-badge { background: var(--late); color: #fff; border-radius: 999px; min-width: 18px; height: 18px; padding: 0 5px; font-size: 11px; display: inline-grid; place-items: center; }

    .app { position: fixed; inset: 0; z-index: 2147483001; background: var(--bg); color: var(--text); display: flex; flex-direction: column; }
    .top { display: flex; align-items: center; gap: 10px; padding: 10px 16px; background: var(--panel); border-bottom: 1px solid var(--line); flex-wrap: wrap; }
    .brand { display: flex; align-items: center; gap: 8px; font-weight: 700; font-size: 15px; color: var(--acc); margin-right: 4px; }
    .seg { display: inline-flex; background: var(--col); border-radius: 10px; padding: 3px; gap: 2px; }
    .seg:empty { display: none; }
    .sg { border: 0; background: transparent; border-radius: 8px; padding: 5px 10px; cursor: pointer; display: inline-flex; align-items: center; gap: 6px; color: var(--muted); font-weight: 500; }
    .sg.on { background: var(--panel); color: var(--text); box-shadow: var(--shadow); }
    .search { display: flex; align-items: center; gap: 6px; background: var(--col); border-radius: 10px; padding: 0 10px; color: var(--muted); width: 220px; }
    .search input { border: 0; background: transparent; outline: none; padding: 7px 0; width: 100%; color: var(--text); }
    .fx { display: inline-flex; gap: 6px; align-items: center; }
    .fxs { display: inline-flex; align-items: center; gap: 4px; border: 1px solid var(--line); border-radius: 10px; padding: 0 4px 0 8px; color: var(--muted); background: var(--panel); }
    .fxs.on { border-color: var(--acc); color: var(--acc); background: var(--acc-soft); }
    .fxs select { border: 0; background: transparent; outline: none; padding: 6px 2px; cursor: pointer; color: inherit; max-width: 130px; }
    .ib { position: relative; display: inline-grid; place-items: center; width: 34px; height: 34px; border-radius: 10px; border: 0; background: transparent; color: var(--muted); cursor: pointer; }
    .ib:hover:not([disabled]) { background: var(--col); color: var(--text); }
    .ib.on { background: var(--acc-soft); color: var(--acc); }
    .ib.alert { color: var(--late); }
    .ib.ghost { cursor: help; }
    .ib.sm { width: 26px; height: 26px; border-radius: 8px; font-size: 10px; }
    .ib[disabled] { opacity: .3; cursor: default; }
    .ib-badge { position: absolute; top: 2px; right: 1px; background: var(--late); color: #fff; border-radius: 999px; min-width: 16px; height: 16px; font-size: 10px; display: grid; place-items: center; padding: 0 4px; }
    .msg { margin: 10px 16px 0; padding: 9px 12px; border-radius: 10px; background: #fff4d6; color: #6b4e00; font-size: 12.5px; }

    .kpis { display: grid; grid-template-columns: repeat(6, minmax(0, 1fr)) minmax(0, 1.6fr) minmax(0, 1.6fr); gap: 10px; padding: 12px 16px 0; }
    .kpi { min-width: 0; overflow: hidden; background: var(--panel); border-radius: 12px; padding: 10px 12px; box-shadow: var(--shadow); display: flex; gap: 10px; align-items: center; }
    .kpi-i { width: 34px; height: 34px; border-radius: 10px; display: grid; place-items: center; background: var(--acc-soft); color: var(--acc); flex: none; }
    .kpi.warn .kpi-i { background: #fff3d6; color: var(--warn); }
    .kpi.late .kpi-i { background: #fde7e7; color: var(--late); }
    .kpi-v { font-size: 18px; font-weight: 700; line-height: 1.1; white-space: nowrap; }
    .kpi-l { color: var(--muted); font-size: 11.5px; display: flex; align-items: center; gap: 5px; white-space: nowrap; }
    .kpi.wide { flex-direction: column; align-items: stretch; gap: 4px; }
    .gr { display: grid; grid-template-columns: 34px 1fr 22px; gap: 6px; align-items: center; font-size: 11.5px; }
    .gr-t { color: var(--muted); font-weight: 600; }
    .gr-bar { height: 6px; background: var(--col); border-radius: 99px; overflow: hidden; }
    .gr-bar i { display: block; height: 100%; background: var(--acc); border-radius: 99px; }
    .gr-v { text-align: right; font-weight: 600; }

    .board { flex: 1; display: flex; gap: 12px; padding: 14px 16px; overflow: auto; align-items: flex-start; }
    .col { flex: 1 0 240px; max-width: 340px; max-height: 100%; display: flex; flex-direction: column; }
    .col-h { padding: 4px 4px 8px; margin-bottom: 8px; border-bottom: 3px solid var(--c); }
    .col-t { display: flex; align-items: center; justify-content: space-between; gap: 6px; }
    .col-name { display: inline-flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 700; letter-spacing: .04em; text-transform: uppercase; color: var(--text); }
    .col-n { font-size: 11.5px; font-weight: 600; color: var(--muted); background: var(--col); border-radius: 99px; padding: 1px 8px; }
    .col-s { font-size: 12px; color: var(--muted); margin-top: 2px; min-height: 16px; }
    .cards { overflow-y: auto; display: flex; flex-direction: column; gap: 6px; padding: 0 2px 8px; min-height: 40px; }
    .empty { color: var(--muted); text-align: center; padding: 14px; font-size: 12px; border: 1px dashed var(--line); border-radius: 10px; }
    .card { background: var(--panel); border-radius: 10px; padding: 9px 11px; box-shadow: var(--shadow); cursor: pointer; border-left: 3px solid transparent; transition: transform .08s, box-shadow .08s; }
    .card:hover { transform: translateY(-1px); box-shadow: 0 4px 12px rgba(16,24,40,.12); }
    .card.r-warn { border-left-color: var(--warn); }
    .card.r-late { border-left-color: var(--late); }
    .c1 { display: flex; align-items: center; gap: 7px; }
    .nm { flex: 1; font-weight: 600; font-size: 13px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .tm { color: var(--muted); font-size: 11px; flex: none; }
    .c2 { display: flex; align-items: center; gap: 6px; margin-top: 6px; min-height: 18px; flex-wrap: wrap; row-gap: 4px; }
    .icons { display: inline-flex; align-items: center; gap: 5px; }
    .ic { display: inline-grid; place-items: center; color: var(--muted); }
    .ic.warn { color: var(--warn); }
    .ic.late { color: var(--late); }
    .ic.muted { color: #a3adbb; }
    .unread { background: var(--ok); color: #fff; border-radius: 99px; font-size: 10px; font-weight: 700; min-width: 17px; height: 17px; display: inline-grid; place-items: center; padding: 0 4px; }
    .badges { display: inline-flex; align-items: center; gap: 4px; margin-left: auto; }
    .bd { font-size: 10px; font-weight: 700; border-radius: 6px; padding: 1px 6px; line-height: 16px; display: inline-flex; align-items: center; }
    .bd.pd { background: #e3f4ee; color: #187a55; }
    .bd.og { background: var(--col); color: var(--muted); padding: 2px 4px; }
    .bd.lv.N1 { background: #eef2f7; color: #5b6b80; }
    .bd.lv.N2 { background: #fff1d6; color: #9a6400; }
    .bd.lv.N3 { background: #ffe1d6; color: #b4400f; }
    :host([data-theme="dark"]) .bd.pd { background: #173a2e; color: #6fd3a6; }
    :host([data-theme="dark"]) .bd.lv.N1 { background: #263240; color: #a9b6c6; }
    :host([data-theme="dark"]) .bd.lv.N2 { background: #3d3014; color: #f0c56a; }
    :host([data-theme="dark"]) .bd.lv.N3 { background: #45251a; color: #ff9f7a; }
    .dot { width: 8px; height: 8px; border-radius: 50%; display: inline-block; }
    .val { font-size: 11.5px; font-weight: 700; color: var(--text); flex: none; }
    .badges:empty + .val { margin-left: auto; }
    .icons:empty { display: none; }

    .av { width: 26px; height: 26px; border-radius: 50%; color: #fff; display: inline-grid; place-items: center; font-size: 11px; font-weight: 700; flex: none; }
    .av.sm { width: 20px; height: 20px; font-size: 9.5px; }
    .av.xs { width: 16px; height: 16px; font-size: 8.5px; }
    .av.lg { width: 42px; height: 42px; font-size: 15px; }

    .scrim { position: absolute; inset: 0; background: rgba(15,20,25,.25); }
    .drawer { position: absolute; top: 0; right: 0; bottom: 0; width: min(440px, 100%); background: var(--panel); box-shadow: -8px 0 24px rgba(16,24,40,.16); display: flex; flex-direction: column; animation: slide .16s ease-out; }
    @keyframes slide { from { transform: translateX(24px); opacity: .6; } to { transform: none; opacity: 1; } }
    .dw-h { display: flex; align-items: center; gap: 12px; padding: 16px 16px 10px; }
    .dw-t { flex: 1; min-width: 0; }
    .dw-name { font-size: 16px; font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .dw-sub { color: var(--muted); font-size: 12px; display: flex; align-items: center; gap: 5px; }
    .dw-pills { display: flex; align-items: center; gap: 8px; padding: 0 16px 12px; flex-wrap: wrap; border-bottom: 1px solid var(--line); }
    .pill-stage { font-size: 12px; font-weight: 600; padding: 3px 10px; border-radius: 99px; background: color-mix(in srgb, var(--c) 22%, transparent); color: var(--text); border: 1px solid color-mix(in srgb, var(--c) 55%, transparent); }
    .pill-owner { display: inline-flex; align-items: center; gap: 5px; font-size: 12px; color: var(--muted); }
    .dw-pills .btn { margin-left: auto; }
    .dw-alerts { padding: 10px 16px 0; display: flex; flex-direction: column; gap: 6px; }
    .al { display: flex; align-items: center; gap: 8px; font-size: 12.5px; padding: 7px 10px; border-radius: 9px; background: var(--col); }
    .al.warn { background: #fff4d9; color: #7a5300; }
    .al.late { background: #fde8e8; color: #a3282c; }
    :host([data-theme="dark"]) .al.warn { background: #3a2f12; color: #f3cd72; }
    :host([data-theme="dark"]) .al.late { background: #40201f; color: #ff9b9b; }
    .dw-last { margin: 10px 16px 0; display: flex; gap: 8px; align-items: flex-start; font-size: 12.5px; color: var(--muted); background: var(--col); border-radius: 9px; padding: 8px 10px; }
    .dw-last span:first-of-type { flex: 1; color: var(--text); overflow-wrap: anywhere; }
    .dw-form { flex: 1; overflow-y: auto; padding: 4px 16px 14px; display: flex; flex-direction: column; gap: 2px; }
    .sec { font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .05em; color: var(--muted); margin: 14px 0 4px; }
    .dw-form .fr { display: grid; grid-template-columns: 112px 1fr; align-items: center; gap: 8px; min-height: 34px; border-bottom: 1px dashed var(--line); }
    .dw-form .frl { display: flex; align-items: center; flex-direction: row; gap: 7px; color: var(--muted); font-size: 12.5px; }
    .dw-form .fr input, .dw-form .fr select { border: 1px solid transparent; border-radius: 7px; background: transparent; outline: none; padding: 6px 8px; width: 100%; min-width: 0; color: var(--text); font: inherit; font-size: 13px; }
    .dw-form .fr:hover input, .dw-form .fr:hover select { background: var(--col); }
    .dw-form .fr input:focus, .dw-form .fr select:focus { border-color: var(--acc); background: var(--panel); }
    .dw-form .fr select { cursor: pointer; }
    .dw-form .fr input::placeholder { color: var(--muted); opacity: .7; }
    .dw-form .ta { border: 1px solid var(--line); border-radius: 9px; background: var(--col); outline: none; padding: 9px 10px; width: 100%; box-sizing: border-box; color: var(--text); font: inherit; font-size: 13px; resize: vertical; }
    .dw-form .ta:focus { border-color: var(--acc); background: var(--panel); }
    .dw-f { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 12px 16px; border-top: 1px solid var(--line); }

    .btn { border: 1px solid var(--line); background: var(--panel); border-radius: 9px; padding: 7px 14px; cursor: pointer; font-weight: 600; display: inline-flex; align-items: center; gap: 6px; }
    .btn:hover { background: var(--col); }
    .btn.primary { background: var(--acc); color: #fff; border-color: var(--acc); }
    .btn.primary:hover { filter: brightness(1.06); }
    .btn.sm { padding: 5px 10px; font-size: 12px; }
    .btn:disabled { opacity: .6; cursor: progress; }

    .modal-bg { position: fixed; inset: 0; z-index: 2147483002; background: rgba(15,20,25,.45); display: flex; align-items: center; justify-content: center; padding: 16px; }
    .modal { background: var(--panel); color: var(--text); border-radius: 14px; padding: 16px 18px; width: min(520px, 100%); max-height: calc(100vh - 32px); overflow: auto; display: flex; flex-direction: column; gap: 12px; box-shadow: 0 20px 50px rgba(0,0,0,.25); }
    .md-h { display: flex; align-items: center; gap: 8px; color: var(--acc); }
    .md-h h2 { margin: 0; font-size: 16px; color: var(--text); flex: 1; }
    .fl { display: flex; flex-direction: column; gap: 4px; font-weight: 600; font-size: 12px; color: var(--muted); }
    .fl input { padding: 8px 10px; border: 1px solid var(--line); border-radius: 9px; background: var(--bg); font-weight: 400; color: var(--text); }
    .row { display: flex; gap: 8px; align-items: center; }
    .stages { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 6px; }
    .stages li { display: flex; align-items: center; gap: 8px; border: 1px solid var(--line); border-radius: 10px; padding: 6px 8px; }
    .sw { width: 10px; height: 10px; border-radius: 3px; flex: none; }
    .lname { flex: 1; font-weight: 500; }
    .tg { display: inline-flex; align-items: center; gap: 4px; font-size: 12px; color: var(--muted); cursor: pointer; }

    .toast { position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%); z-index: 2147483003; background: #1f2733; color: #fff; padding: 9px 16px; border-radius: 10px; max-width: calc(100vw - 32px); box-shadow: 0 8px 24px rgba(0,0,0,.2); font-size: 12.5px; }
    .toast.error { background: var(--late); }
    .tip { position: fixed; z-index: 2147483004; max-width: 280px; background: #1f2733; color: #fff; font-size: 11.5px; line-height: 1.35; padding: 6px 9px; border-radius: 7px; pointer-events: none; box-shadow: 0 4px 14px rgba(0,0,0,.2); }
    @media (max-width: 1200px) { .kpis { grid-template-columns: repeat(3, minmax(0, 1fr)); } .search { width: 160px; } }
    @media (max-width: 720px) { .col { flex-basis: 85vw; } .fx { display: none; } }
    `;
  }
})();
