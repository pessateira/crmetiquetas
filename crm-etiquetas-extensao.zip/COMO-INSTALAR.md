# Coyote CRM: funil do WhatsApp Business em modo espelho (somente leitura)

É um funil (Kanban) **dentro do próprio WhatsApp Web** que **espelha** as etiquetas do seu WhatsApp Business:

- **As colunas são as etiquetas**, e cada cliente aparece na coluna da etiqueta que tem no WhatsApp.
- **Trocou a etiqueta no WhatsApp** (no celular ou no WhatsApp Web)? O cartão muda de coluna sozinho em poucos segundos.
- **O CRM nunca mexe no seu WhatsApp:**
  - não cria, não troca e não tira etiqueta;
  - não envia mensagem;
  - **não coloca nenhum código dentro do WhatsApp Web**. Ele só lê a cópia das conversas e etiquetas que o próprio WhatsApp Web guarda no computador.
- Avisos de **"esperando sua resposta"** e **"parado na etapa"**, mais um **Painel** com os números.
- **Valor (R$) e anotações** ficam guardados só no seu Chrome.

## Para evitar desconexões (leia antes)

**Até a versão 2.3**, o CRM colocava uma biblioteca (WA-JS) **dentro** do WhatsApp Web para ler as etiquetas. É a causa mais provável do aviso **"Seus dispositivos foram desconectados"**: essa biblioteca mexe nas peças internas do WhatsApp, e em 2026 houve vários relatos de desconexão ligados a ela.

**A partir da versão 3.0**, isso acabou:
- o CRM **não roda nada dentro do WhatsApp** e não usa nenhuma função dele;
- ele só **lê a cópia** que o WhatsApp Web já guarda no seu computador e fecha logo em seguida. Como isso não encosta no WhatsApp, ele lê **quase em tempo real**: poucos segundos depois que algo muda na lista de conversas, a cada 15 segundos com o CRM aberto e a cada 1 minuto com ele fechado (nunca com a aba do WhatsApp escondida);
- a primeira leitura só acontece depois que o WhatsApp Web termina de abrir.

**Se o WhatsApp Web cair mesmo assim:**
- O CRM não lê nada enquanto o WhatsApp está fora do ar, nem nos 30 segundos depois que ele volta.
- Tudo fica anotado no **diário de quedas**: botão de **Conexão** (linha de batimento) no topo do CRM. Ele mostra quando caiu, quando voltou, se a página recarregou, se apareceu o QR code e há quanto tempo o CRM tinha lido.
- Para tirar a dúvida se é o CRM: na mesma janela, clique em **Pausar** e use um dia assim. Se cair do mesmo jeito com a leitura pausada, a causa é outra (internet, celular, outra extensão).
- Se cair, clique em **Copiar relatório** e mande para quem cuida do CRM.

Além disso:
1. **No celular**, em WhatsApp Business → **Dispositivos conectados**, deixe só o que você usa (o WhatsApp Web).
2. **Troque etiquetas só pelo WhatsApp oficial** (celular ou o próprio WhatsApp Web). O CRM só mostra.
3. **Não use outras extensões que automatizam o WhatsApp** (disparo, robô, "CRM" que mexe em etiqueta).
4. **Nada de disparo em massa ou mensagem automática** por este número.
5. Mantenha o celular com internet e o app WhatsApp Business atualizado.

## Instalar (uma vez só em cada computador, 3 minutos)

Daqui pra frente o CRM **se atualiza sozinho**: um atualizador no Windows busca a versão nova a cada 15 minutos. E você pode buscar na hora (veja abaixo).

1. **Baixe:** https://github.com/pessateira/crmetiquetas/raw/main/crm-etiquetas-extensao.zip
2. Em **Downloads**, clique com o botão direito no arquivo → **Extrair tudo** → **Extrair**.
3. Dentro da pasta extraída, dê **dois cliques** em **INSTALAR-ATUALIZADOR**.
   - Se o Windows mostrar "O Windows protegeu o computador": clique em **Mais informações** → **Executar assim mesmo**.
   - Uma janela preta baixa o CRM para a pasta `%LOCALAPPDATA%\CRM-Etiquetas\extensao`, cria a tarefa que atualiza sozinha e copia o endereço da pasta.
4. No Chrome, abra `chrome://extensions` e ligue o **Modo do desenvolvedor** (canto de cima, à direita). Ele fica ligado.
5. Clique em **Carregar sem compactação**. Na janela que abrir, clique na barra de endereço lá em cima, aperte **Ctrl+V** e **Enter**, e clique em **Selecionar pasta**.
   - Já tinha o CRM instalado? **Não precisa remover**: o Chrome troca pela nova (é a mesma extensão) e mantém as fichas. Se der erro, aí remova a antiga e carregue de novo.
6. Abra o **web.whatsapp.com** (ou aperte F5) e espere as conversas carregarem. Uns 15 segundos depois aparece o botão preto **CRM** com o coiote, no canto de baixo à esquerda.

**Chrome da Bianca no mesmo computador** (outro perfil): faça só os passos 4 a 6 no perfil dela, escolhendo a mesma pasta.

**Buscar a versão nova na hora:** no CRM, botão **Conexão e versão** (linha de batimento, no topo) → **Procurar atualização**.
- Se tiver versão nova, ele baixa na hora e o botão vira **Atualizar agora**: clique e o WhatsApp Web recarrega já na versão nova.
- Se disser que o botão ainda não está ligado neste computador: espere uns 15 minutos (o atualizador liga sozinho) ou rode o **INSTALAR-ATUALIZADOR** de novo.

**Quando a versão nova chega sozinha:** aparece um **botão verde com uma seta** no topo do CRM. Clique nele. Se fechar e abrir o Chrome, ele também já abre na versão nova.

## Primeiro uso: funil padrão da equipe

**Colunas (iguais para todos):**

| Coluna | O que é | Etiqueta no WhatsApp |
|---|---|---|
| **Novos** | Conversas **sem etiqueta**: as do último mês antes de instalar e todas as que chegarem depois | nenhuma (não crie "Novos") |
| **Iniciando** | Começou a conversa e está entendendo a necessidade | **Iniciando** |
| **Negociando** | Proposta, visita ou condições em discussão | **Negociando** |
| **Em fechamento** | Contrato e últimos detalhes | **Em fechamento** |
| **Fechado** | Assinou | **Fechado** |

1. **No celular** (WhatsApp Business → **Ferramentas → Etiquetas**), crie as 4 etiquetas com **exatamente** estes nomes: **Iniciando**, **Negociando**, **Em fechamento** e **Fechado**. A Bianca faz o mesmo no WhatsApp dela.
2. Se tiver etiquetas antigas que não são etapa (Buy, Franquia, Moai...): no CRM, em **Etapas**, desmarque "etapa" nelas (ou apague no celular).
3. No CRM, em **Etapas**: deixe na ordem Iniciando → Negociando → Em fechamento → Fechado, confira que **Fechado** está como **final** e clique em **Salvar**.
4. **Negócio que não fechou?** Crie no celular a etiqueta **Perdido** (o CRM entende sozinho que é etapa final e cria a coluna depois de Fechado). Troque a etiqueta da conversa para Perdido, escreva o motivo no **Histórico** e, se valer tentar de novo, marque um **Próximo passo** com data (ex.: recontatar em 3 meses). Arquivar a conversa não tira do funil quem tem etiqueta.

## No dia a dia

O funil mostra pouco texto. **Passe o mouse** em qualquer ícone para ver o que ele quer dizer. **Clique no cartão** para ver tudo.

**No cartão:**

| Ícone | Quer dizer |
|---|---|
| 🕒 relógio (amarelo ou vermelho) | Cliente esperando sua resposta |
| 🌙 lua | Parado na mesma etapa há 7 dias ou mais |
| 📅 calendário (vermelho = hoje ou atrasado) | Próximo passo |
| 📄 folha | Tem observação na ficha |
| 💬 balão | Última mensagem |
| bolinha verde com número | Mensagens não lidas |
| **N1 / N2 / N3 / N4** | Nível do negócio: pequeno, médio, grande, gigante |
| **VM / OCS** (vermelho) | Produto THM: Vending Machine, OCS |
| **FZ-M / FZ-E** (azul) | Produto BRZ: Freezer Mensal, Freezer Evento |
| **MERC / BOX** (verde) | Produto Buy: Mercadinho, Buy Box |
| **FRQ** (amarelo) | Produto TMF: Franquia |
| 🧭 bússola | Origem |
| **R$ 36 mil** | Valor estimado do negócio **por ano** (12 meses) |
| foto ou iniciais | Foto do WhatsApp da pessoa (quando ela tem e o WhatsApp Web já carregou) |
| bolinha com inicial (P, B) | De quem é o cliente (no modo Todos) |

A **borda colorida** à esquerda do cartão avisa: amarela = atenção, vermelha = urgente.

**Clique no cartão** e abre a **ficha** do lado direito:
- botão **Abrir conversa**: o CRM fecha e escreve o número na **busca do WhatsApp** (igual a você digitar). É só clicar na conversa. Para mudar de etapa, troque a etiqueta por lá;
- **Últimas mensagens:** o WhatsApp guarda o texto das mensagens criptografado, então o CRM anota o que já aparece na sua tela: a prévia de cada conversa na lista (também no ícone de balão do cartão) e as últimas mensagens da conversa que você abrir. Fica só neste Chrome (com a equipe ligada, a prévia vai junto para a planilha). Se não aparecer nada, abra a conversa uma vez ou role a lista até ela;
- **Histórico:** escreva o que aconteceu (ex.: "mandei a proposta", "liguei, decide sexta") e aperte **Enter**. Fica com a data e quem registrou. As mudanças de etapa entram sozinhas. O último registro aparece no ícone de relógio do cartão;
- **Nome no CRM:** escreva o nome que faz sentido para você (ex.: o nome da empresa quando é uma pessoa falando por ela). O cartão passa a mostrar esse nome; o nome e o número do WhatsApp continuam ligados e aparecem embaixo do nome na ficha (e ao passar o mouse no nome do cartão). A busca acha pelos dois;
- **Classificação:**
  - **Produto:** THM (Vending Machine, OCS), BRZ (Freezer Mensal, Freezer Evento), Buy (Mercadinho, Buy Box) e TMF (Franquia);
  - **Nível:** N1 pequeno, N2 médio, N3 grande, N4 gigante;
  - **Origem:** Moai, Indicação, Instagram, Google/Site, Outdoor, Prospecção ativa, Evento, Outro;
- **Próximo passo:** o quê e quando;
- **Negócio:** valor **por ano** (fichas antigas, que estavam por mês, já aparecem multiplicadas por 12), tipo de local, pessoas, decisor e concorrente;
- **Observações**;
- clique em **Salvar**: a ficha salva e fecha. Ela fica no CRM, nunca no WhatsApp;
- **Remover:** tira a conversa do funil (ex.: contato pessoal, fornecedor, spam). É só no CRM: no WhatsApp nada muda. Aparece **Desfazer** por alguns segundos.

**Remover direto no quadro:** passe o mouse no cartão e clique no **x** do canto.
- Se depois você colocar outra etiqueta de etapa nessa conversa no WhatsApp, ela volta sozinha para o funil.
- Para trazer de volta na mão: botão **controles** (Etapas) → **Removidos do funil** → **Voltar ao funil**.

**Botões do topo** (passe o mouse para ver o nome):
- **Todos / Meus / Bianca:** de quem é o funil que aparece;
- 🔄 **setas:** mostra há quanto tempo foi a última leitura (normalmente "agora"). Não precisa clicar: ele se atualiza sozinho. Se quiser, clique para ler na hora;
- **Buscar:** por nome, telefone ou qualquer coisa da ficha;
- **Produto, Nível e Origem:** filtros (ex.: só os N4; "BRZ (todos)" mostra os dois freezers; "Sem nível" acha quem falta classificar);
- 🔔 **sino:** mostra só quem precisa de você (esperando resposta, parado ou com passo para hoje ou atrasado);
- ➕ **mais (Adicionar ao funil):** puxa para o funil conversas que não estão nele (mais antigas que 1 mês, arquivadas ou removidas) e também **contatos salvos no celular** que ainda não têm conversa no WhatsApp Web. Busque por nome ou número, marque e clique em **Adicionar**. Elas entram em **Novos**;
- 📊 **gráfico:** Painel com os números (em aberto, valor por ano, por nível e por marca);
- 〰️ **linha de batimento (Conexão e versão):** mostra a versão e o botão **Procurar atualização**, explica o modo espelho, deixa **pausar a leitura automática** e mostra o **diário de quedas** do WhatsApp (botão **Copiar relatório**);
- **controles:** Etapas e a lista de removidos do funil;
- **pessoas:** Equipe;
- **Esc** fecha a ficha e depois o CRM.

**Quem entra no funil sozinho:**
- **Toda conversa com etiqueta de etapa**, mesmo antiga ou arquivada.
- **Número novo**, que nunca tinha falado com você: entra em **Novos** poucos segundos depois que chega, mesmo sem etiqueta e sem o contato salvo, com o nome que a pessoa usa no WhatsApp.
- Ficam de fora:
  - **contato antigo que volta a mandar mensagem** (se quiser no funil, coloque a etiqueta ou use o **+**);
  - grupos;
  - conversas sem etiqueta que você **arquivou**;
  - as que você **removeu** do funil.
- Como o CRM sabe quem é "antigo": na primeira vez que a versão 3.7 roda, ele tira uma "foto" de todas as conversas que já existem no WhatsApp Web. Quem estava na foto é antigo. Os cartões que já estavam em **Novos** nessa hora continuam lá.

**Puxar conversas que estão no celular:**
- **Já sabe a etapa?** No celular, coloque a etiqueta (Iniciando, Negociando...) na conversa. Em poucos segundos o cartão aparece na coluna certa, mesmo que a conversa seja antiga e ainda não esteja no WhatsApp Web.
- **Ainda sem etapa?** No CRM, botão **+** → busque → marque → **Adicionar**. Entra em **Novos** com o selo roxo **importado** (passe o mouse para ver quem importou e quando).
- **Não tem conversa nem contato salvo?** No **+**, clique em **"Não está na lista? Adicionar à mão"**, escreva o nome e o WhatsApp com DDD. Entra em **Novos** com o selo **manual**.
- **Não achou no +?** O WhatsApp Web só traz as conversas mais recentes e os contatos salvos. Procure a pessoa na busca do próprio WhatsApp Web e abra a conversa uma vez: ela passa a aparecer no **+**.

**Cartão com ⚠️ "2 etapas no WhatsApp":** tire a etiqueta antiga na conversa.

## Ver o CRM da equipe (ex.: o seu e o da Bianca juntos)

Cada pessoa usa o CRM no próprio Chrome, com o próprio WhatsApp. Para ver todos juntos, com o filtro **Todos / Meus / Bianca**, vocês usam **uma planilha Google como ponto de encontro**:
- a extensão de cada um manda para lá uma cópia do funil (a cada 2 minutos, enquanto o WhatsApp Web estiver aberto);
- valor e anotações passam a ser **da equipe**: o que um anota, o outro vê;
- **nada disso mexe no WhatsApp.**

### Parte 1: você cria a planilha (uma vez só, uns 5 minutos)

1. Entre na sua conta Google e abra **sheets.new**. Dê o nome **CRM Equipe**.
2. No menu: **Extensões → Apps Script**.
3. Abra o código: https://github.com/pessateira/crmetiquetas/raw/main/equipe/Codigo.gs. Aperte **Ctrl+A** e **Ctrl+C** para copiar tudo.
4. No Apps Script, apague o que estiver escrito e cole (**Ctrl+V**).
5. Na linha `const CODIGO = 'troque-este-codigo';`, troque `troque-este-codigo` por um código secreto seu (ex.: `machine-equipe-7391`). Mantenha as aspas.
6. Aperte **Ctrl+S** para salvar.
7. Clique em **Implantar → Nova implantação**. Na engrenagem ⚙️ de "Selecionar tipo", escolha **App da Web**:
   - **Executar como:** Eu;
   - **Quem pode acessar:** Qualquer pessoa;
   - clique em **Implantar**.
8. O Google vai pedir autorização: **Autorizar acesso** → escolha a sua conta → **Avançado** → **Acessar CRM Equipe (não seguro)** → **Permitir**. O aviso aparece porque o script é seu e não foi publicado na loja do Google; é normal.
9. Copie o **URL do app da Web**. Ele termina em `/exec`.

### Parte 2: cada pessoa liga a equipe no próprio CRM

1. Abra o **CRM** e clique no ícone de **pessoas** (Equipe), no alto à direita.
2. Preencha:
   - **Seu nome:** Pedro (no CRM da Bianca: Bianca);
   - **Endereço da planilha:** o URL que termina em `/exec`;
   - **Código da equipe:** o código que você colocou no passo 5.
3. Clique em **Testar e salvar**.
4. Mande para a Bianca, pelo WhatsApp, **o URL e o código**. Ela faz a mesma coisa no CRM dela (com a extensão instalada no Chrome dela).

### No dia a dia

- No topo do CRM aparecem os botões **Todos**, **Meus** e **Bianca**. Passe o mouse em **Bianca** para ver quando chegou a última atualização dela.
- Nos cartões da Bianca, o clique abre a **ficha**. A conversa em si está no WhatsApp dela, por isso não aparece **Abrir conversa**.
- **Para as colunas baterem**, usem **os mesmos nomes de etiqueta** nos dois WhatsApps (Iniciando, Negociando, Em fechamento, Fechado).
- A **ficha** (selos, próximo passo, valor, observações) é da equipe: o que um preenche, o outro vê. Fichas preenchidas antes de ligar a equipe sobem sozinhas para a planilha.
- **Já tinha criado a planilha com um código antigo?** Cole o código novo no Apps Script (mantendo o seu CODIGO) e faça **Implantar → Gerenciar implantações → ✏️ editar → Versão: Nova versão → Implantar**. O URL continua o mesmo.
- Na planilha, a aba **funil** mostra o funil de todo mundo e a aba **anotacoes**, as fichas (produto, nível, origem, próximo passo, valor...).
- ⚠️ Quem tiver o URL **e** o código consegue ler o funil. Não passe para fora da equipe. Para trocar o código: mude no Apps Script, faça **Implantar → Gerenciar implantações → editar → Nova versão** e atualize em **Equipe** no CRM de cada um.

## Para quem for mexer no código

- `leitor.js`: lê o banco `model-storage` (IndexedDB) que o WhatsApp Web guarda no navegador: tabelas `label`, `label-association`, `chat`, `contact`, `lid-pn-mapping` e as últimas mensagens de `message` (só quem falou e quando; o texto é criptografado e não é lido). Só transações de leitura; nunca cria o banco; fecha a conexão logo depois e sai da frente se o WhatsApp precisar atualizar o banco. Testes em `test/leitor.test.js`.
- `crm-core.js`: regras (testes em `test/`, rode `node --test test/*.test.js`).
- `crm.js`: a tela. Roda isolada da página do WhatsApp (mundo ISOLATED da extensão, Shadow DOM fechado). **Não chama nenhuma função do WhatsApp.**
- `background.js`: fala com a planilha da equipe e confere se há versão nova na pasta.
- `equipe/Codigo.gs`: código da planilha da equipe (testado com uma planilha simulada em `test/equipe.test.js`).
- `dev/teste.html`: abre a tela com um WhatsApp simulado (`dev/mock-idb.js` cria um banco igual ao do WhatsApp).
- `atualizador/` e `INSTALAR-ATUALIZADOR.cmd`: atualizador do Windows. Ele baixa o zip do repositório público **pessateira/crmetiquetas**.
- **Número da versão:** mudança pequena (correção, ajuste) sobe só o último número (3.7.0 → 3.7.1); mudança grande (função nova) sobe o do meio (3.7 → 3.8).
- **Para publicar uma versão nova:** aumente `version` no `manifest.json` e rode `python3 dev/empacotar.py <pasta do repositório crmetiquetas>`. Isso gera o zip, `versao.txt` e `versoes/crm-<versão>.zip`; depois é só enviar o repositório **crmetiquetas**. O atualizador baixa o zip com o número da versão no nome, então a cópia que o GitHub guarda por uns 5 minutos não atrapalha. Em até 1 hora cada computador baixa, e o botão verde aparece no CRM.
- **Nome dos clientes:** o CRM usa o nome salvo no seu celular. Se o contato não está salvo, usa o nome que a própria pessoa colocou no WhatsApp (aparece com `~` na ficha), e só por último o número.
- **Planilha da equipe:** a coluna de valor agora é **valor estimado/ano**. Quem já tinha a planilha pode colar o `Codigo.gs` novo (mantendo o seu CODIGO) e fazer **Implantar → Gerenciar implantações → editar → Nova versão**. Sem isso continua funcionando; só o título e o número dessa coluna ficam no formato antigo.
