# CRM Etiquetas: extensão do Chrome em modo espelho (somente leitura)

É um funil (Kanban) **dentro do próprio WhatsApp Web** que **espelha** as etiquetas do seu WhatsApp Business:

- **As colunas são as etiquetas**, e cada cliente aparece na coluna da etiqueta que tem no WhatsApp.
- **Trocou a etiqueta no WhatsApp** (no celular ou no WhatsApp Web)? O cartão muda de coluna na próxima leitura (a cada 5 minutos, ou na hora se você clicar em **Atualizar**).
- **O CRM nunca mexe no seu WhatsApp:**
  - não cria, não troca e não tira etiqueta;
  - não envia mensagem;
  - **não coloca nenhum código dentro do WhatsApp Web**. Ele só lê a cópia das conversas e etiquetas que o próprio WhatsApp Web guarda no computador.
- Avisos de **"esperando sua resposta"** e **"parado na etapa"**, mais um **Painel** com os números.
- **Valor (R$) e anotações** ficam guardados só no seu Chrome.

## Para evitar desconexões (leia antes)

**Até a versão 2.3**, o CRM colocava uma biblioteca (WA-JS) **dentro** do WhatsApp Web para ler as etiquetas. É a causa mais provável do aviso **"Seus dispositivos foram desconectados"**: essa biblioteca mexe nas peças internas do WhatsApp, e em 2026 houve vários relatos de desconexão ligados a ela.

**A partir da versão 3.0**, isso acabou:
- o CRM **não roda nada dentro do WhatsApp** e não usa nenhuma função dele;
- ele só **lê a cópia** que o WhatsApp Web já guarda no seu computador, **a cada 5 minutos** ou quando você clica em **Atualizar** (ícone de setas, no topo do CRM), e fecha logo em seguida;
- a primeira leitura só acontece depois que o WhatsApp Web termina de abrir.

Além disso:
1. **No celular**, em WhatsApp Business → **Dispositivos conectados**, deixe só o que você usa (o WhatsApp Web).
2. **Troque etiquetas só pelo WhatsApp oficial** (celular ou o próprio WhatsApp Web). O CRM só mostra.
3. **Não use outras extensões que automatizam o WhatsApp** (disparo, robô, "CRM" que mexe em etiqueta).
4. **Nada de disparo em massa ou mensagem automática** por este número.
5. Mantenha o celular com internet e o app WhatsApp Business atualizado.

## Instalar (uma vez só em cada computador, 3 minutos)

Daqui pra frente o CRM **se atualiza sozinho**: um atualizador no Windows busca a versão nova de hora em hora.

1. **Baixe:** https://github.com/pessateira/crmetiquetas/raw/main/crm-etiquetas-extensao.zip
2. Em **Downloads**, clique com o botão direito no arquivo → **Extrair tudo** → **Extrair**.
3. Dentro da pasta extraída, dê **dois cliques** em **INSTALAR-ATUALIZADOR**.
   - Se o Windows mostrar "O Windows protegeu o computador": clique em **Mais informações** → **Executar assim mesmo**.
   - Uma janela preta baixa o CRM para a pasta `%LOCALAPPDATA%\CRM-Etiquetas\extensao`, cria a tarefa que atualiza sozinha e copia o endereço da pasta.
4. No Chrome, abra `chrome://extensions` e ligue o **Modo do desenvolvedor** (canto de cima, à direita). Ele fica ligado.
5. Clique em **Carregar sem compactação**. Na janela que abrir, clique na barra de endereço lá em cima, aperte **Ctrl+V** e **Enter**, e clique em **Selecionar pasta**.
   - Já tinha o CRM instalado? **Não precisa remover**: o Chrome troca pela nova (é a mesma extensão) e mantém as fichas. Se der erro, aí remova a antiga e carregue de novo.
6. Abra o **web.whatsapp.com** (ou aperte F5) e espere as conversas carregarem. Uns 15 segundos depois aparece o botão **CRM**, no canto de baixo à esquerda.

**Chrome da Bianca no mesmo computador** (outro perfil): faça só os passos 4 a 6 no perfil dela, escolhendo a mesma pasta.

**Quando sair versão nova:** aparece um **botão verde com uma seta** no topo do CRM. Clique nele: o WhatsApp Web recarrega já com a versão nova. Se fechar e abrir o Chrome, ele também já abre na versão nova.

## Primeiro uso: funil padrão da equipe

**Colunas (iguais para todos):**

| Coluna | O que é | Etiqueta no WhatsApp |
|---|---|---|
| **Novos** | Conversas **sem etiqueta**: as do último mês antes de instalar e todas as que chegarem depois | nenhuma (não crie "Novos") |
| **Iniciando** | Começou a conversa e está entendendo a necessidade | **Iniciando** |
| **Negociando** | Proposta, visita ou condições em discussão | **Negociando** |
| **Em fechamento** | Contrato e últimos detalhes | **Em fechamento** |
| **Fechado** | Assinou | **Fechado** |

1. **No celular** (WhatsApp Business → **Ferramentas → Etiquetas**), crie as 4 etiquetas com **exatamente** estes nomes: **Iniciando**, **Negociando**, **Em fechamento** e **Fechado**. A Bianca faz o mesmo no WhatsApp dela.
2. Se tiver etiquetas antigas que não são etapa (Buy, Franquia, Moai...): no CRM, em **Etapas**, desmarque "etapa" nelas (ou apague no celular).
3. No CRM, em **Etapas**: deixe na ordem Iniciando → Negociando → Em fechamento → Fechado, confira que **Fechado** está como **final** e clique em **Salvar**.
4. **Lead perdido?** Arquive a conversa no WhatsApp: ela sai do funil.

## No dia a dia

O funil mostra pouco texto. **Passe o mouse** em qualquer ícone para ver o que ele quer dizer. **Clique no cartão** para ver tudo.

**No cartão:**

| Ícone | Quer dizer |
|---|---|
| 🕒 relógio (amarelo ou vermelho) | Cliente esperando sua resposta |
| 🌙 lua | Parado na mesma etapa há 7 dias ou mais |
| 📅 calendário (vermelho = hoje ou atrasado) | Próximo passo |
| 📄 folha | Tem observação na ficha |
| 💬 balão | Última mensagem |
| bolinha verde com número | Mensagens não lidas |
| **N1 / N2 / N3** | Nível do negócio |
| **Buy / HM / BRZ / FR** | Produto |
| 🧭 bússola | Origem |
| **R$ 2,4 mil** | Valor estimado por mês |
| bolinha com inicial (P, B) | De quem é o cliente (no modo Todos) |

A **borda colorida** à esquerda do cartão avisa: amarela = atenção, vermelha = urgente.

**Clique no cartão** e abre a **ficha** do lado direito:
- botão **Abrir conversa**: o CRM fecha e escreve o número na **busca do WhatsApp** (igual a você digitar). É só clicar na conversa. Para mudar de etapa, troque a etiqueta por lá;
- **Classificação:** Produto, Nível e Origem;
- **Próximo passo:** o quê e quando;
- **Negócio:** valor por mês, tipo de local, pessoas, decisor e concorrente;
- **Observações**;
- clique em **Salvar**. A ficha fica no CRM, nunca no WhatsApp.

**Botões do topo** (passe o mouse para ver o nome):
- **Todos / Meus / Bianca:** de quem é o funil que aparece;
- 🔄 **setas (Atualizar):** lê o WhatsApp de novo agora. Ao lado, aparece há quanto tempo foi a última leitura. Sozinho, ele lê a cada 5 minutos;
- **Buscar:** por nome, telefone ou qualquer coisa da ficha;
- **Produto, Nível e Origem:** filtros (ex.: só os N3; "Sem nível" acha quem falta classificar);
- 🔔 **sino:** mostra só quem precisa de você (esperando resposta, parado ou com passo para hoje ou atrasado);
- 📊 **gráfico:** Painel com os números (em aberto, valor por mês, por nível e por produto);
- **controles:** Etapas;
- **pessoas:** Equipe;
- **Esc** fecha a ficha e depois o CRM.

**Cartão com ⚠️ "2 etapas no WhatsApp":** tire a etiqueta antiga na conversa.

## Ver o CRM da equipe (ex.: o seu e o da Bianca juntos)

Cada pessoa usa o CRM no próprio Chrome, com o próprio WhatsApp. Para ver todos juntos, com o filtro **Todos / Meus / Bianca**, vocês usam **uma planilha Google como ponto de encontro**:
- a extensão de cada um manda para lá uma cópia do funil (a cada 2 minutos, enquanto o WhatsApp Web estiver aberto);
- valor e anotações passam a ser **da equipe**: o que um anota, o outro vê;
- **nada disso mexe no WhatsApp.**

### Parte 1: você cria a planilha (uma vez só, uns 5 minutos)

1. Entre na sua conta Google e abra **sheets.new**. Dê o nome **CRM Equipe**.
2. No menu: **Extensões → Apps Script**.
3. Abra o código: https://github.com/pessateira/crmetiquetas/raw/main/equipe/Codigo.gs. Aperte **Ctrl+A** e **Ctrl+C** para copiar tudo.
4. No Apps Script, apague o que estiver escrito e cole (**Ctrl+V**).
5. Na linha `const CODIGO = 'troque-este-codigo';`, troque `troque-este-codigo` por um código secreto seu (ex.: `machine-equipe-7391`). Mantenha as aspas.
6. Aperte **Ctrl+S** para salvar.
7. Clique em **Implantar → Nova implantação**. Na engrenagem ⚙️ de "Selecionar tipo", escolha **App da Web**:
   - **Executar como:** Eu;
   - **Quem pode acessar:** Qualquer pessoa;
   - clique em **Implantar**.
8. O Google vai pedir autorização: **Autorizar acesso** → escolha a sua conta → **Avançado** → **Acessar CRM Equipe (não seguro)** → **Permitir**. O aviso aparece porque o script é seu e não foi publicado na loja do Google; é normal.
9. Copie o **URL do app da Web**. Ele termina em `/exec`.

### Parte 2: cada pessoa liga a equipe no próprio CRM

1. Abra o **CRM** e clique no ícone de **pessoas** (Equipe), no alto à direita.
2. Preencha:
   - **Seu nome:** Pedro (no CRM da Bianca: Bianca);
   - **Endereço da planilha:** o URL que termina em `/exec`;
   - **Código da equipe:** o código que você colocou no passo 5.
3. Clique em **Testar e salvar**.
4. Mande para a Bianca, pelo WhatsApp, **o URL e o código**. Ela faz a mesma coisa no CRM dela (com a extensão instalada no Chrome dela).

### No dia a dia

- No topo do CRM aparecem os botões **Todos**, **Meus** e **Bianca**. Passe o mouse em **Bianca** para ver quando chegou a última atualização dela.
- Nos cartões da Bianca, o clique abre a **ficha**. A conversa em si está no WhatsApp dela, por isso não aparece **Abrir conversa**.
- **Para as colunas baterem**, usem **os mesmos nomes de etiqueta** nos dois WhatsApps (Iniciando, Negociando, Em fechamento, Fechado).
- A **ficha** (selos, próximo passo, valor, observações) é da equipe: o que um preenche, o outro vê. Fichas preenchidas antes de ligar a equipe sobem sozinhas para a planilha.
- **Já tinha criado a planilha com um código antigo?** Cole o código novo no Apps Script (mantendo o seu CODIGO) e faça **Implantar → Gerenciar implantações → ✏️ editar → Versão: Nova versão → Implantar**. O URL continua o mesmo.
- Na planilha, a aba **funil** mostra o funil de todo mundo e a aba **anotacoes**, as fichas (produto, nível, origem, próximo passo, valor...).
- ⚠️ Quem tiver o URL **e** o código consegue ler o funil. Não passe para fora da equipe. Para trocar o código: mude no Apps Script, faça **Implantar → Gerenciar implantações → editar → Nova versão** e atualize em **Equipe** no CRM de cada um.

## Para quem for mexer no código

- `leitor.js`: lê o banco `model-storage` (IndexedDB) que o WhatsApp Web guarda no navegador: tabelas `label`, `label-association`, `chat`, `contact`, `lid-pn-mapping` e as últimas mensagens de `message` (só quem falou e quando; o texto é criptografado e não é lido). Só transações de leitura; nunca cria o banco; fecha a conexão logo depois e sai da frente se o WhatsApp precisar atualizar o banco. Testes em `test/leitor.test.js`.
- `crm-core.js`: regras (testes em `test/`, rode `node --test test/*.test.js`).
- `crm.js`: a tela. Roda isolada da página do WhatsApp (mundo ISOLATED da extensão, Shadow DOM fechado). **Não chama nenhuma função do WhatsApp.**
- `background.js`: fala com a planilha da equipe e confere se há versão nova na pasta.
- `equipe/Codigo.gs`: código da planilha da equipe (testado com uma planilha simulada em `test/equipe.test.js`).
- `dev/teste.html`: abre a tela com um WhatsApp simulado (`dev/mock-idb.js` cria um banco igual ao do WhatsApp).
- `atualizador/` e `INSTALAR-ATUALIZADOR.cmd`: atualizador do Windows. Ele baixa o zip do repositório público **pessateira/crmetiquetas**.
- **Para publicar uma versão nova:** aumente `version` no `manifest.json`, rode `python3 dev/empacotar.py` e copie `crm-etiquetas-extensao.zip` (e `equipe/Codigo.gs`, se mudou) para o repositório **crmetiquetas**. Em até 1 hora o atualizador de cada computador baixa, e o botão verde aparece no CRM.
