// Leitor do WhatsApp Web SEM mexer no WhatsApp.
//
// O WhatsApp Web guarda uma cópia das conversas e etiquetas no próprio
// navegador (banco "model-storage", no IndexedDB). Este arquivo só LÊ esse
// banco, de vez em quando, e fecha logo em seguida:
// - não coloca nenhum código dentro da página do WhatsApp;
// - não usa nenhuma função interna do WhatsApp;
// - não fala com o servidor do WhatsApp;
// - não grava nada no banco (só transações "readonly").
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.CRMLeitor = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  const DB = 'model-storage';
  // Paleta de cores das etiquetas do WhatsApp Business (colorIndex -> cor).
  const CORES = ['#FF9485', '#64C4FF', '#FFD429', '#DFAEF0', '#99B6C1', '#55CCB3', '#FF9DFF', '#D3A91D', '#6D7CCE', '#D7E752', '#00D0E2', '#FFC5C7', '#93CEAC', '#F74848', '#00A0F2', '#83E422', '#FFAF04', '#B5EBFF', '#9BA6FF', '#9368CF'];
  // Listas automáticas do WhatsApp que não são etiquetas de verdade
  // (Não lidas, Grupos, Favoritos, Comunidades, IA, Canais, Menções...).
  const LISTAS_DO_SISTEMA = new Set([1, 2, 3, 6, 7, 8, 9, 10, 11, 17]);
  // Mensagens de sistema que não contam como "quem falou por último".
  const MSG_DE_SISTEMA = new Set(['e2e_notification', 'notification', 'notification_template', 'gp2', 'protocol', 'call_log', 'broadcast_notification', 'debug']);
  const MENSAGENS_RECENTES = 1500;

  const user = (jid) => String(jid || '').split('@')[0].split(':')[0];
  const isPessoa = (id) => /@(c\.us|lid)$/.test(id) && !id.startsWith('0@') && id !== 'status@broadcast';

  // Transforma o que foi lido do banco no formato do CRM (função pura, testada em test/leitor.test.js).
  function montar(raw, formatPhone) {
    const labels = (raw.labels || [])
      .filter((l) => l && l.id != null && l.name && l.isActive !== false && !LISTAS_DO_SISTEMA.has(Number(l.type)))
      .sort((a, b) => (a.orderIndex ?? 0) - (b.orderIndex ?? 0) || Number(a.id) - Number(b.id))
      .map((l) => ({ id: String(l.id), name: String(l.name), hexColor: CORES[Number(l.colorIndex)] || CORES[0] }));
    const labelIds = new Set(labels.map((l) => l.id));

    // número de telefone de quem só aparece com ID do WhatsApp (@lid)
    const pnDoLid = new Map();
    const lidDoPn = new Map();
    for (const m of raw.lidPn || []) {
      const lid = user(m.id);
      const pn = user(m.phoneNumber);
      if (lid && /^\d{8,15}$/.test(pn)) {
        pnDoLid.set(lid, pn);
        lidDoPn.set(pn, lid);
      }
    }
    const telefone = (id) => (id.endsWith('@c.us') ? user(id) : pnDoLid.get(user(id)) || '');
    // a mesma pessoa pode aparecer como número@c.us ou como ID@lid
    const apelidos = (id) => {
      const u = user(id);
      if (id.endsWith('@lid')) return [id, ...(pnDoLid.has(u) ? [`${pnDoLid.get(u)}@c.us`] : [])];
      return [id, ...(lidDoPn.has(u) ? [`${lidDoPn.get(u)}@lid`] : [])];
    };

    const etiquetasDe = new Map();
    for (const a of raw.assoc || []) {
      if (a.type && a.type !== 'jid') continue;
      const lid = String(a.labelId);
      if (!labelIds.has(lid)) continue;
      const k = String(a.associationId);
      if (!etiquetasDe.has(k)) etiquetasDe.set(k, new Set());
      etiquetasDe.get(k).add(lid);
    }

    const contatos = new Map((raw.contacts || []).map((c) => [String(c.id), c]));
    const nomesLid = new Map((raw.lidNames || []).map((n) => [user(n.id), n.displayName]));

    const ultima = new Map(); // chatId -> { t, fromMe }
    for (const m of raw.msgs || []) {
      if (!m || MSG_DE_SISTEMA.has(m.type)) continue;
      const k = /^(true|false)_([^_]+)_/.exec(String(m.id));
      if (!k) continue;
      const atual = ultima.get(k[2]);
      if (!atual || (m.t || 0) >= atual.t) ultima.set(k[2], { t: m.t || 0, fromMe: k[1] === 'true' });
    }

    const vistos = new Set();
    const chats = [];
    for (const ch of raw.chats || []) {
      const id = String(ch.id || '');
      if (!isPessoa(id) || vistos.has(id)) continue;
      vistos.add(id);
      const ids = apelidos(id);
      const labs = new Set();
      for (const x of ids) for (const l of etiquetasDe.get(x) || []) labs.add(l);
      const ct = ids.map((x) => contatos.get(x)).find(Boolean) || {};
      const fone = telefone(id) || user(ct.phoneNumber);
      const foneFmt = fone ? formatPhone(`${fone}@c.us`) : '';
      const nome = ct.name || ch.name || ct.verifiedName || ct.pushname || ct.shortName || nomesLid.get(user(id)) || foneFmt || 'Contato sem nome';
      const ult = ids.map((x) => ultima.get(x)).filter(Boolean).sort((a, b) => b.t - a.t)[0];
      const t = Math.max(Number(ch.t) || 0, ult?.t || 0);
      chats.push({
        id,
        name: String(nome),
        phone: foneFmt,
        labels: [...labs],
        lastAt: t,
        // só sabemos quem falou por último se a última mensagem está entre as recentes lidas
        lastFromMe: ult && ult.t >= (Number(ch.t) || 0) ? ult.fromMe : null,
        lastText: '',
        unread: Math.max(0, Number(ch.unreadCount) || 0),
        archived: Boolean(ch.archive),
      });
    }
    return { labels, chats };
  }

  // ---------- leitura do banco (só no navegador) ----------
  function abrir() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB);
      let criando = false;
      // se o banco ainda não existe, NÃO cria (o WhatsApp é quem cria)
      req.onupgradeneeded = () => {
        criando = true;
        req.transaction.abort();
      };
      req.onsuccess = () => {
        const db = req.result;
        // se o WhatsApp precisar atualizar o banco, saímos da frente na hora
        db.onversionchange = () => db.close();
        resolve(db);
      };
      req.onerror = () => reject(new Error(criando ? 'o WhatsApp Web ainda não terminou de carregar' : req.error?.message || 'não abriu'));
      req.onblocked = () => reject(new Error('banco ocupado, tente de novo'));
    });
  }
  const pedido = (r) => new Promise((resolve, reject) => {
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
  function recentes(store, n) {
    return new Promise((resolve) => {
      const out = [];
      if (!store.indexNames.contains('rowId')) return resolve(out);
      const cur = store.index('rowId').openCursor(null, 'prev');
      cur.onsuccess = () => {
        const c = cur.result;
        if (!c || out.length >= n) return resolve(out);
        const v = c.value;
        out.push({ id: v.id, t: v.t, type: v.type });
        c.continue();
      };
      cur.onerror = () => resolve(out);
    });
  }

  async function ler(formatPhone) {
    if (indexedDB.databases) {
      const dbs = await indexedDB.databases();
      if (!dbs.some((d) => d.name === DB)) throw new Error('o WhatsApp Web ainda não terminou de carregar');
    }
    const db = await abrir();
    try {
      const tem = (n) => db.objectStoreNames.contains(n);
      for (const n of ['label', 'label-association', 'chat']) if (!tem(n)) throw new Error(`o WhatsApp mudou o formato (falta "${n}")`);
      // uma transação curta por tabela: o WhatsApp nunca fica esperando o CRM para gravar
      const all = (n) => (tem(n) ? pedido(db.transaction(n, 'readonly').objectStore(n).getAll()) : Promise.resolve([]));
      const labels = await all('label');
      const assoc = await all('label-association');
      const chats = await all('chat');
      const contacts = await all('contact');
      const lidPn = await all('lid-pn-mapping');
      const lidNames = await all('lid-display-name-mapping');
      const msgs = tem('message') ? await recentes(db.transaction('message', 'readonly').objectStore('message'), MENSAGENS_RECENTES) : [];
      return montar({ labels, assoc, chats, contacts, lidPn, lidNames, msgs }, formatPhone);
    } finally {
      db.close();
    }
  }

  return { ler, montar, CORES, DB };
});
