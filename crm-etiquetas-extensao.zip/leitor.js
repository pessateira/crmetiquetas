// Leitor do WhatsApp Web SEM mexer no WhatsApp.
//
// O WhatsApp Web guarda uma cópia das conversas e etiquetas no próprio
// navegador (banco "model-storage", no IndexedDB). Este arquivo só LÊ esse
// banco, de vez em quando, e fecha logo em seguida:
// - não coloca nenhum código dentro da página do WhatsApp;
// - não usa nenhuma função interna do WhatsApp;
// - não fala com o servidor do WhatsApp;
// - não grava nada no banco (só transações "readonly").
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.CRMLeitor = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  const DB = 'model-storage';
  // Paleta de cores das etiquetas do WhatsApp Business (colorIndex -> cor).
  const CORES = ['#FF9485', '#64C4FF', '#FFD429', '#DFAEF0', '#99B6C1', '#55CCB3', '#FF9DFF', '#D3A91D', '#6D7CCE', '#D7E752', '#00D0E2', '#FFC5C7', '#93CEAC', '#F74848', '#00A0F2', '#83E422', '#FFAF04', '#B5EBFF', '#9BA6FF', '#9368CF'];
  // Listas automáticas do WhatsApp que não são etiquetas de verdade
  // (Não lidas, Grupos, Favoritos, Comunidades, IA, Canais, Menções...).
  const LISTAS_DO_SISTEMA = new Set([1, 2, 3, 6, 7, 8, 9, 10, 11, 17]);
  // Mensagens de sistema que não contam como "quem falou por último".
  const MSG_DE_SISTEMA = new Set(['e2e_notification', 'notification', 'notification_template', 'gp2', 'protocol', 'call_log', 'broadcast_notification', 'debug']);
  const MENSAGENS_RECENTES = 1500;

  const user = (jid) => String(jid || '').split('@')[0].split(':')[0];
  const isPessoa = (id) => /@(c\.us|lid)$/.test(id) && !id.startsWith('0@') && id !== 'status@broadcast';

  // Transforma o que foi lido do banco no formato do CRM (função pura, testada em test/leitor.test.js).
  function montar(raw, formatPhone) {
    const labels = (raw.labels || [])
      .filter((l) => l && l.id != null && l.name && l.isActive !== false && !LISTAS_DO_SISTEMA.has(Number(l.type)))
      .sort((a, b) => (a.orderIndex ?? 0) - (b.orderIndex ?? 0) || Number(a.id) - Number(b.id))
      .map((l) => ({ id: String(l.id), name: String(l.name), hexColor: CORES[Number(l.colorIndex)] || CORES[0] }));
    const labelIds = new Set(labels.map((l) => l.id));

    // número de telefone de quem só aparece com ID do WhatsApp (@lid)
    const pnDoLid = new Map();
    const lidDoPn = new Map();
    for (const m of raw.lidPn || []) {
      const lid = user(m.id);
      const pn = user(m.phoneNumber);
      if (lid && /^\d{8,15}$/.test(pn)) {
        pnDoLid.set(lid, pn);
        lidDoPn.set(pn, lid);
      }
    }
    const telefone = (id) => (id.endsWith('@c.us') ? user(id) : pnDoLid.get(user(id)) || '');
    // a mesma pessoa pode aparecer como número@c.us ou como ID@lid
    const apelidos = (id) => {
      const u = user(id);
      if (id.endsWith('@lid')) return [id, ...(pnDoLid.has(u) ? [`${pnDoLid.get(u)}@c.us`] : [])];
      return [id, ...(lidDoPn.has(u) ? [`${lidDoPn.get(u)}@lid`] : [])];
    };

    const etiquetasDe = new Map();
    for (const a of raw.assoc || []) {
      if (a.type && a.type !== 'jid') continue;
      const lid = String(a.labelId);
      if (!labelIds.has(lid)) continue;
      const k = String(a.associationId);
      if (!etiquetasDe.has(k)) etiquetasDe.set(k, new Set());
      etiquetasDe.get(k).add(lid);
    }

    const contatos = new Map((raw.contacts || []).map((c) => [String(c.id), c]));
    const nomesLid = new Map((raw.lidNames || []).map((n) => [user(n.id), n.displayName]));
    const fotos = new Map((raw.pics || []).filter((f) => f && (f.previewEurl || f.eurl)).map((f) => [String(f.id), f.previewEurl || f.eurl]));

    const ultima = new Map(); // chatId -> { t, fromMe }
    const nomeNaMsg = new Map(); // chatId -> nome que a pessoa usa no WhatsApp (vem nas mensagens dela)
    for (const m of raw.msgs || []) {
      if (!m || MSG_DE_SISTEMA.has(m.type)) continue;
      const k = /^(true|false)_([^_]+)_/.exec(String(m.id));
      if (!k) continue;
      if (k[1] === 'false' && m.notifyName && (m.t || 0) >= (nomeNaMsg.get(k[2])?.t ?? -1)) nomeNaMsg.set(k[2], { t: m.t || 0, nome: String(m.notifyName) });
      const atual = ultima.get(k[2]);
      if (!atual || (m.t || 0) >= atual.t) ultima.set(k[2], { t: m.t || 0, fromMe: k[1] === 'true' });
    }

    const vistos = new Set();
    const chats = [];
    const conversa = (id, ch) => {
      vistos.add(id);
      const ids = apelidos(id);
      ids.forEach((x) => vistos.add(x));
      const labs = new Set();
      for (const x of ids) for (const l of etiquetasDe.get(x) || []) labs.add(l);
      const ct = ids.map((x) => contatos.get(x)).find(Boolean) || {};
      const fone = telefone(id) || user(ct.phoneNumber);
      const foneFmt = fone ? formatPhone(`${fone}@c.us`) : '';
      // nome que a própria pessoa colocou no WhatsApp (aparece mesmo sem o contato salvo)
      const nomeWhats = ct.verifiedName || ct.pushname || ids.map((x) => nomeNaMsg.get(x)?.nome).find(Boolean) || nomesLid.get(user(id)) || '';
      const nome = ct.name || ch.name || nomeWhats || ct.shortName || foneFmt || 'Contato sem nome';
      const ult = ids.map((x) => ultima.get(x)).filter(Boolean).sort((a, b) => b.t - a.t)[0];
      const t = Math.max(Number(ch.t) || 0, ult?.t || 0);
      chats.push({
        id,
        name: String(nome),
        waName: nomeWhats && nomeWhats !== nome ? String(nomeWhats) : '',
        photo: ids.map((x) => fotos.get(x)).find(Boolean) || '',
        phone: foneFmt,
        labels: [...labs],
        lastAt: t,
        // só sabemos quem falou por último se a última mensagem está entre as recentes lidas
        lastFromMe: ult && ult.t >= (Number(ch.t) || 0) ? ult.fromMe : null,
        lastText: '',
        unread: Math.max(0, Number(ch.unreadCount) || 0),
        archived: Boolean(ch.archive),
        semConversa: Boolean(ch.semConversa),
      });
    };
    for (const ch of raw.chats || []) {
      const id = String(ch.id || '');
      if (isPessoa(id) && !vistos.has(id)) conversa(id, ch);
    }
    // conversa etiquetada no celular que ainda não veio para o WhatsApp Web
    // (o WhatsApp Web só traz as conversas mais recentes): entra mesmo assim
    for (const id of etiquetasDe.keys()) {
      if (isPessoa(id) && !vistos.has(id)) conversa(id, { semConversa: true });
    }
    // contatos salvos que ainda não têm conversa no WhatsApp Web (para o botão "+")
    const contatosSemConversa = [];
    for (const ct of raw.contacts || []) {
      const id = String(ct.id || '');
      if (!ct.name || !id.endsWith('@c.us') || vistos.has(id) || !isPessoa(id)) continue;
      contatosSemConversa.push({
        id,
        name: String(ct.name),
        waName: ct.pushname && ct.pushname !== ct.name ? String(ct.pushname) : '',
        photo: fotos.get(id) || '',
        phone: formatPhone(id),
        labels: [],
        lastAt: 0,
        lastFromMe: null,
        lastText: '',
        unread: 0,
        archived: false,
        semConversa: true,
      });
    }
    return { labels, chats, contatos: contatosSemConversa };
  }

  // ---------- leitura do banco (só no navegador) ----------
  function abrir() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB);
      let criando = false;
      // se o banco ainda não existe, NÃO cria (o WhatsApp é quem cria)
      req.onupgradeneeded = () => {
        criando = true;
        req.transaction.abort();
      };
      req.onsuccess = () => {
        const db = req.result;
        // se o WhatsApp precisar atualizar o banco, saímos da frente na hora
        db.onversionchange = () => db.close();
        resolve(db);
      };
      req.onerror = () => reject(new Error(criando ? 'o WhatsApp Web ainda não terminou de carregar' : req.error?.message || 'não abriu'));
      req.onblocked = () => reject(new Error('banco ocupado, tente de novo'));
    });
  }
  const pedido = (r) => new Promise((resolve, reject) => {
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
  function recentes(store, n) {
    return new Promise((resolve) => {
      const out = [];
      if (!store.indexNames.contains('rowId')) return resolve(out);
      const cur = store.index('rowId').openCursor(null, 'prev');
      cur.onsuccess = () => {
        const c = cur.result;
        if (!c || out.length >= n) return resolve(out);
        const v = c.value;
        out.push({ id: v.id, t: v.t, type: v.type, notifyName: v.notifyName });
        c.continue();
      };
      cur.onerror = () => resolve(out);
    });
  }

  // As tabelas pequenas (etiquetas e conversas) são lidas toda vez. As grandes,
  // que o WhatsApp grava o tempo todo (contatos e mensagens), bem menos:
  // contatos a cada 10 min e só as últimas mensagens a cada 1 min.
  const cache = { contacts: [], lidPn: [], lidNames: [], pics: [], msgs: new Map(), contatosEm: 0, msgsEm: 0, conversas: null };
  const CONTATOS_A_CADA = 10 * 60 * 1000;
  const MSGS_A_CADA = 60 * 1000;

  async function ler(formatPhone, { tudo = false } = {}) {
    if (indexedDB.databases) {
      const dbs = await indexedDB.databases();
      if (!dbs.some((d) => d.name === DB)) throw new Error('o WhatsApp Web ainda não terminou de carregar');
    }
    const db = await abrir();
    try {
      const tem = (n) => db.objectStoreNames.contains(n);
      for (const n of ['label', 'label-association', 'chat']) if (!tem(n)) throw new Error(`o WhatsApp mudou o formato (falta "${n}")`);
      // uma transação curta por tabela: o WhatsApp nunca fica esperando o CRM para gravar
      const all = (n) => (tem(n) ? pedido(db.transaction(n, 'readonly').objectStore(n).getAll()) : Promise.resolve([]));
      const labels = await all('label');
      const assoc = await all('label-association');
      const chats = await all('chat');
      const agora = Date.now();
      // surgiu conversa nova? lê as mensagens na hora (é delas que vem o nome de quem não está salvo)
      const ids = new Set(chats.map((c) => String(c.id)));
      const novaConversa = cache.conversas && [...ids].some((id) => !cache.conversas.has(id));
      cache.conversas = ids;
      if (tudo || agora - cache.contatosEm > CONTATOS_A_CADA) {
        cache.contacts = await all('contact');
        cache.lidPn = await all('lid-pn-mapping');
        cache.lidNames = await all('lid-display-name-mapping');
        cache.pics = await all('profile-pic-thumb');
        cache.contatosEm = agora;
      }
      if (tem('message') && (tudo || novaConversa || agora - cache.msgsEm > MSGS_A_CADA)) {
        const primeira = cache.msgsEm === 0;
        const novas = await recentes(db.transaction('message', 'readonly').objectStore('message'), primeira || tudo ? MENSAGENS_RECENTES : 300);
        for (const m of novas) cache.msgs.set(m.id, m);
        if (cache.msgs.size > 4000) cache.msgs = new Map([...cache.msgs].slice(-3000));
        cache.msgsEm = agora;
      }
      return montar({ labels, assoc, chats, contacts: cache.contacts, lidPn: cache.lidPn, lidNames: cache.lidNames, pics: cache.pics, msgs: [...cache.msgs.values()] }, formatPhone);
    } finally {
      db.close();
    }
  }

  return { ler, montar, CORES, DB };
});
